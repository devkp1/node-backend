import admin from '#root/config/firebaseConfig/firebaseConfig.cjs';

const sendNotification = async (registrationToken, message) => {
  
  // eslint-disable-next-line
  const payload = {
    notification: {
      title: message.title,
      body: message.body,
    },
    data: message.data || {},
  };

  try {
   
    const response = await admin.messaging().send({
      token: registrationToken,  
      notification: {
        title: message.title,
        body: message.body,
      },
      data: message.data || {}, 
    });

    
    return { firebaseResponse: response };
  } catch (error) {
    throw new Error(error.message);
  }
};

export default { sendNotification };
