import {
  CanNotAddAnotherActiveWithoutCompletedStatus,
  CanNotAddAnotherCompletedWithoutActiveStatus,
  CanNotUpdateStatus,
  CanNotUpdateStatusDuringSuspend,
  CycleIsAlreadyExistMessage,
  CycleNotFound,
  GenderNotFound,
  GenderValidation,
  InvalidDateRange,
  InvalidRequestPauseResume,
  InvalidStatus,
  MenstruationCycleNotFound,
  NoActiveFoundForCompleted,
  NoActivePauseFound,
  NotFoundErrorMessage,
  ServerErrorMessage,
  StatusCompletedDateGratherThanActiveStartDate,
  StatusIsSuspendedForThisDate,
  ValidDateFormat,
  ValidationErrorMessage,
} from '#root/constants/errorMessages.js';
import {
  CyclePauseSucessfully,
  MenstruationAddSucessfully,
  MenstruationCycleGetSucessfully,
  MenstruationCycleResumeSucessfully,
  MenstruationCycleUpdateSucessfully,
  MenstruationDeletedSuccessfully,
  PauseIsAlreadyExists,
  StatusUpdatedSucessfully,
} from '#root/constants/responseMessages.js';
import { statusCodes } from '#root/constants/statusCodeMessages.js';
import { errorResponse, successResponse } from '#root/utils/responseHandler.js';
import {
  UpdateValidateCycleInput,
  validateCycleInput,
} from '#root/validators/cycle.validation.js';
import moment from 'moment';
import CycleModel from './cycle.model.js';
import logger from '#root/logger.js';
import { checkUserExists } from '#root/utils/checkUserExists.js';
import User from '../User/user.model.js';
import CycleStatusModel from './cycle.status.model.js';
import { cycleStatus } from '#root/enums/cycleEnum.js';
import { calculateAdherenceCycle } from '#root/utils/calculateAdherence.js';
import { createCron } from '#root/Cron/autoCompltedCron.js';
import { sendMedicationNotification } from '#root/utils/sendMedicationNotification.js';
import {
  MenstruationCycleAddedNotification,
  MenstruationCycleUpdatedNotification,
  PeriodStartReminder,
} from '#root/constants/notificationMessages.js';
import { startCycleReminderCronJob } from '#root/Cron/morningCycleReminder.js';
import { sleepCycleReminderCronJob } from '#root/Cron/SleepCycleReminder.js';
import { MotivationalCycleReminderCronJob } from '#root/Cron/motivationalCycleReminder.js';

export const addCycle = async (req, res) => {
  try {
    const userId = req.user.userId;

    const user = await User.findById(userId).select('gender');
    if (!user) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        GenderNotFound,
        statusCodes.SUCCESS,
      );
    }

    const userGender = user.gender;

    if (!userGender) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        GenderNotFound,
        statusCodes.SUCCESS,
      );
    }

    if (userGender !== 'Female') {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        GenderValidation,
        statusCodes.SUCCESS,
      );
    }
    const existingCycle = await CycleModel.findOne({ userId });
    if (existingCycle) {
      return errorResponse(
        res,
        new Error(CycleIsAlreadyExistMessage),
        CycleIsAlreadyExistMessage,
        statusCodes.SUCCESS,
      );
    }
    const { valid, error, data } = validateCycleInput(req.body);
    if (!valid) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        error,
        statusCodes.SUCCESS,
      );
    }

    const cycle = await CycleModel.create({ ...data, userId });

    const formattedCycle = {
      id: cycle._id,
      userId: cycle.userId,
      cycleLength: cycle.cycleLength,
      menstruationLength: cycle.menstruationLength,
      menstruationStartDate: moment(cycle.menstruationStartDate).format(
        'DD/MM/YYYY',
      ),
      time: cycle.time,
      scheduleDayBefore: cycle.scheduleDayBefore,
      message: cycle.message,
      autoCompleted: cycle.autoCompleted,
      completedDays: cycle.completedDays,
    };

    startCycleReminderCronJob();
    sleepCycleReminderCronJob();
    MotivationalCycleReminderCronJob();

    const message = MenstruationCycleAddedNotification(cycle._id);
    await sendMedicationNotification(userId, message);

    return successResponse(
      res,
      formattedCycle,
      MenstruationAddSucessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Menstruation cycle add error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const getCycle = async (req, res) => {
  try {
    const userId = req.user.userId;
    const cycleId = req.params.id;

    const user = await checkUserExists(userId, res);
    if (!user) return;

    const cycle = await CycleModel.findById(cycleId);

    if (!cycle) {
      return successResponse(
        res,
        new Error(MenstruationCycleNotFound),
        MenstruationCycleNotFound,
        statusCodes.SUCCESS,
      );
    }

    const startDate = moment(cycle.menstruationStartDate).format('DD/MM/YYYY');
    const endDate = moment.utc().format('DD/MM/YYYY');

    const { timeWiseStatuses } = await calculateAdherenceCycle(
      cycleId,
      userId,
      startDate,
      endDate,
    );

    const formattedCycle = {
      id: cycle._id,
      cycleLength: cycle.cycleLength,
      menstruationLength: cycle.menstruationLength,
      menstruationStartDate: moment(cycle.menstruationStartDate).format(
        'DD/MM/YYYY',
      ),
      time: cycle.time,
      scheduleDayBefore: cycle.scheduleDayBefore,
      message: cycle.message,
      autoCompleted: cycle.autoCompleted,
      completedDays: cycle.completedDays,
      timeWiseStatuses,
    };

    return successResponse(
      res,
      formattedCycle,
      MenstruationCycleGetSucessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Get menstruation cycle error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const updateCycle = async (req, res) => {
  try {
    const cycleId = req.params.id;
    const userId = req.user.userId;

    const user = await checkUserExists(userId, res);
    if (!user) return;

    const validationResult = UpdateValidateCycleInput({
      ...req.body,
      userId,
    });

    if (!validationResult.valid) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        validationResult.error,
        statusCodes.VALIDATION_ERROR,
      );
    }

    let cycle = await CycleModel.findById(cycleId);
    if (!cycle) {
      return errorResponse(
        res,
        new Error(MenstruationCycleNotFound),
        MenstruationCycleNotFound,
        statusCodes.NOT_FOUND,
      );
    }

    cycle = await CycleModel.findByIdAndUpdate(
      cycleId,
      { ...validationResult.data },
      {
        new: true,
        runValidators: true,
        useFindAndModify: false,
      },
    );

    const formattedCycle = {
      id: cycle._id,
      cycleLength: cycle.cycleLength,
      menstruationLength: cycle.menstruationLength,
      menstruationStartDate: moment(cycle.menstruationStartDate).format(
        'DD/MM/YYYY',
      ),
      time: cycle.time,
      scheduleDayBefore: cycle.scheduleDayBefore,
      message: cycle.message,
      autoCompleted: cycle.autoCompleted,
      completedDate: cycle.completedDays,
    };
    const message = MenstruationCycleUpdatedNotification(cycle._id);
    await sendMedicationNotification(userId, message);

    return successResponse(
      res,
      formattedCycle,
      MenstruationCycleUpdateSucessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Menstruation cycle update error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const deleteCycle = async (req, res) => {
  try {
    const userId = req.user.userId;
    const cycleId = req.params.id;

    const user = await checkUserExists(userId, res);
    if (!user) return;

    let cycle = await CycleModel.findById(cycleId);

    if (!cycle) {
      return successResponse(
        res,
        new Error(MenstruationCycleNotFound),
        MenstruationCycleNotFound,
        statusCodes.SUCCESS,
      );
    }

    cycle = await CycleModel.findByIdAndDelete(cycleId);

    return successResponse(
      res,
      undefined,
      MenstruationDeletedSuccessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Delete menstruation cycle error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const updateCycleStatus = async (req, res) => {
  try {
    const { status, activeStartDate, completedDate } = req.body;
    const userId = req.user.userId;
    const cycleId = req.params.id;

    const allowedStatuses = [1, 2, 3];

    if (!allowedStatuses.includes(status)) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        InvalidStatus,
        statusCodes.SUCCESS,
      );
    }

    const cycle = await CycleModel.findById(cycleId);
    if (!cycle) {
      return errorResponse(
        res,
        new Error(NotFoundErrorMessage),
        CycleNotFound,
        statusCodes.NOT_FOUND,
      );
    }
    let cycleStatusRecord = await CycleStatusModel.findOne({ userId, cycleId });
    if (!cycleStatusRecord) {
      cycleStatusRecord = new CycleStatusModel({
        userId,
        cycleId,
        statuses: [],
      });
      await cycleStatusRecord.save();
    }

    const lastStatus =
      cycleStatusRecord.statuses[cycleStatusRecord.statuses.length - 1];
    // eslint-disable-next-line
    const lastActiveDate =
      lastStatus?.times[0]?.status === 'active'
        ? moment.utc(lastStatus.date)
        : null;

    const lastCompletedDate =
      lastStatus?.times[0]?.status === 'completed'
        ? moment.utc(lastStatus.date)
        : null;

    if (lastCompletedDate) {
      const currentDate = moment.utc();
      const daysSinceCompleted = currentDate.diff(lastCompletedDate, 'days');
       
      const formattedCompletedDate = lastCompletedDate
        .local()
        .format('DD/MM/YYYY');

      if (daysSinceCompleted < 10) {
        {
          return errorResponse(
            res,
            new Error(ValidationErrorMessage),
            `Your cycle was completed on ${formattedCompletedDate}, and you cannot update it within 10 days.`,
            statusCodes.SUCCESS,
          );
        }
      }
    }

    if (status === 1 && lastStatus?.times[0]?.status === 'active') {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        CanNotAddAnotherActiveWithoutCompletedStatus,
        statusCodes.SUCCESS,
      );
    }

    if (status === 2) {
      if (!lastStatus || lastStatus.times[0].status !== 'active') {
        return errorResponse(
          res,
          new Error(ValidationErrorMessage),
          CanNotAddAnotherCompletedWithoutActiveStatus,
          statusCodes.VALIDATION_ERROR,
        );
      }
    }

    let effectiveDate = moment.utc().toDate();

    if (status === 1) {
      let cycleMessage = '';
      const perfectDate = activeStartDate ? activeStartDate : effectiveDate;
      const currentActiveDate = moment.utc(perfectDate, 'DD/MM/YYYY', true);
      const currentDate = moment.utc();

      const activeStatuses = cycleStatusRecord.statuses.filter((entry) =>
        entry.times.some((timeEntry) => timeEntry.status === 'active'),
      );

      const lastActiveStatus = activeStatuses[activeStatuses.length - 1];
      const lastActiveDate = moment.utc(lastActiveStatus?.date);

      const autoCompletionApplied = createCron(
        userId,
        cycle,
        currentDate,
        lastActiveStatus,
        activeStatuses,
        cycleStatusRecord,
      );

      if (autoCompletionApplied) {
        return successResponse(
          res,
          {
            message: 'Your menstruation cycle has been auto-completed.',
          },
          StatusUpdatedSucessfully,
          statusCodes.SUCCESS,
        );
      }

      const monthsDifference = currentActiveDate.diff(
        lastActiveDate,
        'months',
        true,
      );
      const exactMonths = currentActiveDate.diff(lastActiveDate, 'months');
      const startOfLastMonth = lastActiveDate
        .clone()
        .add(exactMonths, 'months');
      const daysDifference = currentActiveDate.diff(startOfLastMonth, 'days');

      if (activeStatuses.length === 0) {
        cycleMessage = 'This is your first recorded active date.';
      } else {
        if (exactMonths === 1 && daysDifference === 0) {
          cycleMessage = 'Your menstruation cycle is on time.';
        } else if (exactMonths === 0) {
          const perfectDays = cycle.cycleLength ? cycle.cycleLength : 30;
          cycleMessage = `Your menstruation cycle started ${Math.abs(perfectDays - daysDifference)} days earlier than expected.`;
        } else if (daysDifference > 0) {
          let totalDaysLate = daysDifference;

          if (exactMonths > 1) {
            const totalMonthsLate = Math.floor(monthsDifference);
            const remainingDaysLate = currentActiveDate.diff(
              lastActiveDate.clone().add(totalMonthsLate, 'months'),
              'days',
            );
            totalDaysLate = remainingDaysLate;

            cycleMessage = `Your menstruation cycle started ${totalMonthsLate} months and ${totalDaysLate} days late from the last active date.`;
          } else {
            cycleMessage = `Your menstruation cycle started ${daysDifference} days late from the last active date.`;
          }
        } else {
          cycleMessage = 'Your menstruation cycle is on time.';
        }
      }

      const currentTime = moment.utc().local().format('HH:mm');

      cycleStatusRecord.statuses.push({
        date: currentActiveDate.toDate(),
        times: [
          {
            time: currentTime,
            status: cycleStatus[status],
          },
        ],
      });

      await cycleStatusRecord.save();

      if (currentActiveDate.isSame(currentDate, 'day')) {
        const message = PeriodStartReminder(cycleId);
        await sendMedicationNotification(userId, message);
      }
      return successResponse(
        res,
        {
          message: cycleMessage,
          status: {
            date: currentActiveDate.format('DD/MM/YYYY'),
            time: currentTime,
            status: cycleStatus[status],
          },
        },
        StatusUpdatedSucessfully,
        statusCodes.SUCCESS,
      );
    }

    const isSuspended = cycleStatusRecord.statuses.some((statusEntry) =>
      statusEntry.times.some((timeEntry) => {
        const suspendStart = moment.utc(timeEntry.pauseStartDate);
        const suspendEnd = moment.utc(timeEntry.pauseEndDate);
        return (
          timeEntry.status === 'suspend' &&
          moment().isBetween(suspendStart, suspendEnd, 'day', '[]')
        );
      }),
    );

    if (isSuspended) {
      return errorResponse(
        res,
        new Error(CanNotUpdateStatusDuringSuspend),
        StatusIsSuspendedForThisDate,
        statusCodes.VALIDATION_ERROR,
      );
    }

    const isPaused = cycleStatusRecord.statuses.some((statusEntry) => {
      const pauseTimes = statusEntry.times.find((t) => t.status === 'paused');
      if (pauseTimes) {
        const pauseStart = moment.utc(pauseTimes.pauseStartDate);
        const pauseEnd = pauseTimes.pauseEndDate
          ? moment.utc(pauseTimes.pauseEndDate)
          : moment.utc();
        return moment.utc().isBetween(pauseStart, pauseEnd, 'day', '[]');
      }
      return false;
    });

    if (isPaused && status !== 4) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        CanNotUpdateStatus,
        statusCodes.SUCCESS,
      );
    }

    if (status === 1 && activeStartDate) {
      const parsedActiveStartDate = moment.utc(
        activeStartDate,
        'DD/MM/YYYY',
        true,
      );
      if (!parsedActiveStartDate.isValid()) {
        return errorResponse(
          res,
          new Error(ValidationErrorMessage),
          ValidDateFormat,
          statusCodes.SUCCESS,
        );
      }
      effectiveDate = parsedActiveStartDate.toDate();
    }

    let cycleDuration = 0;

    let effectiveCompletedDate = moment.utc().toDate();

    if (status === 2) {
      effectiveCompletedDate = moment.utc().toDate();

      if (completedDate) {
        const parsedCompletedDate = moment.utc(
          completedDate,
          'DD/MM/YYYY',
          true,
        );

        if (!parsedCompletedDate.isValid()) {
          return errorResponse(
            res,
            new Error(ValidationErrorMessage),
            ValidDateFormat,
            statusCodes.SUCCESS,
          );
        }
        effectiveCompletedDate = parsedCompletedDate.toDate();
      }

      const lastActiveStatus = cycleStatusRecord.statuses
        .slice()
        .reverse()
        .find((s) => s.times[0].status === 'active');

      if (!lastActiveStatus) {
        return errorResponse(
          res,
          new Error(ValidationErrorMessage),
          NoActiveFoundForCompleted,
          statusCodes.SUCCESS,
        );
      }

      const activeDate = moment.utc(lastActiveStatus.date);
      const completedDateMoment = moment.utc(effectiveCompletedDate);

      if (completedDateMoment.isBefore(activeDate)) {
        return errorResponse(
          res,
          new Error(InvalidDateRange),
          StatusCompletedDateGratherThanActiveStartDate,
          statusCodes.SUCCESS,
        );
      }

      cycleDuration = completedDateMoment.diff(activeDate, 'days');
      lastActiveStatus.times[0].cycleDuration = cycleDuration;
    }

    if (status !== 1) {
      cycleStatusRecord.statuses.push({
        date: effectiveCompletedDate,
        times: [
          {
            time: moment.utc().local().format('HH:mm'),
            status: cycleStatus[status],
            cycleDuration,
          },
        ],
      });

      await cycleStatusRecord.save();
    }

    const responseData = {
      id: cycleId,
      status: {
        date: moment.utc(effectiveCompletedDate).local().format('DD/MM/YYYY'),
        time: moment.utc().local().format('HH:mm'),
        status: cycleStatus[status],
      },
    };

    if (status === 2) {
      responseData.status.cycleDuration = cycleDuration;
      responseData.message = `Your menstruation cycle was completed in ${cycleDuration} days.`;
    }

    return successResponse(
      res,
      responseData,
      StatusUpdatedSucessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Update cycle status error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const pauseResumeCycleStatus = async (req, res) => {
  try {
    const { pauseStartDate, pauseEndDate, pauseReason, resume } = req.body;
    const userId = req.user.userId;
    const cycleId = req.params.id;

    const user = await checkUserExists(userId, res);
    if (!user) {
      return;
    }

    const cycle = await CycleModel.findById(cycleId);
    if (!cycle) {
      return successResponse(
        res,
        new Error(MenstruationCycleNotFound),
        MenstruationCycleNotFound,
        statusCodes.SUCCESS,
      );
    }

    let cycleStatusRecord = await CycleStatusModel.findOne({ userId, cycleId });
    if (!cycleStatusRecord) {
      cycleStatusRecord = new CycleStatusModel({
        userId,
        cycleId,
        statuses: [],
      });
    }

    const isSuspended = cycleStatusRecord.statuses.some((statusEntry) => {
      return statusEntry.times.some((timeEntry) => {
        const suspendStart = moment.utc(timeEntry.pauseStartDate);
        const suspendEnd = moment.utc(timeEntry.pauseEndDate);

        if (
          timeEntry.status === 'suspend' &&
          moment().isBetween(suspendStart, suspendEnd, 'day', '[]')
        ) {
          const isResumed = cycleStatusRecord.statuses.some((resumeEntry) => {
            return resumeEntry.times.some((resumeTime) => {
              return (
                resumeTime.status === 'resumed' &&
                moment.utc(resumeTime.time).isAfter(suspendEnd)
              );
            });
          });

          return !isResumed;
        }
        return false;
      });
    });

    if (isSuspended) {
      return errorResponse(
        res,
        new Error(CanNotUpdateStatusDuringSuspend),
        StatusIsSuspendedForThisDate,
        statusCodes.VALIDATION_ERROR,
      );
    }

    const parsedStartDate = pauseStartDate
      ? moment.utc(pauseStartDate, 'DD/MM/YYYY', true)
      : null;
    const parsedEndDate = pauseEndDate
      ? moment.utc(pauseEndDate, 'DD/MM/YYYY', true)
      : null;

    if (resume === true) {
      const cycleStatus = await CycleStatusModel.findOne({ userId, cycleId });
      if (!cycleStatus) {
        return errorResponse(
          res,
          new Error(NotFoundErrorMessage),
          MenstruationCycleNotFound,
          statusCodes.NOT_FOUND,
        );
      }

      const activePause = cycleStatus.statuses.find((status) =>
        status.times.some(
          (timeEntry) =>
            timeEntry.status === 'paused' &&
            (!timeEntry.pauseEndDate ||
              moment
                .utc()
                .isBetween(
                  moment.utc(timeEntry.pauseStartDate),
                  moment.utc(timeEntry.pauseEndDate) || moment.utc(),
                  'day',
                  '[]',
                )),
        ),
      );

      if (!activePause) {
        return errorResponse(
          res,
          new Error(ValidationErrorMessage),
          NoActivePauseFound,
          statusCodes.SUCCESS,
        );
      }

      activePause.times.forEach((timeEntry) => {
        if (timeEntry.status === 'paused') {
          timeEntry.status = 'resumed';
          timeEntry.pauseEndDate = moment.utc().toDate();
        }
      });

      await cycleStatus.save();

      return successResponse(
        res,
        {
          id: cycleId,
          resume: {
            date: moment.utc().local().format('DD/MM/YYYY'),
            times: activePause.times.map((t) => ({
              time: moment.utc(t.time, 'HH:mm').format('HH:mm'),
              status: t.status,
              pauseStartDate: moment
                .utc(t.pauseStartDate)
                .local()
                .format('DD/MM/YYYY'),
              pauseEndDate: t.pauseEndDate
                ? moment.utc(t.pauseEndDate).local().format('DD/MM/YYYY')
                : null,
              pauseReason: t.pauseReason,
              id: t._id,
            })),
          },
        },
        MenstruationCycleResumeSucessfully,
        statusCodes.SUCCESS,
      );
    }

    if (parsedStartDate) {
      let cycleStatus = await CycleStatusModel.findOne({ userId, cycleId });
      if (!cycleStatus) {
        cycleStatus = new CycleStatusModel({
          userId,
          cycleId,
          statuses: [],
        });
      }

      const overlappingPause = cycleStatus.statuses.find((status) =>
        status.times.some((timeEntry) => {
          const pauseStart = moment.utc(timeEntry.pauseStartDate);
          const pauseEnd = timeEntry.pauseEndDate
            ? moment.utc(timeEntry.pauseEndDate)
            : moment.utc();

          return (
            timeEntry.status === 'paused' &&
            parsedStartDate.isBetween(pauseStart, pauseEnd, 'day', '[]')
          );
        }),
      );

      if (overlappingPause) {
        return errorResponse(
          res,
          new Error(ValidationErrorMessage),
          PauseIsAlreadyExists,
          statusCodes.VALIDATION_ERROR,
        );
      }

      cycleStatus.statuses.push({
        date: new Date(),
        times: [
          {
            time: moment.utc().local().format('HH:mm'),
            status: 'paused',
            pauseStartDate: parsedStartDate.toDate(),
            pauseEndDate: parsedEndDate ? parsedEndDate.toDate() : null,
            pauseReason: pauseReason,
          },
        ],
      });

      await cycleStatus.save();

      const lastStatus = cycleStatus.statuses[cycleStatus.statuses.length - 1];
      const localTime = moment
        .utc(lastStatus.times[0].time, 'HH:mm')
        .format('HH:mm');
      const formattedPauseStartDate = moment
        .utc(lastStatus.times[0].pauseStartDate)
        .local()
        .format('DD/MM/YYYY');
      const formattedPauseEndDate = lastStatus.times[0].pauseEndDate
        ? moment
          .utc(lastStatus.times[0].pauseEndDate)
          .local()
          .format('DD/MM/YYYY')
        : null;

      return successResponse(
        res,
        {
          id: cycleId,
          pause: {
            date: moment.utc(lastStatus.date).local().format('DD/MM/YYYY'),
            times: [
              {
                time: localTime,
                status: lastStatus.times[0].status,
                pauseStartDate: formattedPauseStartDate,
                pauseEndDate: formattedPauseEndDate,
                pauseReason: lastStatus.times[0].pauseReason,
                id: lastStatus.times[0]._id,
              },
            ],
          },
        },
        CyclePauseSucessfully,
        statusCodes.SUCCESS,
      );
    }

    return errorResponse(
      res,
      new Error(ValidationErrorMessage),
      InvalidRequestPauseResume,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Update pause resumecycle status error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const getUpcomingCycle = async (req, res) => {
  try {
    const userId = req.user.userId;

    const user = await checkUserExists(userId, res);
    if (!user) return;

    const cycle = await CycleModel.findOne({ userId }).sort({
      menstruationStartDate: -1,
    });

    if (!cycle) {
      return successResponse(
        res,
        {},
        MenstruationCycleNotFound,
        statusCodes.SUCCESS,
      );
    }

    const startDate = moment(cycle.menstruationStartDate).format('DD/MM/YYYY');
    const endDate = moment.utc().format('DD/MM/YYYY');

    const { timeWiseStatuses } = await calculateAdherenceCycle(
      cycle._id,
      userId,
      startDate,
      endDate,
    );

    const filteredTimeWiseStatuses = timeWiseStatuses?.some(
      (status) =>
        status.activeStartDate !== null ||
        status.activeTime !== null ||
        status.cycleDuration !== null ||
        status.completedDate !== null,
    )
      ? timeWiseStatuses
      : [];

    const cycleStatusRecord = await CycleStatusModel.findOne({
      userId,
      cycleId: cycle._id,
    });

    let upcomingCycleDate = null;

    if (cycleStatusRecord?.statuses?.length > 0) {
      const activeStatuses = cycleStatusRecord.statuses.filter((entry) =>
        entry?.times?.some((timeEntry) => timeEntry.status === 'active'),
      );

      if (activeStatuses.length > 0) {
        const lastActiveStatus = activeStatuses[activeStatuses.length - 1];
        const lastActiveDate = moment.utc(lastActiveStatus.date);

        if (lastActiveDate.isValid() && cycle.cycleLength) {
          upcomingCycleDate = lastActiveDate
            .clone()
            .add(cycle.cycleLength + 1, 'days')
            .format('DD/MM/YYYY');
        }
      }
    }

    if (
      !upcomingCycleDate &&
      cycle.menstruationStartDate &&
      cycle.cycleLength
    ) {
      upcomingCycleDate = moment(cycle.menstruationStartDate)
        .clone()
        .add(cycle.cycleLength, 'days')
        .format('DD/MM/YYYY');
    }

    const formattedCycle = {
      id: cycle._id,
      userId: userId,
      cycleLength: cycle.cycleLength,
      menstruationLength: cycle.menstruationLength,
      menstruationStartDate: moment(cycle.menstruationStartDate).format(
        'DD/MM/YYYY',
      ),
      time: cycle.time,
      scheduleDayBefore: cycle.scheduleDayBefore,
      message: cycle.message,
      autoCompleted: cycle.autoCompleted,
      completedDays: cycle.completedDays,
      timeWiseStatuses: filteredTimeWiseStatuses,
      upcomingCycleDate: upcomingCycleDate ? upcomingCycleDate : '',
    };

    return successResponse(
      res,
      formattedCycle,
      MenstruationCycleGetSucessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Error in getUpcomingCycle API: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};
