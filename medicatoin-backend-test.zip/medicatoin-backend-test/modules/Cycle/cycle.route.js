import { isAuthenticateUser } from '#root/middleware/validateTokenHandler.js';
import { verifyToken } from '#root/middleware/verifyTokenHandler.js';
import express from 'express';
import { addCycle, deleteCycle, getCycle, getUpcomingCycle, pauseResumeCycleStatus, updateCycle, updateCycleStatus} from './cycle.controller.js';


const cycleRoute = express.Router();


cycleRoute
  .route('/add-menstruation-cycle')
  .post(isAuthenticateUser, verifyToken, addCycle);
cycleRoute
  .route('/delete-menstruation-cycle/:id')
  .delete(isAuthenticateUser, verifyToken, deleteCycle);
cycleRoute
  .route('/update-menstruation-cycle/:id')
  .put(isAuthenticateUser, verifyToken, updateCycle);
cycleRoute
  .route('/get-menstruation-cycle/:id')
  .get(isAuthenticateUser, verifyToken, getCycle );
cycleRoute
  .route('/pause-resume-cycle-status/:id')
  .post(isAuthenticateUser, verifyToken, pauseResumeCycleStatus);
cycleRoute
  .route('/update-cycle-status/:id')
  .post(isAuthenticateUser, verifyToken, updateCycleStatus);
cycleRoute
  .route('/get-upcoming-cycle')
  .get(isAuthenticateUser, verifyToken, getUpcomingCycle)

  

export default cycleRoute;
