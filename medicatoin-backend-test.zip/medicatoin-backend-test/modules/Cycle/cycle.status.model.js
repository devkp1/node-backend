import { CycleModelSchema, CycleStatusModelSchema, UserModelSchema } from '#root/constants/modelNameConstants.js';
import { cycleStatus } from '#root/enums/cycleEnum.js';
import mongoose from 'mongoose';

const CycleStatusSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: UserModelSchema,
    required: true,
  },
  cycleId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: CycleModelSchema,
    required: true,
  },
  statuses: [
    {
      date: {
        type: Date,
        required: true,
      },
      times: [
        {
          time: {
            type: String,
            required: true,
          },
          status: {
            type: String,
            enum: cycleStatus,
            required: true,
          },
          cycleDuration: {
            type: Number,
            default: 0,
          },
          pauseStartDate: {
            type: Date,
          },
          pauseEndDate: {
            type: Date,
          },
          pauseReason: {
            type: String,
            default: '',
          }
        },
      ],
    },
  ],
  createdAt: {
    type: Date,
    default: Date.now,
  },
});



const CycleStatusModel = mongoose.model(
  CycleStatusModelSchema,
  CycleStatusSchema,
);

export default CycleStatusModel;
