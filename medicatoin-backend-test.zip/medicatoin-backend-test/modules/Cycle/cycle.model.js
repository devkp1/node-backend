import {
  CycleModelSchema,
  UserModelSchema,
} from '#root/constants/modelNameConstants.js';
import { validateTimeFormat } from '#root/constants/regexConstants.js';
import { setSchedule } from '#root/enums/cycleEnum.js';
import mongoose, { Schema } from 'mongoose';

const cycleSchema = new Schema(
  {
    cycleLength: {
      type: Number,
      default: 30,

    },
    menstruationLength: {
      type: Number,
      default: 5,
  
    },
    menstruationStartDate: {
      type: Date,
      required: true,
    },
    time: {
      type: String,
      validate: {
        validator: validateTimeFormat,
        message: validateTimeFormat,
      },
    },
    scheduleDayBefore: {
      type: String,
      enum: Object.values(setSchedule),
      default: '1 day before',
    },
    message: {
      type: String,
    },
    autoCompleted: {
      type: Boolean,
      default: true,
    },
    completedDays :{
      type: Number,
      default : 7
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: UserModelSchema,
    },
  },
  {
    timestamps: true,
  },
);

const CycleModel = mongoose.model(CycleModelSchema, cycleSchema);

export default CycleModel;
