import {
  CitiesNotFoundMessage,
  NotFoundErrorMessage,
  ServerErrorMessage,
  CityEmptyParameterMessage,
  ValidationErrorMessage,
  StateNotFoundMessage,
  CountriesNotFoundMessage,
} from '#constants/errorMessages.js';
import { CityGetSuccessfully } from '#constants/responseMessages.js';
import logger from '../../../logger.js';
import City from '../Models/cityModel.js';
import State from '../Models/stateModel.js';
import Country from '../Models/countryModel.js';
import { statusCodes } from '#constants/statusCodeMessages.js';
import { errorResponse, successResponse } from '#utils/responseHandler.js';

export const getCitiesByStateCode = async (req, res) => {
  try {
    const { countryCode, stateCode } = req.query;

    if (!countryCode || !stateCode) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        CityEmptyParameterMessage,
        statusCodes.VALIDATION_ERROR,
      );
    }

    const normalizedCountryCode = countryCode.toUpperCase();
    const normalizedStateCode = stateCode.toUpperCase();

    const state = await State.findOne({ isoCode: normalizedStateCode });
    if (!state) {
      logger.error(`State with code ${normalizedStateCode} not found`);
      return successResponse(
        res,
        [],
        StateNotFoundMessage,
        statusCodes.SUCCESS,
      );
    }

    const country = await Country.findOne({ isoCode: normalizedCountryCode });
    if (!country) {
      logger.error(`Country with code ${normalizedCountryCode} not found`);
      return successResponse(
        res,
        [],
        CountriesNotFoundMessage,
        statusCodes.SUCCESS,
      );
    }

    const cities = await City.find({
      stateCode: normalizedStateCode,
      countryCode: normalizedCountryCode,
    })
      .populate('stateId', 'isoCode')
      .populate('countryId', 'isoCode');

    if (cities.length === 0) {
      return successResponse(
        res,
        new Error(NotFoundErrorMessage),
        CitiesNotFoundMessage,
        statusCodes.SUCCESS,
      );
    }

    const stateDetails = {
      id: state._id,
      isoCode: state.isoCode,
    };

    const countryDetails = {
      id: country._id,
      isoCode: country.isoCode,
    };

    const formattedCities = cities.map((city) => ({
      id: city._id,
      name: city.name,
    }));

    const responsePayload = {
      country: countryDetails,
      state: stateDetails,
      cities: formattedCities,
    };

    return successResponse(
      res,
      responsePayload,
      CityGetSuccessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Location error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};
