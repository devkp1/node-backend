import {
  PostalCodeNotFoundMessage,
  ServerErrorMessage,
} from '#constants/errorMessages.js';
import { PostalCodeGetSuccessfully } from '#constants/responseMessages.js';
import { statusCodes } from '#constants/statusCodeMessages.js';
import { errorResponse, successResponse } from '#utils/responseHandler.js';
import logger from '../../../logger.js';
import City from '../Models/cityModel.js';

export const getPostalCodeByLocation = async (req, res) => {
  try {
    const postalCode = await City.findById(req.params.id);

    if (!postalCode) {
      return successResponse(
        res,
        [],
        PostalCodeNotFoundMessage,
        statusCodes.SUCCESS,
      );
    }

    const formattedPostalCodes = postalCode.postalCode.map((code) => ({
      postalCode: code,
    }));

    return successResponse(
      res,
      formattedPostalCodes,
      PostalCodeGetSuccessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`City ID error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};
