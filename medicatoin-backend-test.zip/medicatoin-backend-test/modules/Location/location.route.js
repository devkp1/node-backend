import express from 'express';
import { getAllCountries } from './Controller/countryController.js';
import { getStatesByCountryCode } from './Controller/stateController.js';
import { getCitiesByStateCode } from './Controller/cityController.js';
import { getPostalCodeByLocation } from './Controller/postalCodeController.js';
import { isAuthenticateUser } from '#middleware/validateTokenHandler.js';
import { verifyToken } from '#middleware/verifyTokenHandler.js';

const locationRoute = express.Router();

locationRoute
  .route('/get-country')
  .get(isAuthenticateUser, verifyToken, getAllCountries);
locationRoute
  .route('/get-state')
  .get(isAuthenticateUser, verifyToken, getStatesByCountryCode);
locationRoute
  .route('/get-city')
  .get(isAuthenticateUser, verifyToken, getCitiesByStateCode);
locationRoute
  .route('/get-postal-code/:id')
  .get(isAuthenticateUser, verifyToken, getPostalCodeByLocation);
export default locationRoute;
