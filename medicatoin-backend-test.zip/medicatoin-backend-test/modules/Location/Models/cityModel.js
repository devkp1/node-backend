import mongoose, { Schema } from 'mongoose';
import {
  CityModelSchema,
  CountryModelSchema,
  StateModelSchema,
} from '../../../constants/modelNameConstants.js';

const citySchema = new Schema({
  name: { type: String, required: true },
  stateCode: { type: String, required: true },
  countryCode: { type: String, required: true },
  countryId: { type: mongoose.Schema.Types.ObjectId, ref: CountryModelSchema },
  stateId: { type: mongoose.Schema.Types.ObjectId, ref: StateModelSchema },
  postalCode: [{ type: String }],
});

const City = mongoose.model(CityModelSchema, citySchema);

export default City;
