import {
  TreatmentModelSchema,
  UserModelSchema,
} from '#root/constants/modelNameConstants.js';
import { validateTimeFormat } from '#root/constants/regexConstants.js';
import {
  treatmemtFrequency,
  treatmentFrequencyTime,
} from '#root/enums/treatmentEnum.js';
import mongoose, { Schema } from 'mongoose';

export const validDays = treatmemtFrequency.Custom;

const treatmentSchema = new mongoose.Schema(
  {
    treatmentName: {
      type: String,
      required: true,
    },
    startDate: {
      type: Date,
      required: true,
    },
    endDate: {
      type: Date,
      required: true,
    },
    frequency: {
      type: Schema.Types.Mixed,
      required: true,
    },
    timeFrequency: {
      type: String,
      enum: Object.keys(treatmentFrequencyTime),
      required: true,
    },
    times: {
      type: [String],
      required: true,
      validate: {
        validator: function (value) {
          const frequency = this.frequency;
          const expectedTimes = treatmentFrequencyTime[frequency];
          const isValidFormat = value.every((time) => validateTimeFormat(time));
          return expectedTimes
            ? isValidFormat && value.length === expectedTimes
            : isValidFormat;
        },
        message: function () {
          const frequency = this.frequency;
          const expectedTimes = treatmentFrequencyTime[frequency];
          return expectedTimes
            ? `The selected frequency requires exactly ${expectedTimes} time(s) in HH:MM format.`
            : 'Invalid frequency or time format.';
        },
      },
    },
    numberOfSessions: {
      type: Number,
      required: true,
    },
    notes: {
      type: String,
      required: false,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: UserModelSchema,
    },
    statusId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: TreatmentModelSchema,
    },
  },
  {
    timestamps: true,
  },
);

const TreatmentModel = mongoose.model(TreatmentModelSchema, treatmentSchema);

export default TreatmentModel;
