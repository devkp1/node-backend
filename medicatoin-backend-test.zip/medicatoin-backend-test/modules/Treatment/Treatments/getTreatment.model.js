import { GetTreatmentModelSchema } from '#root/constants/modelNameConstants.js';
import mongoose from 'mongoose';

const GetTreatmentschema = new mongoose.Schema({
  treatmentName: {
    type: String,
    required: true,
    unique: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

const GetTreatmentModel = mongoose.model(
  GetTreatmentModelSchema,
  GetTreatmentschema,
);

export default GetTreatmentModel;
