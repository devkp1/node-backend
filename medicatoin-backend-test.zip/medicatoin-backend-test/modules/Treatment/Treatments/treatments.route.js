import express from 'express';

import { getTreatment, insertTreatments, recomendedTreatment } from './treatments.controller.js';

const treatmemtsRoute = express.Router();

treatmemtsRoute.route('/search-treatment').get(getTreatment);
treatmemtsRoute.route('/recomended-treatment').get(recomendedTreatment);
treatmemtsRoute.route('/sync-treatment').post(insertTreatments);

export default treatmemtsRoute;
