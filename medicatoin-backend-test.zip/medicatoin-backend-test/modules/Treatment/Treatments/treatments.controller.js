import {
  ServerErrorMessage,
  TreatmentAlreadyExistsInDatabse,
} from '#root/constants/errorMessages.js';
import {
  TreatmenteNotFound,
  TreatmentInsertSucessfully,
  TreatmentSearchSuccessMessage,
} from '#root/constants/responseMessages.js';
import { statusCodes } from '#root/constants/statusCodeMessages.js';
import logger from '#root/logger.js';
import { errorResponse, successResponse } from '#root/utils/responseHandler.js';
import GetTreatmentModel from './getTreatment.model.js';

export const getTreatment = async (req, res) => {
  try {
    const { query } = req;
    const searchquery = query.name || '';

    const startsWithQuery = await GetTreatmentModel.find({
      treatmentName: { $regex: `^${searchquery}`, $options: 'i' },
    });

    const containsQuery = await GetTreatmentModel.find({
      treatmentName: {
        $regex: searchquery,
        $options: 'i',
        $not: { $regex: `^${searchquery}`, $options: 'i' },
      },
    });

    const treatments = [...startsWithQuery, ...containsQuery];

    if (treatments.length === 0) {
      return successResponse(res, [], TreatmenteNotFound, statusCodes.SUCCESS);
    }

    const formatedMedicines = treatments.map((treatmemt) => ({
      id: treatmemt.id,
      name: treatmemt.treatmentName,
    }));

    return successResponse(
      res,
      formatedMedicines,
      TreatmentSearchSuccessMessage,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Treatment search error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

const response = [
  { name: 'Diabetes' },
  { name: 'Lipid Profile' },
  { name: 'Blood Pressure' },
  { name: 'Thyroid' },
  { name: 'Cancer' },
];

export const insertTreatments = async (req, res) => {
  try {
    const formattedMedications = response.map((med) => ({
      treatmentName: med.name,
    }));

    const result = await GetTreatmentModel.insertMany(formattedMedications, {
      ordered: false,
    });

    logger.info(`Successfully inserted ${result.length} treatments.`);
    return successResponse(
      res,
      { insertedCount: result.length },
      TreatmentInsertSucessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    if (error.name === 'BulkWriteError') {
      logger.warn(TreatmentAlreadyExistsInDatabse);
      return errorResponse(
        res,
        TreatmentAlreadyExistsInDatabse,
        ServerErrorMessage,
        statusCodes.SUCCESS,
      );
    }
    logger.error(`Error inserting medications: ${error.message}`);
    return errorResponse(
      res,
      error.message,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const recomendedTreatment = async (req, res) => {
  try {
    const treatments = [
      { _id: '6798a95264bf40bf41bdcb4e', treatmentName: 'Diabetes' },
      { _id: '6798a95264bf40bf41bdcb4f', treatmentName: 'Lipid Profile' },
      { _id: '6798a95264bf40bf41bdcb50', treatmentName: 'Blood Pressure' },
      { _id: '6798a95264bf40bf41bdcb51', treatmentName: 'Thyroid' },
      { _id: '6798a95264bf40bf41bdcb52', treatmentName: 'Cancer' },
    ];

    const { name = '', id = '' } = req.query;

    let filteredTreatments = treatments;

    if (id) {
      filteredTreatments = treatments.filter(
        (treatment) => treatment._id === id,
      );
    } else if (name) {
      const lowerCaseName = name.toLowerCase();
      filteredTreatments = treatments.filter((treatment) =>
        treatment.treatmentName.toLowerCase().includes(lowerCaseName),
      );

      filteredTreatments.sort((a, b) => {
        const aName = a.treatmentName.toLowerCase();
        const bName = b.treatmentName.toLowerCase();
        if (
          aName.startsWith(lowerCaseName) &&
          !bName.startsWith(lowerCaseName)
        ) {
          return -1;
        }
        if (
          !aName.startsWith(lowerCaseName) &&
          bName.startsWith(lowerCaseName)
        ) {
          return 1;
        }
        return 0;
      });
    }

    return res.status(200).json({
      success: true,
      data: filteredTreatments,
      message:
        filteredTreatments.length > 0
          ? 'Treatment search successful'
          : 'No treatments found',
    });
  } catch (error) {
    logger.error(`Error fetching treatments: ${error.message}`);
    return errorResponse(
      res,
      error.message,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};
