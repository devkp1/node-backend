import express from 'express';
import {
  addTreatment,
  deleteTreatmentById,
  getTreatmentById,
  updateTreatment,
} from './treatment.controller.js';
import { isAuthenticateUser } from '#root/middleware/validateTokenHandler.js';
import { verifyToken } from '#root/middleware/verifyTokenHandler.js';

const treatmemtRoute = express.Router();

treatmemtRoute
  .route('/treatment')
  .post(isAuthenticateUser, verifyToken, addTreatment);
treatmemtRoute
  .route('/update-treatment/:id')
  .put(isAuthenticateUser, verifyToken, updateTreatment);
treatmemtRoute
  .route('/get-treatment/:id')
  .get(isAuthenticateUser, verifyToken, getTreatmentById);
treatmemtRoute
  .route('/delete-treatment/:id')
  .delete(isAuthenticateUser, verifyToken, deleteTreatmentById);

export default treatmemtRoute;
