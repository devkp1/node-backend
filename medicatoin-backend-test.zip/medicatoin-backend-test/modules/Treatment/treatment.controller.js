import logger from '#root/logger.js';
import {
  TreatmentCreationSuccessMessage,
  TreatmentDeletedSuccessfully,
  TreatmentDetailGetSucessfully,
  TreatmentNotFoundMessage,
  TreatmentUpdateSuccessMessage,
} from '#root/constants/responseMessages.js';
import {
  NotFoundErrorMessage,
  ServerErrorMessage,
  sessionsValidationMessage,
  ValidationErrorMessage,
} from '#root/constants/errorMessages.js';
import { errorResponse, successResponse } from '#root/utils/responseHandler.js';
import { statusCodes } from '#root/constants/statusCodeMessages.js';
import TreatmentModel from './treatment.model.js';
import moment from 'moment';
import { validateCommonData } from '#root/validators/treatment.validation.js';
import { checkUserExists } from '#root/utils/checkUserExists.js';
import { calculateAdherenceTreatment } from '#root/utils/calculateAdherence.js';
import { addformatTreatmentData } from '#root/utils/formatted.response.js';
import { sendMedicationNotification } from '#root/utils/sendMedicationNotification.js';
import { TreatmentAddedNotification, TreatmentUpdatedNotification } from '#root/constants/notificationMessages.js';



export const addTreatment = async (req, res) => {
  try {
    const userId = req.user.userId;

    const validationResult = validateCommonData({ ...req.body, userId });

    if (!validationResult.valid) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        validationResult.error,
        statusCodes.VALIDATION_ERROR,
      );
    }

    const { times, treatmentName,...otherData } = validationResult.data;

    const sortedTimes = times.slice().sort((a, b) => {
      const [aHour, aMinute] = a.split(':').map(Number);
      const [bHour, bMinute] = b.split(':').map(Number);
      return aHour - bHour || aMinute - bMinute;
    });

    const treatmemtData = {
      ...otherData,
      times: sortedTimes,
      treatmentName :treatmentName
    };

    const treatment = await TreatmentModel.create(treatmemtData);

    const formattedTreatment = addformatTreatmentData(treatment);

    const message = TreatmentAddedNotification(treatmentName, treatment._id);
    await sendMedicationNotification(userId, message);


    return successResponse(
      res,
      formattedTreatment,
      TreatmentCreationSuccessMessage,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Treatment creation error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};
export const updateTreatment = async (req, res) => {
  try {
    const userId = req.user.userId;
    const treatmentId = req.params.id;

    const existingTreatment = await TreatmentModel.findById(treatmentId);

    if (!existingTreatment) {
      return errorResponse(
        res,
        new Error(NotFoundErrorMessage),
        TreatmentNotFoundMessage,
        statusCodes.NOT_FOUND,
      );
    }

    const updatedData = {
      treatmentName: req.body.treatmentName || existingTreatment.treatmentName,
      startDate:
        req.body.startDate ||
        moment.utc(existingTreatment.startDate).format('DD/MM/YYYY'),
      endDate:
        req.body.endDate ||
        moment.utc(existingTreatment.endDate).format('DD/MM/YYYY'),
      frequency: req.body.frequency || existingTreatment.frequency,
      timeFrequency: req.body.timeFrequency || existingTreatment.timeFrequency,
      times: req.body.times || existingTreatment.times,
      numberOfSessions:
        req.body.numberOfSessions || existingTreatment.numberOfSessions,
      notes: req.body.notes || existingTreatment.notes,
      userId: req.user.userId,
    };

    if (
      req.body.numberOfSessions !== undefined &&
      req.body.numberOfSessions <= 0
    ) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        sessionsValidationMessage,
        statusCodes.VALIDATION_ERROR,
      );
    }

    const validationResult = validateCommonData(updatedData);

    if (!validationResult.valid) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        validationResult.error,
        statusCodes.VALIDATION_ERROR,
      );
    }
    // eslint-disable-next-line
    let { times, ...otherData } = validationResult.data;

    if (times) {
      const sortedTimes = times.slice().sort((a, b) => {
        const [aHour, aMinute] = a.split(':').map(Number);
        const [bHour, bMinute] = b.split(':').map(Number);
        return aHour - bHour || aMinute - bMinute;
      });
      otherData = { ...otherData, times: sortedTimes };
    }

    otherData.treatmentName = validationResult.data.treatmentName;

    const treatment = await TreatmentModel.findByIdAndUpdate(
      treatmentId,
      otherData,
      {
        new: true,
        runValidators: true,
        useFindAndModify: false,
      },
    );

    const formattedTreatment = addformatTreatmentData(treatment);

    const message = TreatmentUpdatedNotification(
      treatment.treatmentName,  
      treatment._id
    );
    await sendMedicationNotification(userId, message);

    return successResponse(
      res,
      formattedTreatment,
      TreatmentUpdateSuccessMessage,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Error in updateTreatment: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const getTreatmentById = async (req, res) => {
  try {
    const treatmemtId = req.params.id;
    const userId = req.user.userId;

    const user = await checkUserExists(userId, res);
    if (!user) return;

    const treatment = await TreatmentModel.findOne({
      _id: treatmemtId,
      userId,
    });

    if (!treatment) {
      return successResponse(
        res,
        new Error(TreatmentNotFoundMessage),
        TreatmentNotFoundMessage,
        statusCodes.SUCCESS,
      );
    }
    const startDate = moment.utc(treatment.startDate).format('DD/MM/YYYY');
    const endDate = moment.utc(treatment.endDate).format('DD/MM/YYYY');

    const {
      adherencePercentage,
      timeWiseStatuses,
      totalTreatmentCount,
      completedTreatmentCount,
    } = await calculateAdherenceTreatment(
      treatment,
      userId,
      startDate,
      endDate,
    );

    const formattedTreatment = addformatTreatmentData(
      treatment,
      adherencePercentage,
      timeWiseStatuses,
      totalTreatmentCount,
      completedTreatmentCount,
    );

    return successResponse(
      res,
      formattedTreatment,
      TreatmentDetailGetSucessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Error in getTreatmentById: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const deleteTreatmentById = async (req, res) => {
  try {
    const treatmentId = req.params.id;
    const userId = req.user.userId;

    const user = await checkUserExists(userId, res);
    if (!user) return;

    let existingTreatment = await TreatmentModel.findById(treatmentId);

    if (!existingTreatment) {
      return successResponse(
        res,
        [],
        TreatmentNotFoundMessage,
        statusCodes.SUCCESS,
      );
    }

    existingTreatment = await TreatmentModel.findByIdAndDelete(treatmentId);
    return successResponse(
      res,
      undefined,
      TreatmentDeletedSuccessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Delete treatment error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};
