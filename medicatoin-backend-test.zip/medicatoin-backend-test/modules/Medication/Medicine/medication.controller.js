import {
  CanNotUpdateStatusDuringPause,
  CanNotUpdateStatusDuringSuspend,
  DateOutOfRangeMessage,
  DateRequired,
  InvalidDateFormat,
  InvalidDateRange,
  InvalidReminderType,
  InvalidRequest,
  InvalidStatus,
  InvalidTimeMessage,
  MedicationAlreadyPausedMessage,
  MedicationCanNotPausedMessage,
  MedicationNotFound,
  MedicationTreatmentAlredySuspend,
  NoActivePauseForProvidedResumeDate,
  NoActiveSuspendForResumeDate,
  NoDataFoundForSpecifiedReminder,
  NoRecordsFoundForSuspend,
  NotFoundErrorMessage,
  PauseStartDateIsGreathenEndDate,
  PauseStartDateRequired,
  RecordNotFoundMessage,
  ResumeDateNotFound,
  ServerErrorMessage,
  StartDateGreterthenEndDateMessage,
  StatusIsPausedForThisDate,
  StatusIsSuspendedForThisDate,
  StatusUpdatedSucessfullMesssage,
  SuspendApplied,
  SuspendDaysEligibleLength,
  SuspendDaysFieldrequired,
  SuspendedDaysNotBeProvidedWhenResuming,
  TimeRequired,
  ValidDateFormat,
  ValidationErrorMessage,
} from '#constants/errorMessages.js';
import {
  MedicationDeleteSucessfully,
  MedicationDetailGetSucessfully,
  MedicationTreatmentSuspendSucessfully,
  MedicationUpdateSucessfully,
  MedicineAddSucessfully,
  StatusResumedSuccessfully,
  StatuspauseSucessfully,
  SuspendedRecordsresumedSucessfully,
} from '#constants/responseMessages.js';
import { statusCodes } from '#constants/statusCodeMessages.js';
import { errorResponse, successResponse } from '#utils/responseHandler.js';
import MedicationModel from './medication.model.js';
import {
  UpdatevalidateMedicationData,
  validateMedicationData,
} from '#root/validators/medication.validation.js';
import TreatmentModel from '#root/modules/Treatment/treatment.model.js';
import { checkUserExists } from '#root/utils/checkUserExists.js';
import moment from 'moment';
import logger from '#root/logger.js';
import MedicationStatusModel from './medication.status.model.js';
import TreatmentStatusModel from '#root/modules/Treatment/treatment.status.model.js';
import {
  medicationFoodTime,
  medicationFrequency,
  medicationStatuses,
  medicationTimeFrequency,
  medicationType,
} from '#root/enums/medicationEnum.js';
import {
  calculateActiveStatus,
  calculateAdherence,
  calculateAdherenceForPauseSuspend,
  calculateAdherenceMedication,
} from '#root/utils/calculateAdherence.js';
import {
  addFormatMedicationData,
  formatCycleData,
  formatMedicationData,
  formatPauseSuspendCycleData,
  formatPauseSuspendMedicationData,
  formatPauseSuspendTreatmentData,
  formatTreatmentData,
} from '#root/utils/formatted.response.js';
import { validateFilter } from '#root/utils/checkAllowedFeilds.js';
import CycleModel from '#root/modules/Cycle/cycle.model.js';
import CycleStatusModel from '#root/modules/Cycle/cycle.status.model.js';
import {
  MedicationAddedNotification,
  MedicationUpdatedNotification,
} from '#root/constants/notificationMessages.js';
import { sendMedicationNotification } from '#root/utils/sendMedicationNotification.js';
import { setupMedicationAndTreatmentEndReminderCron } from '#root/Cron/expirationMedicationTreatmentCron.js';
import { setupMorningMedicationReminderCron } from '#root/Cron/morningMedicationTreatmentCron.js';

export const addMedication = async (req, res) => {
  try {
    const userId = req.user.userId;

    const validationResult = validateMedicationData({ ...req.body, userId });

    if (!validationResult.valid) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        validationResult.error,
        statusCodes.SUCCESS,
      );
    }

    const { times, numberOfCapsule, medicationName, ...otherData } =
      validationResult.data;

    const sortedTimes = times.slice().sort((a, b) => {
      const [aHour, aMinute] = a.split(':').map(Number);
      const [bHour, bMinute] = b.split(':').map(Number);
      return aHour - bHour || aMinute - bMinute;
    });

    const sortedNumberOfCapsule = sortedTimes.map((time) => {
      const index = times.indexOf(time);
      return numberOfCapsule[index];
    });

    const medicationData = {
      ...otherData,
      times: sortedTimes,
      numberOfCapsule: sortedNumberOfCapsule,
      medicationName: medicationName,
    };

    const medication = await MedicationModel.create(medicationData);

    const formatMedication = addFormatMedicationData(medication);

    const message = MedicationAddedNotification(medicationName, medication._id);
    await sendMedicationNotification(userId, message);

    setupMedicationAndTreatmentEndReminderCron();
    setupMorningMedicationReminderCron();
    return successResponse(
      res,
      formatMedication,
      MedicineAddSucessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Medication add error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};


export const getMedicationList = async (req, res) => {
  try {
    const { reminderType, sort } = req.query;
    let {
      startDate,
      endDate,
      type,
      frequency,
      foodTime,
      timeFrequency,
      status,
    } = req.query;
    const userId = req.user.userId;

    const user = await checkUserExists(userId, res);
    if (!user) return;

    const isFemale = user.gender === 'Female';

    const validReminderTypes = isFemale
      ? ['medication', 'treatment', 'all', 'cycle']
      : ['medication', 'treatment', 'all'];

    if (!validReminderTypes.includes(reminderType)) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        InvalidReminderType,
        statusCodes.VALIDATION_ERROR,
      );
    }

    if (!startDate && !endDate) {
      startDate = moment().startOf('month').format('DD/MM/YYYY');
      endDate = moment().endOf('month').format('DD/MM/YYYY');
    }

    let dateFilter = {};
    if (startDate && endDate) {
      const start = moment(startDate, 'DD/MM/YYYY', true);
      const end = moment(endDate, 'DD/MM/YYYY', true);

      if (!start.isValid() || !end.isValid()) {
        return errorResponse(
          res,
          new Error(ValidationErrorMessage),
          InvalidDateFormat,
          statusCodes.VALIDATION_ERROR,
        );
      }

      if (start.isAfter(end)) {
        return errorResponse(
          res,
          new Error(ValidationErrorMessage),
          StartDateGreterthenEndDateMessage,
          statusCodes.VALIDATION_ERROR,
        );
      }

      dateFilter = {
        startDate: { $lte: end.endOf('day').toDate() },
        endDate: { $gte: start.startOf('day').toDate() },
      };
    }

    const isValid =
      validateFilter(type, Object.values(medicationType), 'Type', res) &&
      validateFilter(
        frequency,
        [...Object.values(medicationFrequency), ...medicationFrequency.custom],
        'Frequency',
        res,
      ) &&
      validateFilter(
        foodTime,
        Object.values(medicationFoodTime),
        'FoodTime',
        res,
      ) &&
      validateFilter(
        timeFrequency,
        Object.keys(medicationTimeFrequency),
        'TimeFrequency',
        res,
      ) &&
      validateFilter(status, Object.keys(medicationStatuses), 'Status', res);

    if (!isValid) return;

    const parseMultiValueFilter = (filter) =>
      filter
        ? Array.isArray(filter)
          ? filter.map((item) => item.trim())
          : filter.split(',').map((item) => item.trim())
        : undefined;

    type = parseMultiValueFilter(type);
    frequency = parseMultiValueFilter(frequency);
    foodTime = parseMultiValueFilter(foodTime);
    timeFrequency = parseMultiValueFilter(timeFrequency);
    status = parseMultiValueFilter(status)?.map(
      (stat) => medicationStatuses[stat] || stat,
    );

    const medicationFilters = {
      userId,
      ...dateFilter,
      ...(type && { type: { $in: type } }),
      ...(frequency && { frequency: { $in: frequency } }),
      ...(foodTime && { foodTime: { $in: foodTime } }),
      ...(timeFrequency && { timeFrequency: { $in: timeFrequency } }),
    };

    const treatmentFilters = {
      userId,
      ...dateFilter,
      ...(frequency && { frequency: { $in: frequency } }),
      ...(timeFrequency && { timeFrequency: { $in: timeFrequency } }),
    };

    if (frequency) {
      const customDays = medicationFrequency.custom;
      if (frequency.some((f) => customDays.includes(f))) {
        medicationFilters.$or = [
          { frequency: { $in: frequency } },
          { customFrequency: { $in: frequency } },
        ];
      } else {
        medicationFilters.frequency = { $in: frequency };
      }
    }

    const statusFilters = {
      userId,
      ...(status && { 'statuses.times.status': { $in: status } }),
    };

    let medicationStatusData = [];
    let treatmentStatusData = [];
    //eslint-disable-next-line
    const cycleData = [];

    if (status) {
      medicationStatusData = await MedicationStatusModel.find(statusFilters);
      treatmentStatusData = await TreatmentStatusModel.find(statusFilters);

      const medicationIds = medicationStatusData.map((s) => s.medicationId);
      const treatmentIds = treatmentStatusData.map((s) => s.treatmentId);

      medicationFilters._id = { $in: medicationIds };
      treatmentFilters._id = { $in: treatmentIds };
    }

    const sortOrder = sort === 'desc' ? -1 : 1;

    const [medicationData, treatmentData, cycleDataResult] = await Promise.all([
      reminderType === 'medication' || reminderType === 'all'
        ? MedicationModel.find(medicationFilters)
          .collation({ locale: 'en' })
          .sort({ medicationName: sortOrder })
        : [],
      reminderType === 'treatment' ||
      (reminderType === 'all' && !type && !foodTime)
        ? TreatmentModel.find(treatmentFilters)
          .collation({ locale: 'en' })
          .sort({ treatmentName: sortOrder })
        : [],
      isFemale && (reminderType === 'cycle' || reminderType === 'all')
        ? CycleModel.find({
          userId,
          menstruationStartDate: {
            $gte: moment(startDate, 'DD/MM/YYYY').startOf('day').toDate(),
            $lte: moment(endDate, 'DD/MM/YYYY').endOf('day').toDate(),
          },
        })
          .collation({ locale: 'en' })
          .sort({ menstruationStartDate: sortOrder })
        : [],
    ]);

    const formatData = async (data, type) => {
      return Promise.all(
        data.map(async (item) => {
          const { adherencePercentage, timeWiseStatuses, finishedRecord } =
            await calculateAdherence(item, type, userId, startDate, endDate);

          const filteredTimeWiseStatuses = status
            ? timeWiseStatuses.filter(
              (timeStatus) =>
                status.includes(timeStatus.status) ||
                  (status.includes('0') && timeStatus.status === ''),
            )
            : timeWiseStatuses;

          const { status: activeStatus, pauseEntries } =
            await calculateActiveStatus(item, type, userId, startDate, endDate);

          return type === 'medication'
            ? formatMedicationData(
              item,
              adherencePercentage,
              filteredTimeWiseStatuses,
              finishedRecord,
              activeStatus,
              pauseEntries,
            )
            : type === 'treatment'
              ? formatTreatmentData(
                item,
                adherencePercentage,
                filteredTimeWiseStatuses,
                finishedRecord,
                activeStatus,
                pauseEntries,
              )
              : formatCycleData(item, timeWiseStatuses);
        }),
      );
    };

    const medicationFields = await formatData(medicationData, 'medication');
    const treatmentFields = await formatData(treatmentData, 'treatment');
    const cycleFields = isFemale
      ? (
        await formatData(cycleDataResult, 'cycle')
      ).filter((cycle) => {
        const menstruationStartDate = moment(cycle.menstruationStartDate, 'DD/MM/YYYY');
        const start = moment(startDate, 'DD/MM/YYYY');
        const end = moment(endDate, 'DD/MM/YYYY');
  
      
        const isDateInRange = menstruationStartDate.isBetween(start, end, 'day', '[]');
        const hasTimeWiseStatuses = cycle.timeWiseStatuses && cycle.timeWiseStatuses.length > 0;
  
        return isDateInRange || hasTimeWiseStatuses;
      })
      : [];
  

    const calculateCombinedAdherence = (data) => {
      if (data.length === 0) return '0.00';
      const totalAdherence = data.reduce(
        (acc, item) => acc + parseFloat(item.adherencePercentage),
        0,
      );
      return (totalAdherence / data.length).toFixed(2);
    };

    const combinedAdherencePercentage = calculateCombinedAdherence([
      ...medicationFields,
      ...treatmentFields,
    ]);

    const mergeData = [
      ...[...medicationFields, ...treatmentFields].sort((a, b) => {
        const nameA =
          a.medicationName?.toLowerCase() ||
          a.treatmentName?.toLowerCase() ||
          '';
        const nameB =
          b.medicationName?.toLowerCase() ||
          b.treatmentName?.toLowerCase() ||
          '';

        return sort === 'desc'
          ? nameB.localeCompare(nameA)
          : nameA.localeCompare(nameB);
      }),
      ...cycleFields,
    ];

    const responseData = {
      data: mergeData,
      combinedAdherencePercentage: `${combinedAdherencePercentage}%`,
    };

    if (responseData.data.length === 0) {
      return successResponse(
        res,
        responseData,
        NoDataFoundForSpecifiedReminder,
        statusCodes.SUCCESS,
      );
    }

    return successResponse(
      res,
      responseData,
      MedicationDetailGetSucessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Get Medication List: ${error.message}`, {
      stack: error.stack,
      requestQuery: req.query,
      userId: req.user.userId,
    });
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const updateMedication = async (req, res) => {
  try {
    const medicationId = req.params.id;
    const userId = req.user.userId;

    const user = await checkUserExists(userId, res);
    if (!user) return;

    const validationResult = UpdatevalidateMedicationData({
      ...req.body,
      userId,
    });

    if (!validationResult.valid) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        validationResult.error,
        statusCodes.VALIDATION_ERROR,
      );
    }

    const { medicationName, times, numberOfCapsule, ...otherData } =
      validationResult.data;

    let sortedTimes = [];
    let sortedNumberOfCapsule = [];

    if (times && numberOfCapsule) {
      sortedTimes = times.slice().sort((a, b) => {
        const [aHour, aMinute] = a.split(':').map(Number);
        const [bHour, bMinute] = b.split(':').map(Number);
        return aHour - bHour || aMinute - bMinute;
      });

      sortedNumberOfCapsule = sortedTimes.map((time) => {
        const index = times.indexOf(time);
        return numberOfCapsule[index];
      });
    }

    const medicationData = {
      ...otherData,
      times: sortedTimes,
      numberOfCapsule: sortedNumberOfCapsule,
      medicationName: medicationName,
    };

    let medication = await MedicationModel.findOne({
      _id: medicationId,
      userId,
    });

    if (!medication) {
      return successResponse(
        res,
        new Error(MedicationNotFound),
        MedicationNotFound,
        statusCodes.SUCCESS,
      );
    }
    medication = await MedicationModel.findByIdAndUpdate(
      medicationId,
      medicationData,
      {
        new: true,
        runValidators: true,
        useFindAndModify: false,
      },
    );

    const formattedMedication = addFormatMedicationData(medication);

    const message = MedicationUpdatedNotification(
      medicationName,
      medication._id,
    );
    await sendMedicationNotification(userId, message);

    return successResponse(
      res,
      formattedMedication,
      MedicationUpdateSucessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Error in updateMedication: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const getMedicationById = async (req, res) => {
  try {
    const medicationId = req.params.id;
    const userId = req.user.userId;

    const user = await checkUserExists(userId, res);
    if (!user) return;

    const medication = await MedicationModel.findOne({
      _id: medicationId,
      userId,
    });

    if (!medication) {
      return successResponse(
        res,
        new Error(MedicationNotFound),
        MedicationNotFound,
        statusCodes.SUCCESS,
      );
    }

    const startDate = moment.utc(medication.startDate).format('DD/MM/YYYY');
    const endDate = moment.utc(medication.endDate).format('DD/MM/YYYY');

    const {
      adherencePercentage,
      timeWiseStatuses,
      totalMedicationCount,
      completedMedicationCount,
    } = await calculateAdherenceMedication(
      medication,
      userId,
      startDate,
      endDate,
    );

    const formattedMedication = addFormatMedicationData(
      medication,
      adherencePercentage,
      timeWiseStatuses,
      totalMedicationCount,
      completedMedicationCount,
    );

    return successResponse(
      res,
      formattedMedication,
      MedicationDetailGetSucessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Error in getMedicationById: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const updateStatus = async (req, res) => {
  try {
    const { date, time, status } = req.body;
    const userId = req.user.userId;
    const itemId = req.params.id;

    const user = await checkUserExists(userId, res);
    if (!user) return;

    if (
      typeof status !== 'number' ||
      status < 0 ||
      status == 1 ||
      status == 2 ||
      status == 5 ||
      status >= medicationStatuses.length
    ) {
      return errorResponse(
        res,
        new Error(InvalidStatus),
        `Invalid status: ${status}. Valid statuses are 0 3 4.`,
        statusCodes.VALIDATION_ERROR,
      );
    }

    const statusString = medicationStatuses[status];

    if (!date) {
      return errorResponse(
        res,
        new Error(DateRequired),
        DateRequired,
        statusCodes.SUCCESS,
      );
    }

    if (!time) {
      return errorResponse(
        res,
        new Error(TimeRequired),
        TimeRequired,
        statusCodes.SUCCESS,
      );
    }

    const parsedDate = moment.utc(date, 'DD/MM/YYYY', true);
    if (!parsedDate.isValid()) {
      return errorResponse(
        res,
        new Error(ValidDateFormat),
        InvalidDateFormat,
        statusCodes.SUCCESS,
      );
    }

    const isMedication = await MedicationModel.exists({ _id: itemId });
    const isTreatment = await TreatmentModel.exists({ _id: itemId });

    if (!isMedication && !isTreatment) {
      return errorResponse(
        res,
        new Error(NotFoundErrorMessage),
        RecordNotFoundMessage,
        statusCodes.SUCCESS,
      );
    }

    const statusModel = isMedication
      ? MedicationStatusModel
      : TreatmentStatusModel;
    const idField = isMedication ? 'medicationId' : 'treatmentId';
    const item = isMedication
      ? await MedicationModel.findById(itemId)
      : await TreatmentModel.findById(itemId);

    const startDate = moment.utc(item.startDate).startOf('day');
    const endDate = moment.utc(item.endDate).endOf('day');
    if (!parsedDate.isBetween(startDate, endDate, 'day', '[]')) {
      return errorResponse(
        res,
        new Error(
          `Record of Date ${parsedDate.format('DD/MM/YYYY')} is not found, Please verify.`,
        ),
        DateOutOfRangeMessage,
        statusCodes.SUCCESS,
      );
    }

    const timeArray = Array.isArray(time) ? time : [time];

    const validTimes = item.times.map((t) =>
      moment.utc(t, 'HH:mm').format('HH:mm'),
    );
    const providedTimes = timeArray.map((t) =>
      moment.utc(t, 'HH:mm').format('HH:mm'),
    );

    for (const providedTime of providedTimes) {
      if (!validTimes.includes(providedTime)) {
        return errorResponse(
          res,
          new Error(
            `Time ${providedTime} is not within the valid times for this medication`,
          ),
          InvalidTimeMessage,
          statusCodes.SUCCESS,
        );
      }
    }

    let itemStatus = await statusModel.findOne({ userId, [idField]: itemId });

    if (!itemStatus) {
      itemStatus = new statusModel({
        userId,
        [idField]: itemId,
        statuses: [],
      });
    }

    if (itemStatus) {
      const hasFinishedStatus = itemStatus.statuses.some((statusEntry) =>
        statusEntry.times.some((timeEntry) => timeEntry.status === 'finished'),
      );

      if (hasFinishedStatus) {
        return errorResponse(
          res,
          new Error(
            `Updates not allowed as this ${idField} is marked as finished.`,
          ),
          `No updates allowed: This ${idField} with ID ${itemId} has already been marked as finished.`,
          statusCodes.SUCCESS,
        );
      }
    }

    const isSuspended = itemStatus.statuses.some((statusEntry) => {
      return statusEntry.times.some((timeEntry) => {
        const suspendStart = moment.utc(timeEntry.pauseStartDate);
        const suspendEnd = moment.utc(timeEntry.pauseEndDate);

        if (
          timeEntry.status === 'suspend' &&
          parsedDate.isBetween(suspendStart, suspendEnd, 'day', '[]')
        ) {
          const isResumed = itemStatus.statuses.some((resumeEntry) => {
            return resumeEntry.times.some((resumeTime) => {
              return (
                resumeTime.status === 'resumed' &&
                moment.utc(resumeTime.time).isAfter(suspendEnd)
              );
            });
          });

          return !isResumed;
        }
        return false;
      });
    });

    if (isSuspended) {
      return errorResponse(
        res,
        new Error(CanNotUpdateStatusDuringSuspend),
        StatusIsSuspendedForThisDate,
        statusCodes.VALIDATION_ERROR,
      );
    }

    const isPaused = itemStatus.statuses.some((statusEntry) => {
      const pauseTimes = statusEntry.times.find((t) => t.status === 'paused');
      if (pauseTimes) {
        const pauseStart = moment.utc(pauseTimes.pauseStartDate);
        const pauseEnd = moment.utc(pauseTimes.pauseEndDate);
        return parsedDate.isBetween(pauseStart, pauseEnd, 'day', '[]');
      }
      return false;
    });

    if (isPaused) {
      return errorResponse(
        res,
        new Error(CanNotUpdateStatusDuringPause),
        StatusIsPausedForThisDate,
        statusCodes.VALIDATION_ERROR,
      );
    }

    let dateEntry = itemStatus.statuses.find((entry) =>
      moment(entry.date).isSame(parsedDate, 'day'),
    );

    if (dateEntry) {
      const isCompleted = dateEntry.times.some(
        (entry) => entry.status === 'completed',
      );
      if (isCompleted) {
        return errorResponse(
          res,
          new Error(
            `Updates not allowed for date ${parsedDate.format('DD/MM/YYYY')} as it is already completed.`,
          ),
          `No further updates allowed: All times on ${parsedDate.format('DD/MM/YYYY')} have been marked as completed.`,
          statusCodes.SUCCESS,
        );
      }
    }

    if (!dateEntry) {
      dateEntry = {
        date: parsedDate.format('YYYY-MM-DD'),
        times: providedTimes.map((providedTime) => ({
          time: providedTime,
          status: statusString,
        })),
      };
      itemStatus.statuses.push(dateEntry);
    } else {
      for (const providedTime of providedTimes) {
        const timeEntry = dateEntry.times.find((t) => t.time === providedTime);

        if (timeEntry) {
          timeEntry.status = statusString;
        } else {
          dateEntry.times.push({ time: providedTime, status: statusString });
        }
      }
    }

    if (statusString === 'completed') {
      const providedTimeIndex = validTimes.indexOf(providedTimes);
      for (let i = 0; i <= providedTimeIndex; i++) {
        const time = validTimes[i];
        const entry = dateEntry.times.find((t) => t.time === time);
        if (entry) {
          entry.status = 'completed';
        } else {
          dateEntry.times.push({ time, status: 'completed' });
        }
      }
      for (let i = providedTimeIndex + 1; i < validTimes.length; i++) {
        const time = validTimes[i];
        const entry = dateEntry.times.find((t) => t.time === time);
        if (entry) {
          entry.status = 'completed';
        } else {
          dateEntry.times.push({ time, status: 'completed' });
        }
      }
    }

    const dateEntryIndex = itemStatus.statuses.findIndex((entry) =>
      moment(entry.date).isSame(parsedDate, 'day'),
    );
    if (dateEntryIndex !== -1) {
      itemStatus.statuses[dateEntryIndex] = dateEntry;
    } else {
      itemStatus.statuses.push(dateEntry);
    }

    await itemStatus.save();

    const responseData =
      statusString === 'completed'
        ? {
          itemId,
          date: parsedDate.format('DD/MM/YYYY'),
          times: dateEntry.times.map((t) => ({
            time: t.time,
            status: t.status,
          })),
        }
        : {
          id: itemId,
          date: parsedDate.format('DD/MM/YYYY'),
          time: providedTimes,
          status: statusString,
        };

    return successResponse(
      res,
      responseData,
      StatusUpdatedSucessfullMesssage,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Update Status Error: ${error.message}`, {
      stack: error.stack,
      requestBody: req.body,
      itemId: req.params.id,
    });
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const finishMedication = async (req, res) => {
  try {
    const userId = req.user.userId;
    const itemIds = req.body.itemIds;
    const validationMessages = [];
    const successMessages = [];

    const user = await checkUserExists(userId, res);
    if (!user) return;

    for (const itemId of itemIds) {
      const isMedication = await MedicationModel.exists({ _id: itemId });
      const isTreatment = await TreatmentModel.exists({ _id: itemId });

      const idLabel = isMedication ? 'medicationId' : 'treatmentId';

      if (!isMedication && !isTreatment) {
        validationMessages.push(`ID ${itemId} not found.`);
        continue;
      }

      const statusModel = isMedication
        ? MedicationStatusModel
        : TreatmentStatusModel;

      let itemStatus = await statusModel.findOne({ userId, [idLabel]: itemId });

      if (!itemStatus) {
        itemStatus = new statusModel({
          userId,
          [idLabel]: itemId,
          statuses: [],
        });
      } else {
        const hasFinishedStatus = itemStatus.statuses.some((status) =>
          status.times.some((timeEntry) => timeEntry.status === 'finished'),
        );

        if (hasFinishedStatus) {
          validationMessages.push(
            `${idLabel} with ID ${itemId} is already marked as finished.`,
          );
          continue;
        }
      }

      const currentDate = new Date();
      const timeIn24Hours = currentDate
        .toTimeString()
        .split(' ')[0]
        .substring(0, 5);

      const newStatusEntry = {
        date: currentDate,
        times: [
          {
            time: timeIn24Hours,
            status: 'finished',
            pauseReason: '',
          },
        ],
      };

      itemStatus.statuses.push(newStatusEntry);

      await itemStatus.save();

      const successMessage = `${idLabel} with ID ${itemId} marked as finished successfully.`;
      successMessages.push(successMessage);
    }

    const responseMessage = {
      successMessages,
      validationMessages,
    };

    return successResponse(
      res,
      responseMessage,
      StatusUpdatedSucessfullMesssage,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const pauseStatus = async (req, res) => {
  try {
    const { pauseStartDate, pauseEndDate, pauseReason, resumeDate } = req.body;
    const userId = req.user.userId;
    const itemId = req.params.id;

    const user = await checkUserExists(userId, res);
    if (!user) {
      return;
    }

    const parsedStartDate = pauseStartDate
      ? moment.utc(pauseStartDate, 'DD/MM/YYYY', true)
      : null;

    const item =
      (await MedicationModel.findById(itemId)) ||
      (await TreatmentModel.findById(itemId));

    if (!item) {
      return errorResponse(
        res,
        new Error(NotFoundErrorMessage),
        RecordNotFoundMessage,
        statusCodes.NOT_FOUND,
      );
    }

    const itemStartDate = moment.utc(item.startDate).startOf('day');
    const itemEndDate = moment.utc(item.endDate).endOf('day');

    const parsedEndDate = pauseEndDate
      ? moment.utc(pauseEndDate, 'DD/MM/YYYY', true)
      : itemEndDate;

    const parsedResumeDate = resumeDate
      ? moment.utc(resumeDate, 'DD/MM/YYYY', true)
      : null;

    if (
      (parsedStartDate && !parsedStartDate.isValid()) ||
      (parsedEndDate && !parsedEndDate.isValid()) ||
      (parsedResumeDate && !parsedResumeDate.isValid())
    ) {
      return errorResponse(
        res,
        new Error(ValidDateFormat),
        InvalidDateFormat,
        statusCodes.VALIDATION_ERROR,
      );
    }

    if (parsedEndDate.isBefore(parsedStartDate)) {
      return errorResponse(
        res,
        new Error(PauseStartDateIsGreathenEndDate),
        InvalidDateRange,
        statusCodes.VALIDATION_ERROR,
      );
    }

    if (!parsedResumeDate && !parsedStartDate) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        PauseStartDateRequired,
        statusCodes.VALIDATION_ERROR,
      );
    }

    const isMedication = await MedicationModel.exists({ _id: itemId });
    const isTreatment = await TreatmentModel.exists({ _id: itemId });

    if (!isMedication && !isTreatment) {
      return errorResponse(
        res,
        new Error(NotFoundErrorMessage),
        RecordNotFoundMessage,
        statusCodes.NOT_FOUND,
      );
    }

    const statusModel = isMedication
      ? MedicationStatusModel
      : TreatmentStatusModel;
    const idField = isMedication ? 'medicationId' : 'treatmentId';

    if (
      (parsedStartDate &&
        !parsedStartDate.isBetween(itemStartDate, itemEndDate, 'day', '[]')) ||
      (parsedEndDate &&
        !parsedEndDate.isBetween(itemStartDate, itemEndDate, 'day', '[]'))
    ) {
      return errorResponse(
        res,
        new Error(
          `Pause dates must be within the medication's active period from ${itemStartDate.format('DD/MM/YYYY')} to ${itemEndDate.format('DD/MM/YYYY')}.`,
        ),
        DateOutOfRangeMessage,
        statusCodes.VALIDATION_ERROR,
      );
    }

    let itemStatus = await statusModel.findOne({ userId, [idField]: itemId });

    if (!itemStatus) {
      itemStatus = new statusModel({
        userId,
        [idField]: itemId,
        statuses: [],
      });
    }

    const isSuspended = itemStatus.statuses.some((statusEntry) =>
      statusEntry.times.some((timeEntry) => {
        const suspendStart = moment.utc(timeEntry.pauseStartDate);
        const suspendEnd = moment.utc(timeEntry.pauseEndDate);

        if (
          timeEntry.status === 'suspend' &&
          parsedStartDate.isBetween(suspendStart, suspendEnd, 'day', '[]')
        ) {
          const isResumed = itemStatus.statuses.some((resumeEntry) =>
            resumeEntry.times.some(
              (resumeTime) =>
                resumeTime.status === 'resumed' &&
                moment.utc(resumeTime.time).isAfter(suspendEnd),
            ),
          );

          return !isResumed;
        }
        return false;
      }),
    );

    if (isSuspended) {
      return errorResponse(
        res,
        new Error(CanNotUpdateStatusDuringSuspend),
        StatusIsSuspendedForThisDate,
        statusCodes.VALIDATION_ERROR,
      );
    }

    if (parsedResumeDate) {
      const resumeStatus = itemStatus.statuses.find((status) =>
        status.times.some(
          (timeEntry) =>
            timeEntry.status === 'paused' &&
            parsedResumeDate.isBetween(
              moment.utc(timeEntry.pauseStartDate),
              moment.utc(timeEntry.pauseEndDate) || moment.utc(),
              'day',
              '[]',
            ),
        ),
      );

      if (resumeStatus) {
        resumeStatus.times.forEach((timeEntry) => {
          if (timeEntry.status === 'paused') {
            timeEntry.status = 'resumed';
          }
        });

        await itemStatus.save();

        if (
          parsedResumeDate.isAfter(
            moment.utc(resumeStatus.times[0].pauseEndDate),
          )
        ) {
          itemStatus.statuses = itemStatus.statuses.filter(
            (status) => status.date !== resumeStatus.date,
          );
        }

        return successResponse(
          res,
          {
            id: itemId,
            resume: {
              date: moment.utc().local().format('DD/MM/YYYY'),
              times: resumeStatus.times.map((t) => ({
                time: t.time,
                status: t.status,
                pauseStartDate: moment
                  .utc(t.pauseStartDate)
                  .local()
                  .format('DD/MM/YYYY'),
                pauseEndDate: moment
                  .utc(t.pauseEndDate)
                  .local()
                  .format('DD/MM/YYYY'),
                pauseReason: t.pauseReason,
                id: t._id,
              })),
            },
          },
          StatusResumedSuccessfully,
          statusCodes.SUCCESS,
        );
      } else {
        return errorResponse(
          res,
          new Error(NoActivePauseForProvidedResumeDate),
          ResumeDateNotFound,
          statusCodes.VALIDATION_ERROR,
        );
      }
    }

    if (parsedStartDate) {
      const existingPause = itemStatus.statuses.find((status) =>
        status.times.some((timeEntry) => {
          return (
            timeEntry.status === 'paused' &&
            (parsedStartDate.isBetween(
              moment.utc(timeEntry.pauseStartDate),
              moment.utc(timeEntry.pauseEndDate) || moment.utc(),
              'day',
              '[]',
            ) ||
              (parsedEndDate &&
                parsedEndDate.isBetween(
                  moment.utc(timeEntry.pauseStartDate),
                  moment.utc(timeEntry.pauseEndDate) || moment.utc(),
                  'day',
                  '[]',
                )) ||
              (parsedStartDate.isSameOrBefore(
                moment.utc(timeEntry.pauseEndDate) || moment.utc(),
              ) &&
                (!parsedEndDate ||
                  parsedEndDate.isSameOrAfter(
                    moment.utc(timeEntry.pauseStartDate),
                  ))))
          );
        }),
      );

      if (existingPause) {
        return errorResponse(
          res,
          new Error(MedicationAlreadyPausedMessage),
          MedicationCanNotPausedMessage,
          statusCodes.VALIDATION_ERROR,
        );
      }

      itemStatus.statuses.push({
        date: new Date(),
        times: [
          {
            time: moment.utc().local().format('HH:mm'),
            status: 'paused',
            pauseStartDate: parsedStartDate.toDate(),
            pauseEndDate: parsedEndDate
              ? parsedEndDate.toDate()
              : itemEndDate.toDate(),
            pauseReason: pauseReason,
          },
        ],
      });

      await itemStatus.save();

      const lastStatus = itemStatus.statuses[itemStatus.statuses.length - 1];
      // eslint-disable-next-line
      const localTime = moment
        .utc(lastStatus.times[0].time, 'HH:mm')
        .local()
        .format('HH:mm');
      const formattedPauseStartDate = moment
        .utc(lastStatus.times[0].pauseStartDate)
        .local()
        .format('DD/MM/YYYY');
      const formattedPauseEndDate = lastStatus.times[0].pauseEndDate
        ? moment
          .utc(lastStatus.times[0].pauseEndDate)
          .local()
          .format('DD/MM/YYYY')
        : null;

      return successResponse(
        res,
        {
          id: itemId,
          pause: {
            date: moment.utc(lastStatus.date).local().format('DD/MM/YYYY'),
            times: [
              {
                time: lastStatus.times[0].time,
                status: lastStatus.times[0].status,
                pauseStartDate: formattedPauseStartDate,
                pauseEndDate: formattedPauseEndDate,
                pauseReason: lastStatus.times[0].pauseReason,
                id: lastStatus.times[0]._id,
              },
            ],
          },
        },
        StatuspauseSucessfully,
        statusCodes.SUCCESS,
      );
    }

    return errorResponse(
      res,
      new Error(ValidationErrorMessage),
      InvalidRequest,
      statusCodes.VALIDATION_ERROR,
    );
  } catch (error) {
    logger.error(`Pause Status Error: ${error.message}`, {
      stack: error.stack,
      requestBody: req.body,
      itemId: req.params.id,
    });
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const suspendMedicationTreatment = async (req, res) => {
  try {
    const { reminderType } = req.query;
    const { suspendDays, resume } = req.body;
    const userId = req.user.userId;

    
    if (resume && suspendDays !== undefined) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        SuspendedDaysNotBeProvidedWhenResuming,
        statusCodes.VALIDATION_ERROR,
      );
    }

    if (suspendDays !== undefined) {
      if (suspendDays === null || suspendDays === '' || isNaN(suspendDays)) {
        return errorResponse(
          res,
          new Error(ValidationErrorMessage),
          SuspendDaysFieldrequired,
          statusCodes.SUCCESS,
        );
      }

      if (suspendDays < 1 || suspendDays > 99) {
        return errorResponse(
          res,
          new Error(ValidationErrorMessage),
          SuspendDaysEligibleLength,
          statusCodes.SUCCESS,
        );
      }
    }

    if (!['medication', 'treatment', 'cycle', 'all'].includes(reminderType)) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        InvalidReminderType,
        statusCodes.VALIDATION_ERROR,
      );
    }

    const user = await checkUserExists(userId, res);
    if (!user) return;

 

    if (resume) {
      const handleResume = async (model, statusModel, idField) => {
        const records = await model.find({ userId });
        let isAnyRecordResumed = false;
        let firstPauseStartDate = null;
        let firstPauseEndDate = null;

        for (const record of records) {
          const statusEntry = await statusModel.findOne({
            userId,
            [idField]: record._id,
          });

          if (statusEntry) {
            let hasResumedStatus = false;

            
            statusEntry.statuses.forEach((status) => {
              const resumeStatus = status.times.find((timeEntry) => {
                const pauseStartDate = moment.utc(timeEntry.pauseStartDate, moment.ISO_8601);
                const pauseEndDate = moment.utc(timeEntry.pauseEndDate, moment.ISO_8601);

                return (
                  timeEntry.status === 'suspend' &&
                  moment().isBetween(pauseStartDate, pauseEndDate, 'day', '[]')
                );
              });

              if (resumeStatus) {
                hasResumedStatus = true;
                isAnyRecordResumed = true;

                if (!firstPauseStartDate && !firstPauseEndDate) {
                  firstPauseStartDate = moment(resumeStatus.pauseStartDate).format('DD/MM/YYYY');
                  firstPauseEndDate = moment(resumeStatus.pauseEndDate).format('DD/MM/YYYY');
                }

                status.times.forEach((timeEntry) => {
                  if (timeEntry.status === 'suspend') {
                    timeEntry.status = 'resumed';
                  }
                });
              }
            });

            if (hasResumedStatus) {
              await statusEntry.save();
            }
          }
        }

        if (!isAnyRecordResumed) {
          return errorResponse(
            res,
            new Error(NoActiveSuspendForResumeDate),
            NoActiveSuspendForResumeDate,
            statusCodes.SUCCESS,
          );
        } else {
          return successResponse(
            res,
            {
              message: SuspendedRecordsresumedSucessfully,
              pauseStartDate: firstPauseStartDate,
              pauseEndDate: firstPauseEndDate,
            },
            StatusResumedSuccessfully,
            statusCodes.SUCCESS,
          );
        }
      };

   
      const resumePromises = [];
      if (reminderType === 'medication' || reminderType === 'all') {
        resumePromises.push(handleResume(MedicationModel, MedicationStatusModel, 'medicationId'));
      }

      if (reminderType === 'treatment' || reminderType === 'all') {
        resumePromises.push(handleResume(TreatmentModel, TreatmentStatusModel, 'treatmentId'));
      }

      if (reminderType === 'cycle' || reminderType === 'all') {
        resumePromises.push(handleResume(CycleModel, CycleStatusModel, 'cycleId'));
      }

    
      await Promise.all(resumePromises);
      return;
    }

    if (suspendDays) {

      const hasActiveRecords = async (model) => {
        const records = await model.find({
          userId,
          startDate: { $lte: new Date() },
          endDate: { $gte: new Date() },
        });
        return records.length > 0;
      };

      const suspendEndDate = moment().add(parseInt(suspendDays), 'days').endOf('day').toDate();
      const resumeDate = moment(suspendEndDate).add(1, 'day').startOf('day').toDate();

      const handleSuspend = async (model, statusModel, idField) => {
        const records = await model.find({ userId });
        const hasActive = await hasActiveRecords(model);
        if (!hasActive) {
          return false; // No active records found
        }
         
        for (const record of records) {
          const statusEntry = await statusModel.findOne({ userId, [idField]: record._id });

          if (statusEntry) {
            const existingSuspend = statusEntry.statuses.some((status) =>
              status.times.some((timeEntry) => {
                const pauseStartDate = moment.utc(timeEntry.pauseStartDate, moment.ISO_8601);
                const pauseEndDate = moment.utc(timeEntry.pauseEndDate, moment.ISO_8601);

                return (
                  timeEntry.status === 'suspend' &&
                  moment().isBetween(pauseStartDate, pauseEndDate, 'day', '[]')
                );
              }),
            );
             
   

            if (existingSuspend) {
              return errorResponse(
                res,
                new Error(ValidationErrorMessage),
                MedicationTreatmentAlredySuspend,
                statusCodes.SUCCESS,
              );
            }

            statusEntry.statuses.push({
              date: moment().toDate(),
              times: [
                {
                  time: moment().format('HH:mm'),
                  status: 'suspend',
                  pauseStartDate: moment().toDate(),
                  pauseEndDate: suspendEndDate,
                  pauseReason: 'Suspension applied',
                },
              ],
            });
            await statusEntry.save();
          } else {
            const newStatusEntry = new statusModel({
              userId,
              [idField]: record._id,
              statuses: [
                {
                  date: moment().toDate(),
                  times: [
                    {
                      time: moment().format('HH:mm'),
                      status: 'suspend',
                      pauseStartDate: moment().toDate(),
                      pauseEndDate: suspendEndDate,
                      pauseReason: SuspendApplied,
                    },
                  ],
                },
              ],
            });
            await newStatusEntry.save();
          }
        }
      };

    
      const suspendPromises = [];
      if (reminderType === 'medication' || reminderType === 'all') {
        suspendPromises.push(handleSuspend(MedicationModel, MedicationStatusModel, 'medicationId'));
      }

      if (reminderType === 'treatment' || reminderType === 'all') {
        suspendPromises.push(handleSuspend(TreatmentModel, TreatmentStatusModel, 'treatmentId'));
      }

      if (reminderType === 'cycle' || reminderType === 'all') {
        suspendPromises.push(handleSuspend(CycleModel, CycleStatusModel, 'cycleId'));
      }


  
     
      //await Promise.all(suspendPromises);
      const results = await Promise.all(suspendPromises);

      if (results.every(result => result === false)) {
        return errorResponse(
          res,
          new Error(NoRecordsFoundForSuspend),
          NoRecordsFoundForSuspend,
          statusCodes.SUCCESS
        );
      }

    

      const responseData = {
        reminderType,
        suspendEndDate: moment(suspendEndDate).format('DD/MM/YYYY'),
        resumeDate: moment(resumeDate).format('DD/MM/YYYY'),
      };
      return successResponse(
        res,
        responseData,
        MedicationTreatmentSuspendSucessfully,
        statusCodes.SUCCESS,
      );
    }
  } catch (error) {
    if (!res.headersSent) {
      logger.error(`Suspend/Resume Medication/Treatment: ${error.message}`, {
        stack: error.stack,
        requestQuery: req.query,
        userId: req.user.userId,
      });
      return errorResponse(
        res,
        error,
        ServerErrorMessage,
        statusCodes.SERVER_ERROR,
      );
    }
  }
};


export const getPausedOrSuspendedMedicationsList = async (req, res) => {
  try {
    const { reminderType, status } = req.query;
    let { startDate, endDate } = req.query;
    const userId = req.user.userId;

    const user = await checkUserExists(userId, res);
    if (!user) return;

    const isFemale = user.gender === 'Female';
    const validReminderTypes = isFemale
      ? ['medication', 'treatment', 'all', 'cycle']
      : ['medication', 'treatment', 'all'];

    if (!validReminderTypes.includes(reminderType)) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        InvalidReminderType,
        statusCodes.VALIDATION_ERROR,
      );
    }

    if (!['1', '5', '6'].includes(status)) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        InvalidStatus,
        statusCodes.VALIDATION_ERROR,
      );
    }

    if (!startDate && !endDate) {
      const currentMonthStart = moment().startOf('month').format('DD/MM/YYYY');
      const currentMonthEnd = moment().endOf('month').format('DD/MM/YYYY');
      startDate = currentMonthStart;
      endDate = currentMonthEnd;
    }

    let dateFilter = {};
    if (startDate && endDate) {
      const start = moment.utc(startDate, 'DD/MM/YYYY', true);
      const end = moment.utc(endDate, 'DD/MM/YYYY', true);

      if (!start.isValid() || !end.isValid()) {
        return errorResponse(
          res,
          new Error(ValidationErrorMessage),
          InvalidDateFormat,
          statusCodes.VALIDATION_ERROR,
        );
      }

      if (start.isAfter(end)) {
        return errorResponse(
          res,
          new Error(ValidationErrorMessage),
          StartDateGreterthenEndDateMessage,
          statusCodes.VALIDATION_ERROR,
        );
      }

      dateFilter = {
        startDate: { $lte: end.endOf('day').toDate() },
        endDate: { $gte: start.startOf('day').toDate() },
      };
    }

    const medicationFilters = { userId, ...dateFilter };
    const treatmentFilters = { userId, ...dateFilter };
    const cycleFilters = { userId };

    const statusMapping = {
      1: 'paused',
      5: 'suspend',
      6: ['paused', 'suspend'],
    };

    let medicationStatusData = [];
    let treatmentStatusData = [];
    let cycleStatusData = [];

    if (status) {
      const statusFilter = Array.isArray(statusMapping[status])
        ? { $in: statusMapping[status] }
        : statusMapping[status];

      medicationStatusData = await MedicationStatusModel.find({
        userId,
        'statuses.times.status': statusFilter,
      });
      treatmentStatusData = await TreatmentStatusModel.find({
        userId,
        'statuses.times.status': statusFilter,
      });
      cycleStatusData = await CycleStatusModel.find({
        userId,
        'statuses.times.status': statusFilter,
      });

      const medicationIds = medicationStatusData.map(
        (status) => status.medicationId,
      );
      const treatmentIds = treatmentStatusData.map(
        (status) => status.treatmentId,
      );
      const cycleIds = cycleStatusData.map((status) => status.cycleId);

      if (medicationIds.length > 0) {
        medicationFilters._id = { $in: medicationIds };
      }
      if (treatmentIds.length > 0) {
        treatmentFilters._id = { $in: treatmentIds };
      }
      if (cycleIds.length > 0) {
        cycleFilters._id = { $in: cycleIds };
      }
    }

    const [medicationData, treatmentData, cycleData] = await Promise.all([
      reminderType === 'medication' || reminderType === 'all'
        ? MedicationModel.find(medicationFilters)
        : [],
      reminderType === 'treatment' || reminderType === 'all'
        ? TreatmentModel.find(treatmentFilters)
        : [],
      isFemale && (reminderType === 'cycle' || reminderType === 'all')
        ? CycleModel.find(cycleFilters)
        : [],
    ]);

    const medicationFields = await Promise.all(
      medicationData.map(async (medication) => {
        const { timeWiseStatuses } = await calculateAdherenceForPauseSuspend(
          medication,
          'medication',
          userId,
          startDate,
          endDate,
          status,
        );

        if (!timeWiseStatuses || timeWiseStatuses.length === 0) {
          return null;
        }

        const filteredTimeWiseStatuses =
          status === '6'
            ? timeWiseStatuses
            : timeWiseStatuses.filter(
              (timeStatus) => timeStatus.status === statusMapping[status],
            );

        return formatPauseSuspendMedicationData(
          medication,
          filteredTimeWiseStatuses,
        );
      }),
    );

    const treatmentFields = await Promise.all(
      treatmentData.map(async (treatment) => {
        const { timeWiseStatuses } = await calculateAdherenceForPauseSuspend(
          treatment,
          'treatment',
          userId,
          startDate,
          endDate,
          status,
        );

        if (!timeWiseStatuses || timeWiseStatuses.length === 0) {
          return null;
        }

        const filteredTimeWiseStatuses =
          status === '6'
            ? timeWiseStatuses
            : timeWiseStatuses.filter(
              (timeStatus) => timeStatus.status === statusMapping[status],
            );

        return formatPauseSuspendTreatmentData(
          treatment,
          filteredTimeWiseStatuses,
        );
      }),
    );

    const cycleFields = await Promise.all(
      cycleData.map(async (cycle) => {
        const { timeWiseStatuses } = await calculateAdherenceForPauseSuspend(
          cycle,
          'cycle',
          userId,
          startDate,
          endDate,
          status,
        );

        if (!timeWiseStatuses || timeWiseStatuses.length === 0) {
          return null;
        }

        const filteredTimeWiseStatuses =
          status === '6'
            ? timeWiseStatuses
            : timeWiseStatuses.filter(
              (timeStatus) => timeStatus.status === statusMapping[status],
            );

        return formatPauseSuspendCycleData(cycle, filteredTimeWiseStatuses);
      }),
    );

    const validCycleFields = cycleFields.filter((cycle) => cycle !== null);
    const validMedicationFields = medicationFields.filter(
      (medication) => medication !== null,
    );
    const validTreatmentFields = treatmentFields.filter(
      (treatment) => treatment !== null,
    );

    const responseData = [
      ...validMedicationFields,
      ...validTreatmentFields,
      ...(isFemale ? validCycleFields : []),
    ];

    if (responseData.length === 0) {
      return successResponse(
        res,
        responseData,
        NoDataFoundForSpecifiedReminder,
        statusCodes.SUCCESS,
      );
    }

    return successResponse(
      res,
      responseData,
      MedicationDetailGetSucessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Get Medication List: ${error.message}`, {
      stack: error.stack,
      requestQuery: req.query,
      userId: req.user.userId,
    });
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const deleteMedication = async (req, res) => {
  try {
    const userId = req.user.userId;
    const medicationId = req.params.id;

    const user = await checkUserExists(userId, res);
    if (!user) return;

    let medication = await MedicationModel.findById(medicationId);

    if (!medication) {
      return successResponse(
        res,
        new Error(MedicationNotFound),
        MedicationNotFound,
        statusCodes.SUCCESS,
      );
    }

    medication = await MedicationModel.findByIdAndDelete(medicationId);

    return successResponse(
      res,
      undefined,
      MedicationDeleteSucessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Delete medication error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const getSuspendedStatus = async (req, res) => {
  try {
    const userId = req.user.userId;

    
    const user = await checkUserExists(userId, res);
    if (!user) return;

    const isFemale = user.gender === 'Female';
    const currentDate = new Date();
    const suspendStatus = 'suspend';

   
    const buildSuspensionQuery = () => ({
      userId,
      'statuses.times': {
        $elemMatch: {
          status: suspendStatus,
          pauseStartDate: { $lte: currentDate }, 
          pauseEndDate: { $gte: currentDate },  
        },
      },
    });

  
    const [medicationSuspended, treatmentSuspended, cycleSuspended] = await Promise.all([
      MedicationStatusModel.exists(buildSuspensionQuery()),
      TreatmentStatusModel.exists(buildSuspensionQuery()),
      isFemale ? CycleStatusModel.exists(buildSuspensionQuery()) : false,
    ]);

   
    const responseData = [
      {
        title: 'Medication',
        enable: !!medicationSuspended,
        value: 'medication',
      },
      {
        title: 'Treatment',
        enable: !!treatmentSuspended,
        value: 'treatment',
      },
      {
        title: 'Menstruation Cycle',
        enable: !!cycleSuspended,
        value: 'cycle',
      },
    ];

   
    return successResponse(
      res,
      responseData,
      MedicationDetailGetSucessfully,
      statusCodes.SUCCESS
    );
  } catch (error) {
   
    logger.error(`Get Suspended Status: ${error.message}`, {
      stack: error.stack,
      requestQuery: req.query,
      userId: req.user.userId,
    });
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR
    );
  }
};
