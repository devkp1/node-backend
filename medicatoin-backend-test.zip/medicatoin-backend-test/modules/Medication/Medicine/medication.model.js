import mongoose, { Schema } from 'mongoose';
import { InvalidFrequencyValue } from '#constants/errorMessages.js';
import {
  MedicationModelSchema,
  MedicationStatusModelSchema,
  UserModelSchema,
} from '#constants/modelNameConstants.js';
import {
  medicationFoodTime,
  medicationFrequency,
  medicationTimeFrequency,
  medicationType,
  medicationUnit,
} from '#enums/medicationEnum.js';
import { validateTimeFormat } from '#root/constants/regexConstants.js';

const medicationSchema = new Schema(
  {
    medicationName: {
      type: String,
      required: true,
    },
    startDate: {
      type: Date,
      required: true,
    },
    endDate: {
      type: Date,
      required: true,
    },
    type: {
      type: String,
      enum: Object.values(medicationType),
      default: 'Tablet',
      required: true,
    },
    strength: {
      type: Number,
      default: 0
    },
    unit: {
      type: String,
      enum: ['', ...Object.values(medicationUnit)], 
      default: '',
    },
    frequency: {
      type: Schema.Types.Mixed,
      enum: Object.values(medicationFrequency),
      default: 'Everyday',
    },
    foodTime: {
      type: String,
      enum: Object.values(medicationFoodTime),
      default: 'After meal',
    },
    timeFrequency: {
      type: String,
      enum: Object.keys(medicationTimeFrequency),
      default: 'Once a Day',
    },
    times: {
      type: [String],
      default: function () {
        const expectedCount = medicationTimeFrequency[this.timeFrequency];
        return Array(expectedCount).fill('12:00');
      },
      validate: {
        validator: function (value) {
          const expectedTimes = medicationTimeFrequency[this.timeFrequency];
          const isValidFormat = value.every((time) => validateTimeFormat(time));
          return expectedTimes
            ? isValidFormat && value.length === expectedTimes
            : isValidFormat;
        },
        message: function () {
          const expectedTimes = medicationTimeFrequency[this.timeFrequency];
          return expectedTimes
            ? `The selected time frequency requires exactly ${expectedTimes} time(s) in HH:MM format.`
            : 'Invalid time format.';
        },
      },
    },
    numberOfCapsule: {
      type: [Number],
      default: function () {
        const expectedCount = medicationTimeFrequency[this.timeFrequency];
        return Array(expectedCount).fill(1);
      },
      required: true,
      validate: {
        validator: function (value) {
          const expectedTimes = medicationTimeFrequency[this.timeFrequency];
          return expectedTimes ? value.length === expectedTimes : true;
        },
        message: function () {
          const expectedTimes = medicationTimeFrequency[this.timeFrequency];
          return expectedTimes
            ? `The selected time frequency requires exactly ${expectedTimes} ${this.type}(s). You provided ${this.numberOfCapsule.length}.`
            : InvalidFrequencyValue;
        },
      },
    },
    notes: {
      type: String,
      default: '',
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: UserModelSchema,
    },
    statusID: {
      type: mongoose.Schema.Types.ObjectId,
      ref: MedicationStatusModelSchema,
    },
  },
  {
    timestamps: true,
  },
);


const MedicationModel = mongoose.model(MedicationModelSchema, medicationSchema);

export default MedicationModel;
