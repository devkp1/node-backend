import mongoose from 'mongoose';
import {
  MedicationModelSchema,
  MedicationStatusModelSchema,
  UserModelSchema,
} from '#root/constants/modelNameConstants.js';
import { medicationStatuses } from '#root/enums/medicationEnum.js';

const MedicationStatusSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: UserModelSchema,
    required: true,
  },
  medicationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: MedicationModelSchema,
    required: true,
  },
  statuses: [
    {
      date: {
        type: Date,
        required: true,
      },
      times: [
        {
          time: {
            type: String,
            required: true,
          },
          status: {
            type: String,
            enum: medicationStatuses,
            required: true,
          },
          pauseStartDate: {
            type: Date,
          },
          pauseEndDate: {
            type: Date,
          },
          pauseReason: {
            type: String,
            default: '',
          },
        },
      ],
    },
  ],
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

const MedicationStatusModel = mongoose.model(
  MedicationStatusModelSchema,
  MedicationStatusSchema,
);

export default MedicationStatusModel;
