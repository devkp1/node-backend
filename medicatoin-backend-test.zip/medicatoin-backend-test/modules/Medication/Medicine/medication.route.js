import express from 'express';
import {
  addMedication,
  deleteMedication,
  finishMedication,
  getMedicationById,
  getMedicationList,
  getPausedOrSuspendedMedicationsList,
  getSuspendedStatus,
  pauseStatus,
  suspendMedicationTreatment,
  updateMedication,
  updateStatus,
} from './medication.controller.js';
import { isAuthenticateUser } from '#middleware/validateTokenHandler.js';
import { verifyToken } from '#middleware/verifyTokenHandler.js';

const medicationRoute = express.Router();

medicationRoute
  .route('/add-medication')
  .post(isAuthenticateUser, verifyToken, addMedication);
medicationRoute
  .route('/get-medication-list')
  .get(isAuthenticateUser, verifyToken, getMedicationList);
medicationRoute
  .route('/update-medication/:id')
  .put(isAuthenticateUser, verifyToken, updateMedication);
medicationRoute
  .route('/get-medication/:id')
  .get(isAuthenticateUser, verifyToken, getMedicationById);
medicationRoute
  .route('/update-medication-status/:id')
  .put(isAuthenticateUser, verifyToken, updateStatus);
medicationRoute
  .route('/pause-resume-medication/:id')
  .post(isAuthenticateUser, verifyToken, pauseStatus);
medicationRoute
  .route('/delete-medication/:id')
  .delete(isAuthenticateUser, verifyToken, deleteMedication);
medicationRoute
  .route('/suspend-medication')
  .post(isAuthenticateUser, verifyToken, suspendMedicationTreatment);
medicationRoute
  .route('/pause-suspend-medication-list')
  .get(isAuthenticateUser, verifyToken, getPausedOrSuspendedMedicationsList);
medicationRoute
  .route('/finish-medication')
  .post(isAuthenticateUser,verifyToken, finishMedication)
medicationRoute
  .route('/get-suspend-status')
  .get(isAuthenticateUser,verifyToken, getSuspendedStatus)

export default medicationRoute;
