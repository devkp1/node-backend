import moment from 'moment';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
dotenv.config();
import userModel from './user.model.js';
import {
  forgotPasswordValidations,
  loginValidations,
  resetPasswordValidations,
  userUpdateValidations,
  userValidations,
} from '#validators/user.validation.js';
import {
  DeviceIDIsRequired,
  EmailAndPasswordRequiredMessage,
  EmailPasswordMatchMessage,
  GenderDOBrequired,
  IncorrectCurrentPassword,
  InvalidDateFormat,
  InvalidGenderValue,
  InvalidOrExpireOTP,
  InvalidPhoneNumber,
  NotFoundErrorMessage,
  PasswordNotMatch,
  PasswordShouldNotSame,
  ProfileUpdateNotAlowedForGuestUsers,
  ProviderDetailsDoNotMatch,
  ProviderProviderIDEmailRequired,
  ServerErrorMessage,
  UnauthorizedErrorMessage,
  UserInfoRequiredMessage,
  UserNotFoundMessage,
  ValidDateFormat,
  ValidationErrorMessage,
  blacklistedTokenMessage,
  emailUniqueMessage,
} from '#constants/errorMessages.js';
import {
  AccountDeleteSucessfully,
  CodeVerifiedSucessfully,
  GuestUserLoggedInSuccessfully,
  OtpSentMessage,
  PasswordResetSucessMessage,
  UserDataUpdatedSuccessfully,
  UserDetailsGetSucessfully,
  logoutSuccessfully,
  userDataAddedSuccessfully,
  userLoginMessage,
  userRegisterMessage,
} from '#constants/responseMessages.js';
import logger from '../../logger.js';
import { Error } from 'mongoose';
import { errorResponse, successResponse } from '#utils/responseHandler.js';
import { checkCityStateCountryValidity } from '#utils/checkCityStateCountryValidity.js';
import { blacklistToken, isTokenBlacklisted } from '#utils/tokenManager.js';
import { uploadProfilePicture } from '#utils/uploadProfilePicture.js';
import { checkUserExists } from '#utils/checkUserExists.js';
import { generateOTP, sendOTPEmail } from '#utils/otp.utils.js';
import validateAllowedFields from '#utils/checkAllowedFeilds.js';
import {
  generateAccessToken,
  generateGuestAccessToken,
} from '#utils/tokenGenerator.js';
import { validateInput } from '#common/validation.js';
import { statusCodes } from '#constants/statusCodeMessages.js';
import { comparePassword, getHashPassword } from '#utils/password.utils.js';
import { Gender } from '#root/enums/userEnum.js';
import { phoneRegex } from '#root/constants/regexConstants.js';

export const registerUser = async (req, res) => {
  try {
    const { fullName, password, email: emailInput } = req.body;

    const allowedFields = ['fullName', 'email', 'password'];

    if (!validateAllowedFields(allowedFields, req.body, res)) return;

    const email = emailInput.toLowerCase();

    const isValid = validateInput(
      userValidations,
      { fullName, email, password },
      res,
    );
    if (!isValid) return;

    const hashedPassword = await getHashPassword(password);

    let newUser = await userModel.create({
      fullName,
      email,
      password: hashedPassword,
    });

    newUser = await userModel.findById(
      newUser._id,
      'fullName email password createdAt updatedAt',
    );

    const { _id, createdAt, updatedAt } = newUser;
    const updatedUser = {
      id: _id,
      fullName,
      email,
      createdAt,
      updatedAt,
    };

    return successResponse(
      res,
      updatedUser,
      userRegisterMessage,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    if (error.code === 11000 && error.keyValue.email) {
      logger.error(`Registration error: ${emailUniqueMessage}`);
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        emailUniqueMessage,
        statusCodes.VALIDATION_ERROR,
      );
    }

    logger.error(`Registration error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const loginUser = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    const allowedFields = ['email', 'password'];
    if (!validateAllowedFields(allowedFields, req.body, res)) {
      return next();
    }

    const isValid = validateInput(loginValidations, { email, password }, res);
    if (!isValid) {
      return;
    }

    if (!email || !password) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        EmailAndPasswordRequiredMessage,
        statusCodes.VALIDATION_ERROR,
      );
    }

    const user = await userModel.findOne({ email });
    if (!user) {
      return errorResponse(
        res,
        new Error(NotFoundErrorMessage),
        UserNotFoundMessage,
        statusCodes.NOT_FOUND,
      );
    }

    const isPasswordMatch = await comparePassword(password, user.password);
    if (!isPasswordMatch) {
      return errorResponse(
        res,
        new Error(NotFoundErrorMessage),
        EmailPasswordMatchMessage,
        statusCodes.NOT_FOUND,
      );
    }

    const accessToken = generateAccessToken(user);

    return successResponse(
      res,
      {
        id: user._id,
        fullName: user.fullName,
        isProfileComplete: user.isProfileComplete,
        accessToken,
        gender: user.gender || '',
      },
      userLoginMessage,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Update error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const registerGuestUser = async (req, res) => {
  try {
    const { deviceId } = req.body;

    if (!deviceId) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        DeviceIDIsRequired,
        statusCodes.SUCCESS,
      );
    }

    const user = await userModel.findOne({ deviceId: deviceId });

    if (user) {
      const accessToken = generateGuestAccessToken(user);

      const dummyEmailPrefix = 'guest-';
      const dummyEmailSuffix = '@medication.in';

      const isDummyEmail =
        user.email.startsWith(dummyEmailPrefix) &&
        user.email.endsWith(dummyEmailSuffix);

      const emailResponse = isDummyEmail ? '' : user.email;

      return successResponse(
        res,
        {
          id: user._id,
          deviceId: user.deviceId,
          fullName: user.fullName,
          isProfileComplete: user.isProfileComplete,
          accessToken,
          gender: user.gender || '',
          email: emailResponse,
        },
        GuestUserLoggedInSuccessfully,
        statusCodes.SUCCESS,
      );
    }

    const dummyEmail = `guest-${deviceId}@medication.in`;
    const hashedPassword = await getHashPassword(deviceId);

    let newUser = await userModel.create({
      fullName: 'Guest User',
      email: dummyEmail,
      password: hashedPassword,
      deviceId,
      isProfileComplete: false,
    });

    newUser = await userModel.findById(
      newUser._id,
      'fullName email createdAt updatedAt',
    );

    const { _id, createdAt, updatedAt } = newUser;
    const accessToken = generateGuestAccessToken(newUser);

    const emailResponse = newUser.email.startsWith('guest-')
      ? ''
      : newUser.email;

    return successResponse(
      res,
      {
        id: _id,
        fullName: newUser.fullName,
        email: emailResponse,
        deviceId: newUser.deviceId,
        accessToken,
        isProfileComplete: newUser.isProfileComplete || false,
        gender: newUser.gender || '',
        createdAt,
        updatedAt,
      },
      GuestUserLoggedInSuccessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Guest Registration error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const userInfo = async (req, res) => {
  try {
    const {
      gender,
      dob,
      houseNumber,
      address,
      pincode,
      city,
      phoneNumber,
      state,
      country,
      notifyMe,
    } = req.body;
    const userId = req.user.userId;

    const allowedFields = [
      'gender',
      'dob',
      'houseNumber',
      'address',
      'pincode',
      'city',
      'state',
      'country',
      'notifyMe',
      'phoneNumber',
    ];

    if (!gender || !dob) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        GenderDOBrequired,
        statusCodes.VALIDATION_ERROR,
      );
    }

    if (!validateAllowedFields(allowedFields, req.body, res)) return;

    if (phoneNumber && !phoneRegex.test(phoneNumber)) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        InvalidPhoneNumber,
        statusCodes.VALIDATION_ERROR,
      );
    }

    let user = await checkUserExists(userId, res);
    if (!user) return;

    const fullGender = Gender[gender];
    if (!fullGender) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        InvalidGenderValue,
        statusCodes.SUCCESS,
      );
    }

    user.gender = fullGender;
    user.dob = moment(dob).format('DD/MM/YYYY');
    user.houseNumber = houseNumber;
    user.phoneNumber = phoneNumber;
    user.address = address;
    user.pincode = pincode;
    user.city = city;
    user.state = state;
    user.country = country;
    user.notifyMe = notifyMe;
    await user.save();

    user = await user.populate([
      { path: 'city', select: 'name' },
      { path: 'state', select: 'name' },
      { path: 'country', select: 'name' },
    ]);

    let isProfileComplete = true;
    const requiredFields = ['fullName', 'gender', 'dob'];

    requiredFields.forEach((field) => {
      if (!user[field]) {
        isProfileComplete = false;
      }
    });

    user.isProfileComplete = isProfileComplete;
    await user.save();

    const updatedUser = {
      id: user._id,
      gender: fullGender,
      phoneNumber: user.phoneNumber,
      dob: moment(user.dob).format('DD/MM/YYYY'),
      ...(user.houseNumber && { houseNumber: user.houseNumber }),
      ...(user.address && { address: user.address }),
      ...(user.pincode && { pincode: user.pincode }),
      ...(user.city && { city: { id: user.city._id, name: user.city.name } }),
      ...(user.state && {
        state: { id: user.state._id, name: user.state.name },
      }),
      ...(user.country && {
        country: { id: user.country._id, name: user.country.name },
      }),
      isProfileComplete: user.isProfileComplete,
      notifyMe: user.notifyMe,
    };

    return successResponse(
      res,
      updatedUser,
      userDataAddedSuccessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Update error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const requestCode = async (req, res) => {
  try {
    const userEmail = req.body.email;

    const user = await userModel.findOne({ email: userEmail });
    if (!user) {
      return errorResponse(
        res,
        new Error(UserNotFoundMessage),
        UserNotFoundMessage,
        statusCodes.NOT_FOUND,
      );
    }

    const otp = generateOTP();
    user.otp = otp;
    user.otpExpires = moment().add(10, 'minutes').toDate();
    await user.save();

    await sendOTPEmail(user.email, otp);

    return successResponse(res, undefined, OtpSentMessage, statusCodes.SUCCESS);
  } catch (error) {
    logger.error(`OTP request error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const verifyCode = async (req, res) => {
  try {
    const { email, code } = req.body;

    const user = await userModel.findOne({ email });
    if (!user || user.otp !== code || moment().isAfter(user.otpExpires)) {
      return errorResponse(
        res,
        new Error(UnauthorizedErrorMessage),
        InvalidOrExpireOTP,
        statusCodes.UNAUTHORIZED,
      );
    }

    user.otp = undefined;
    user.otpExpires = undefined;
    user.isOTPVerified = true;
    await user.save();

    return successResponse(
      res,
      undefined,
      CodeVerifiedSucessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`OTP verification error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const forgotPassword = async (req, res) => {
  try {
    const { email, newPassword } = req.body;

    if (!validateInput(forgotPasswordValidations, { newPassword }, res)) return;

    const user = await userModel.findOne({ email });
    if (!user) {
      return errorResponse(
        res,
        new Error(NotFoundErrorMessage),
        UserNotFoundMessage,
        statusCodes.NOT_FOUND,
      );
    }

    if (!user.isOTPVerified) {
      return errorResponse(
        res,
        new Error(UnauthorizedErrorMessage),
        InvalidOrExpireOTP,
        statusCodes.UNAUTHORIZED,
      );
    }

    user.password = await getHashPassword(newPassword);
    user.isOTPVerified = false;
    await user.save();

    return successResponse(
      res,
      undefined,
      PasswordResetSucessMessage,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Forgot password error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const resetPassword = async (req, res) => {
  try {
    const userId = req.user.userId;
    const { currentPassword, newPassword, confirmNewPassword } = req.body;

    if (
      !validateInput(
        resetPasswordValidations,
        { newPassword, confirmNewPassword },
        res,
      )
    )
      return;

    if (newPassword === currentPassword) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        PasswordShouldNotSame,
        statusCodes.VALIDATION_ERROR,
      );
    }

    if (newPassword !== confirmNewPassword) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        PasswordNotMatch,
        statusCodes.VALIDATION_ERROR,
      );
    }

    const user = await userModel.findById(userId);
    if (!user) {
      return errorResponse(
        res,
        new Error(UserNotFoundMessage),
        UserNotFoundMessage,
        statusCodes.NOT_FOUND,
      );
    }

    const isMatch = await comparePassword(currentPassword, user.password);
    if (!isMatch) {
      return errorResponse(
        res,
        new Error(UnauthorizedErrorMessage),
        IncorrectCurrentPassword,
        statusCodes.UNAUTHORIZED,
      );
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);

    user.password = hashedPassword;
    await user.save();

    return successResponse(
      res,
      undefined,
      PasswordResetSucessMessage,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`reset password error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const logoutUser = async (req, res) => {
  try {
    const token = req.token;

    await blacklistToken(token);

    return successResponse(
      res,
      undefined,
      logoutSuccessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Logout error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const getUserProfile = async (req, res) => {
  try {
    const userId = req.user.userId;

    const user = await checkUserExists(userId, res);
    if (!user) return;

    const userDetails = await userModel
      .findById(
        userId,
        'fullName countryCode phoneNumber email gender dob city country profilePicture',
      )
      .populate([
        { path: 'city', select: 'name' },
        { path: 'state', select: 'name' },
        { path: 'country', select: 'phoneCode name' },
      ]);

    // if (!userDetails.city || !userDetails.state || !userDetails.country) {
    //   return errorResponse(
    //     res,
    //     new Error(NotFoundErrorMessage),
    //     UserInfoRequiredMessage,
    //     statusCodes.NOT_FOUND,
    //   );
    // }

    const dummyEmailPrefix = 'guest-';
    const dummyEmailSuffix = '@medication.in';
    const isDummyEmail =
      userDetails.email.startsWith(dummyEmailPrefix) &&
      userDetails.email.endsWith(dummyEmailSuffix);
    const emailResponse = isDummyEmail ? '' : userDetails.email;

    const formattedUser = {
      id: userId,
      fullName: userDetails.fullName,
      phoneNumber: userDetails.phoneNumber,
      email: emailResponse,
      dob: moment(userDetails.dob).format('DD/MM/YYYY'),
      gender: userDetails.gender,
      profilePicture: userDetails.profilePicture,
      city: userDetails.city
        ? { id: userDetails.city._id, cityName: userDetails.city.name }
        : { id: '', cityName: '' },
      state: userDetails.state
        ? { id: userDetails.state._id, stateName: userDetails.state.name }
        : { id: '', stateName: '' },
      country: userDetails.country
        ? {
          id: userDetails.country._id,
          countryName: userDetails.country.name,
          phoneCode: userDetails.country.phoneCode,
        }
        : { id: '', countryName: '', phoneCode: '' },
    };

    return successResponse(
      res,
      formattedUser,
      UserDetailsGetSucessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`User retrieved error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const UserUpdateProfile = async (req, res) => {
  try {
    const userId = req.user.userId;

    const {
      fullName,
      phoneNumber,
      email,
      countryCode,
      gender,
      dob,
      city,
      country,
      state,
      address,
      pincode,
      notifyMe,
    } = req.body;

    const isValid = validateInput(
      userUpdateValidations,
      { fullName, email },
      res,
    );
    if (!isValid) return;

    let user = await checkUserExists(userId, res);
    if (!user) return;
    const dummyEmailPrefix = 'guest-';
    const dummyEmailSuffix = '@medication.in';

    const isDummyEmail =
      user.email.startsWith(dummyEmailPrefix) &&
      user.email.endsWith(dummyEmailSuffix);

    if (isDummyEmail) {
      return errorResponse(
        res,
        new Error(ProfileUpdateNotAlowedForGuestUsers),
        ProfileUpdateNotAlowedForGuestUsers,
        statusCodes.FORBIDDEN,
      );
    }

    const validationResponse = await checkCityStateCountryValidity(
      city,
      state,
      country,
      res,
    );
    if (!validationResponse) return;

    // eslint-disable-next-line
    const { cityDetails, stateDetails, countryDetails } = validationResponse;

    const parsedDob = moment(dob, 'DD/MM/YYYY', true);
    if (!parsedDob.isValid()) {
      return errorResponse(
        res,
        new Error(ValidDateFormat),
        InvalidDateFormat,
        statusCodes.VALIDATION_ERROR,
      );
    }
    const fullGender = Gender[gender];
    if (!fullGender) {
      return errorResponse(
        res,
        new Error(ValidationErrorMessage),
        InvalidGenderValue,
        statusCodes.VALIDATION_ERROR,
      );
    }

    user.phoneNumber = phoneNumber;
    user.fullName = fullName;
    user.email = email;
    user.countryCode = countryCode;
    user.gender = fullGender;
    user.dob = parsedDob.toDate();
    user.city = city;
    user.country = country;
    user.state = state;
    user.address = address;
    user.pincode = pincode;
    user.notifyMe = notifyMe;

    if (req.file) {
      const newProfilePictureUrl = await uploadProfilePicture(req.file, res);
      if (newProfilePictureUrl) {
        user.profilePicture = newProfilePictureUrl;
      } else {
        return;
      }
    }

    await user.save();

    user = await user.populate([
      { path: 'city', select: 'name' },
      { path: 'state', select: 'name' },
      { path: 'country', select: 'phoneCode name' },
    ]);

    if (!user.city || !user.state || !user.country) {
      return errorResponse(
        res,
        new Error(NotFoundErrorMessage),
        UserInfoRequiredMessage,
        statusCodes.NOT_FOUND,
      );
    }

    const updatedUser = {
      id: userId,
      fullName: user.fullName,
      phoneNumber: user.phoneNumber,
      email: user.email,
      gender: fullGender,
      profilePicture: user.profilePicture,
      dob: moment(user.dob).format('DD/MM/YYYY'),
      city: {
        id: user.city._id,
        cityName: user.city.name,
      },
      state: {
        id: user.state._id,
        stateName: user.state.name,
      },
      country: {
        id: user.country._id,
        countryName: user.country.name,
        countryCode: user.country.phoneCode,
      },
      notifyMe: user.notifyMe,
    };

    return successResponse(
      res,
      updatedUser,
      UserDataUpdatedSuccessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Update error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const deleteUser = async (req, res) => {
  try {
    const userId = req.user.userId;

    let user = await checkUserExists(userId, res);
    if (!user) return;

    user = await userModel.findByIdAndDelete(userId);
    return successResponse(
      res,
      undefined,
      AccountDeleteSucessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Delete account error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const socialLogin = async (req, res) => {
  const { provider, providerId, email, fullName } = req.body;
  try {
    if (!provider || !providerId || !email) {
      return errorResponse(
        res,
        new Error(ProviderProviderIDEmailRequired),
        ProviderProviderIDEmailRequired,
        statusCodes.VALIDATION_ERROR,
      );
    }

    const normalizedProvider = provider.trim().toLowerCase();
    const normalizedEmail = email.trim().toLowerCase();
    const normalizedProviderId = String(providerId).trim();

    let user = await userModel.findOne({ email: normalizedEmail });

    if (user) {
      if (!user.provider && !user.providerId) {
        user.provider = normalizedProvider;
        user.providerId = normalizedProviderId;
        await user.save();
      }

      if (
        user.provider.toLowerCase() !== normalizedProvider ||
        String(user.providerId).trim() !== normalizedProviderId
      ) {
        return errorResponse(
          res,
          new Error(ProviderDetailsDoNotMatch),
          ProviderDetailsDoNotMatch,
          statusCodes.UNAUTHORIZED,
        );
      }
    } else {
      user = new userModel({
        email: normalizedEmail,
        provider: normalizedProvider,
        providerId: normalizedProviderId,
        fullName: fullName || '',
      });
      await user.save();
    }

    const existingToken = req.headers.authorization?.split(' ')[1];

    if (existingToken && isTokenBlacklisted(existingToken)) {
      return errorResponse(
        res,
        new Error(blacklistedTokenMessage),
        blacklistedTokenMessage,
        statusCodes.UNAUTHORIZED,
      );
    }

    const accessToken = generateAccessToken(user);

    const userData = {
      id: user._id,
      fullName: user.fullName,
      email: user.email,
      provider: user.provider,
      providerId: user.providerId,
      isProfileComplete: user.isProfileComplete,
      gender: user.gender || '',
    };

    return successResponse(
      res,
      { ...userData, accessToken },
      userRegisterMessage,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Social login error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};
