import mongoose, { Schema } from 'mongoose';
import {
  emailRequiredMessage,
  emailUniqueMessage,
  fullNameRequiredMessage
} from '#constants/errorMessages.js';
import { Gender } from '../../enums/userEnum.js';
import {
  CityModelSchema,
  UserModelSchema,
} from '#constants/modelNameConstants.js';

const userSchema = new Schema(
  {
    fullName: {
      type: String,
      required: [true, fullNameRequiredMessage],
    },
    countryCode: {
      type: Number,
      default: 91,
    },
    phoneNumber: {
      type: String,
      default: '',
    },
    email: {
      type: String,
      required: [true, emailRequiredMessage],
      unique: [true, emailUniqueMessage],
    },
    dob: {
      type: Date,
    },
    password: {
      type: String
    },
    otp: {
      type: String,
      maxLength: 6,
      default: '000000',
    },
    isOTPVerified: {
      type: Boolean,
      default: false,
    },
    gender: {
      type: String,
      enum: Object.values(Gender),
    },
    profilePicture: {
      type: String,
      default: '',
    },
    houseNumber: {
      type: String,
      default: '',
    },
    address: {
      type: String,
      default: '',
    },
    pincode: {
      type: Number,
      default: 0,
    },
    city: {
      type: mongoose.Schema.Types.ObjectId,
      ref: CityModelSchema,
      default: null,
    },
    state: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'State',
      default: null,
    },
    country: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Country',
      default: null,
    },
    isProfileComplete: {
      type: Boolean,
      default: false,
    },
    notifyMe:{
      type: Boolean,
      default:true
    },
    provider:{
      type: String,
      default: ''
    },
    providerId:{
      type: String,
      default:''
    },
    deviceId:{
      type: String,
      default:''
    }
  },
  {
    timestamps: true,
  },
);

const User = mongoose.model(UserModelSchema, userSchema);

export default User;
