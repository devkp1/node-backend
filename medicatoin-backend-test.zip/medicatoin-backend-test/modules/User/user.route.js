import express from 'express';
import {
  forgotPassword,
  getUserProfile,
  loginUser,
  logoutUser,
  registerUser,
  resetPassword,
  userInfo,
  requestCode,
  verifyCode,
  deleteUser,
  UserUpdateProfile,
  socialLogin,
  registerGuestUser,
} from './user.controller.js';
import { isAuthenticateUser } from '#middleware/validateTokenHandler.js';
import { verifyToken } from '#middleware/verifyTokenHandler.js';
import upload from '#config/imageConfig/multer.config.js';

const userRoute = express.Router();

userRoute.route('/register-user').post(registerUser);
userRoute.route('/signin').post(loginUser);
userRoute
  .route('/add-user-info')
  .put(isAuthenticateUser, verifyToken, userInfo);
userRoute.route('/request-code').post(requestCode);
userRoute.route('/verify-code').post(verifyCode);
userRoute.route('/forgot-password').put(forgotPassword);
userRoute
  .route('/reset-password')
  .put(isAuthenticateUser, verifyToken, resetPassword);
userRoute.route('/logout').post(isAuthenticateUser, verifyToken, logoutUser);
userRoute
  .route('/reset-password')
  .put(isAuthenticateUser, verifyToken, resetPassword);
userRoute
  .route('/get-user')
  .get(isAuthenticateUser, verifyToken, getUserProfile);
userRoute
  .route('/update-profile')
  .put(
    isAuthenticateUser,
    verifyToken,
    upload.single('profilePicture'),
    UserUpdateProfile,
  );
userRoute
  .route('/delete-account')
  .delete(isAuthenticateUser, verifyToken, deleteUser);
userRoute
  .route('/social-login')
  .post(socialLogin)
userRoute
  .route('/guest-login')
  .post(registerGuestUser)

export default userRoute;
