import express from 'express';
import passport from 'passport';
import { createJwtToken } from '#root/utils/jwtHelper.js';
import { errorResponse } from '#root/utils/responseHandler.js';
import { ServerErrorMessage } from '#root/constants/errorMessages.js';
import { statusCodes } from '#root/constants/statusCodeMessages.js';


const authRoute = express.Router();


authRoute
  .route('/google')
  .get(passport.authenticate('google', { scope: ['profile', 'email'] }));

authRoute.route('/google/callback').get(
  passport.authenticate('google', {
    failureRedirect: '/login',
    failureMessage: true,
  }),
  (req, res) => {
    try {
      const token = createJwtToken(req.user);
      res.json({ token });
    } catch (error) {
      return errorResponse(
        res,
        error,
        ServerErrorMessage,
        statusCodes.SERVER_ERROR,
      );
    }
  },
);

authRoute
  .route('/facebook')
  .get(passport.authenticate('facebook', { scope: ['public_profile', 'email'] })); 
authRoute.route('/facebook/callback').get(
  passport.authenticate('facebook', {
    failureRedirect: '/login',
    failureMessage: true,
  }),
  (req, res) => {
    if (req.session.messages) {
      return errorResponse(
        res,
        req.session.messages,
        ServerErrorMessage,
        statusCodes.UNAUTHORIZED,
      );
    } else {
      try {
        const token = createJwtToken(req.user); 
        res.json({ token });
      } catch (error) {
        return errorResponse(
          res,
          error,
          ServerErrorMessage,
          statusCodes.SERVER_ERROR,
        );
      }
    }
  }
);

  


authRoute.route('/apple').get(passport.authenticate('apple'));

authRoute.route('/apple/callback').post(
  passport.authenticate('apple', {
    failureRedirect: '/login',
    failureMessage: true,
  }),
  (req, res) => {
    if (req.session.messages) {
      return errorResponse(
        res,
        req.session.messages,
        ServerErrorMessage,
        statusCodes.UNAUTHORIZED,
      );
    } else {
      try {
        const token = createJwtToken(req.user);
        res.json({ token });
      } catch (error) {
        return errorResponse(
          res,
          error,
          ServerErrorMessage,
          statusCodes.SERVER_ERROR,
        );
      }
    }
  },
);

export default authRoute;
