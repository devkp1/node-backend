import { UserModelSchema, notificationModelSchema } from '#root/constants/modelNameConstants.js';
import { deviceType } from '#root/enums/notificationEnum.js';
import mongoose from 'mongoose';

const NotificationSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: UserModelSchema,
  },
  androidFcmToken: {
    type: String,
    default:''
  },
  iosFcmToken: {
    type: String,
    default:''
  },
  deviceType: {
    type: String,
    enum: Object.values(deviceType), 
    required: true
  },
  deviceId: {
    type: String,
    default: ''
  },
  createdAt: {
    type: Date,
    default: Date.now 
  },
  updatedAt: {
    type: Date,
    default: Date.now  
  }
});


NotificationSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

const notificationModel = mongoose.model(notificationModelSchema, NotificationSchema);

export default notificationModel;
