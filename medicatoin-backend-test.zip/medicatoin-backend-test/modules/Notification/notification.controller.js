import { FcmTokenDeviceTypeRequired, InvalidDeviceType, ServerErrorMessage } from '#root/constants/errorMessages.js';
import { FcmTokenSavedSucessfully } from '#root/constants/responseMessages.js';
import { statusCodes } from '#root/constants/statusCodeMessages.js';
import logger from '#root/logger.js';
import { errorResponse, successResponse } from '#root/utils/responseHandler.js';
import notificationService from '../../services/notificationService.js';
import notificationModel from './notification.model.js';

export const sendNotification = async (req, res) => {
  const { registrationToken, message } = req.body;
  try {
    const response = await notificationService.sendNotification(
      registrationToken,
      message
    );

    return res.status(200).json({
      success: true,
      firebaseResponse: response.firebaseResponse,
      savedNotification: response.savedNotification,
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

export const createFcmToken = async (req, res) => {
  try {
    const userId = req.user.userId;

    const { fcmToken, deviceType: inputDeviceType, deviceId } = req.body;

    let deviceType;
    if (inputDeviceType === 'A') {
      deviceType = 'android';
    } else if (inputDeviceType === 'I') {
      deviceType = 'ios';
    } else if(inputDeviceType !=undefined || (inputDeviceType === 'A' ||inputDeviceType === 'I')){
      return successResponse(
        res,
        new Error(InvalidDeviceType),
        InvalidDeviceType,
        statusCodes.SUCCESS,
      );
    }

    if (!userId || !fcmToken || !deviceType) {
      return successResponse(
        res,
        new Error(FcmTokenDeviceTypeRequired),
        FcmTokenDeviceTypeRequired,
        statusCodes.SUCCESS,
      );
    }

    let notification = await notificationModel.findOne({ userId });

    if (notification) {
      if (deviceType === 'android') {
        notification.androidFcmToken = fcmToken;
      } else if (deviceType === 'ios') {
        notification.iosFcmToken = fcmToken;
      }

      notification.deviceId = deviceId || notification.deviceId;
    } else {
      notification = new notificationModel({
        userId,
        deviceType,
        deviceId,
        ...(deviceType === 'android'
          ? { androidFcmToken: fcmToken }
          : { isoFcmToken: fcmToken }),
      });
    }

    await notification.save();

    const formatNotification ={
      id : notification._id,
      userId : notification.userId,
      fcmToken: deviceType === 'android' ? notification.androidFcmToken : notification.iosFcmToken,
      deviceType:notification.deviceType,
      deviceId: notification.deviceId,

    }

    return successResponse(
      res,
      formatNotification,
      FcmTokenSavedSucessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`create FCM token error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};
