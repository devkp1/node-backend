import express from 'express';
import { createFcmToken, sendNotification } from './notification.controller.js';
import { isAuthenticateUser } from '#root/middleware/validateTokenHandler.js';
import { verifyToken } from '#root/middleware/verifyTokenHandler.js';

const notificationRoute = express.Router();


notificationRoute.route('/send-notification').post(sendNotification)
notificationRoute.route('/create-fcm-token').post(isAuthenticateUser,verifyToken,createFcmToken)



export default notificationRoute;