import Medicine from './medicine.model.js';
import { errorResponse, successResponse } from '#utils/responseHandler.js';
import {
  MedicationAlreadyExistsInDatabse,
  MedicationInsertSucessfully,
  ServerErrorMessage,
} from '#constants/errorMessages.js';
import { statusCodes } from '#constants/statusCodeMessages.js';
import {
  MedicineNotFound,
  MedicineSearchSuccessMessage,
} from '#constants/responseMessages.js';
import logger from '#root/logger.js';

export const getMedicine = async (req, res) => {
  try {
    const { query } = req;
    const searchquery = query.name || '';

    const startsWithQuery = await Medicine.find({
      medicineName: { $regex: `^${searchquery}`, $options: 'i' },
    });

    const containsQuery = await Medicine.find({
      medicineName: {
        $regex: searchquery,
        $options: 'i',
        $not: { $regex: `^${searchquery}`, $options: 'i' },
      },
    });

    const medicines = [...startsWithQuery, ...containsQuery];

    if (medicines.length === 0) {
      return successResponse(res, [], MedicineNotFound, statusCodes.SUCCESS);
    }

    const formeteddMedicine = medicines.map((medicine) => ({
      id: medicine._id,
      name: medicine.medicineName,
    }));

    return successResponse(
      res,
      formeteddMedicine,
      MedicineSearchSuccessMessage,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    logger.error(`Medicine search error: ${error.message}`);
    return errorResponse(
      res,
      error,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

// const response = [
//   { 'name': 'Dolo 650' },
//   { 'name': 'Crocin' },
//   { 'name': 'Calpol' },
//   { 'name': 'Tylenol' },
//   { 'name': 'Medol' },
//   { 'name': 'Crocin Advance' },
//   { 'name': 'Paracip' },
//   { 'name': 'P-500' },
//   { 'name': 'Calpol 650' },
//   { 'name': 'Brufen' },
//   { 'name': 'Ibugesic' },
//   { 'name': 'Combiflam' },
//   { 'name': 'Ibalgin' },
//   { 'name': 'Brufen Forte' },
//   { 'name': 'Ibufen' },
//   { 'name': 'Disprin' },
//   { 'name': 'Asprin' },
//   { 'name': 'Ecospirin' },
//   { 'name': 'Aspirin 75' },
//   { 'name': 'Aspirin 300' },
//   { 'name': 'Aten' },
//   { 'name': 'Ecotrin' },
//   { 'name': 'Voltaren' },
//   { 'name': 'Voveran' },
//   { 'name': 'Cataflam' },
//   { 'name': 'Dynapar' },
//   { 'name': 'Diclomol' },
//   { 'name': 'Dicloran' },
//   { 'name': 'Voveran SR' },
//   { 'name': 'Naprosyn' },
//   { 'name': 'Naprosyn SR' },
//   { 'name': 'Naprogesic' },
//   { 'name': 'Synflex' },
//   { 'name': 'Amox' },
//   { 'name': 'Mox' },
//   { 'name': 'Ospamox' },
//   { 'name': 'Augmentin' },
//   { 'name': 'Amclav' },
//   { 'name': 'Clavam' },
//   { 'name': 'Cifran' },
//   { 'name': 'Ciplox' },
//   { 'name': 'Cipro' },
//   { 'name': 'Ciprobid' },
//   { 'name': 'Cifran OD' },
//   { 'name': 'Ciproxin' },
//   { 'name': 'Cifran XR' },
//   { 'name': 'Zithromax' },
//   { 'name': 'Azithral' },
//   { 'name': 'Azithro' },
//   { 'name': 'Zmax' },
//   { 'name': 'Zitrolide' },
//   { 'name': 'Oflomac' },
//   { 'name': 'Floxotid' },
//   { 'name': 'Oflotab' },
//   { 'name': 'Oflox' },
//   { 'name': 'Levoflox' },
//   { 'name': 'Loflox' },
//   { 'name': 'Levolet' },
//   { 'name': 'Levoquin' },
//   { 'name': 'Tavanic' },
//   { 'name': 'Glycomet' },
//   { 'name': 'Glucophage' },
//   { 'name': 'Glimep' },
//   { 'name': 'Met XL' },
//   { 'name': 'Metformin' },
//   { 'name': 'Glucovance' },
//   { 'name': 'Daonil' },
//   { 'name': 'Gliben' },
//   { 'name': 'Glyciben' },
//   { 'name': 'Glimep' },
//   { 'name': 'Glibera' },
//   { 'name': 'Amaryl' },
//   { 'name': 'Glizid' },
//   { 'name': 'Glimet' },
//   { 'name': 'Diabeta' },
//   { 'name': 'Glizid-M' },
//   { 'name': 'Huminsulin' },
//   { 'name': 'Mixtard' },
//   { 'name': 'Lantus' },
//   { 'name': 'Novorapid' },
//   { 'name': 'Actrapid' },
//   { 'name': 'Insugen' },
//   { 'name': 'Norvasc' },
//   { 'name': 'Amlong' },
//   { 'name': 'Amlovas' },
//   { 'name': 'Amcard' },
//   { 'name': 'Amlosafe' },
//   { 'name': 'Amlon' },
//   { 'name': 'Zestril' },
//   { 'name': 'Lisinopril' },
//   { 'name': 'Prilace' },
//   { 'name': 'Monopril' },
//   { 'name': 'Lisino' },
//   { 'name': 'Lisinopril S' },
//   { 'name': 'Losar' },
//   { 'name': 'Lorzaar' },
//   { 'name': 'Hyzaar' },
//   { 'name': 'Losartan H' },
//   { 'name': 'Losartan Plus' },
//   { 'name': 'Ramace' },
//   { 'name': 'Coversyl' },
//   { 'name': 'Ramipril 5' },
//   { 'name': 'Ramiwos' },
//   { 'name': 'Triplix' },
//   { 'name': 'Lipitor' },
//   { 'name': 'Atorlip' },
//   { 'name': 'Torvast' },
//   { 'name': 'Aztor' },
//   { 'name': 'Lipvas' },
//   { 'name': 'Zocor' },
//   { 'name': 'Simcor' },
//   { 'name': 'Simvotin' },
//   { 'name': 'Simvyl' },
//   { 'name': 'Simglim' },
//   { 'name': 'Crestor' },
//   { 'name': 'Rosuvas' },
//   { 'name': 'Rosuvast' },
//   { 'name': 'Rosuvastatin' },
//   { 'name': 'Omez' },
//   { 'name': 'Losec' },
//   { 'name': 'Omepral' },
//   { 'name': 'Omez D' },
//   { 'name': 'Omeprazole' },
//   { 'name': 'Pan' },
//   { 'name': 'Pantocid' },
//   { 'name': 'Pantonix' },
//   { 'name': 'Protonix' },
//   { 'name': 'Pantoprex' },
//   { 'name': 'Zantac' },
//   { 'name': 'Rantac' },
//   { 'name': 'Ranidom' },
//   { 'name': 'Aciloc' },
//   { 'name': 'Zinetac' },
//   { 'name': 'Nexium' },
//   { 'name': 'Esomac' },
//   { 'name': 'Esomex' },
//   { 'name': 'Esomeprazole' },
//   { 'name': 'Prozac' },
//   { 'name': 'Fludac' },
//   { 'name': 'Fluox' },
//   { 'name': 'Fluoxetine' },
//   { 'name': 'Fluoxal' },
//   { 'name': 'Zoloft' },
//   { 'name': 'Serlift' },
//   { 'name': 'Sertralin' },
//   { 'name': 'Stresnil' },
//   { 'name': 'Elavil' },
//   { 'name': 'Amitrex' },
//   { 'name': 'Endep' },
//   { 'name': 'Trypzil' },
//   { 'name': 'Lexapro' },
//   { 'name': 'Cipralex' },
//   { 'name': 'Esita' },
//   { 'name': 'Serlift' },
//   { 'name': 'Zyrtec' },
//   { 'name': 'Cetzine' },
//   { 'name': 'Cetcip' },
//   { 'name': 'Reactine' },
//   { 'name': 'Claritin' },
//   { 'name': 'Lorfast' },
//   { 'name': 'Lora' },
//   { 'name': 'Loratadine' },
//   { 'name': 'Loratag' },
//   { 'name': 'Allegra' },
//   { 'name': 'Fexofen' },
//   { 'name': 'Fexo' },
//   { 'name': 'Fexofast' },
//   { 'name': 'Betnovate' },
//   { 'name': 'Celestone' },
//   { 'name': 'Betaderm' },
//   { 'name': 'Betasone' },
//   { 'name': 'Betasone-S' },
//   { 'name': 'Clob' },
//   { 'name': 'Clocip' },
//   { 'name': 'Dermovate' },
//   { 'name': 'Clobex' },
//   { 'name': 'Clobederm' },
//   { 'name': 'Bactroban' },
//   { 'name': 'Mupirocin' },
//   { 'name': 'Mupirocin Cream' },
//   { 'name': 'Muprox' },
//   { 'name': 'Hydrocot' },
//   { 'name': 'Coralan' },
//   { 'name': 'Cortiderm' },
//   { 'name': 'Hydrocortisone Cream' },
//   { 'name': 'D3 Max' },
//   { 'name': 'D3 60000' },
//   { 'name': 'Calcirol' },
//   { 'name': 'Drisdol' },
//   { 'name': 'Osteo-D' },
//   { 'name': 'Neurobion' },
//   { 'name': 'Methylcobalamin' },
//   { 'name': 'Cobadex' },
//   { 'name': 'Neurobion Forte' },
//   { 'name': 'Mecobalamin' },
//   { 'name': 'Ferradol' },
//   { 'name': 'Irofer' },
//   { 'name': 'Ferium' },
//   { 'name': 'Hemfer' },
//   { 'name': 'Sideral' },
//   { 'name': 'Aralen' },
//   { 'name': 'Resochin' },
//   { 'name': 'Chloroquine Phosphate' },
//   { 'name': 'Coartem' },
//   { 'name': 'Arteether' },
//   { 'name': 'Artemether' },
//   { 'name': 'Diflucan' },
//   { 'name': 'Flucoral' },
//   { 'name': 'Flunazole' },
//   { 'name': 'Mycoflox' },
//   { 'name': 'Sporanox' },
//   { 'name': 'Itrazol' },
//   { 'name': 'Itracon' },
//   { 'name': 'Itrafung' },
//   { 'name': 'Lamisil' },
//   { 'name': 'Terbinafine' },
//   { 'name': 'Lamisil AT' },
//   { 'name': 'Terbinex' },
//   { 'name': 'Zovirax' },
//   { 'name': 'Herpvir' },
//   { 'name': 'Acyclovir S' },
//   { 'name': 'Tamiflu' },
//   { 'name': 'Oset' },
//   { 'name': 'Oseltamivir 75mg' },
//   { 'name': 'Veklury' },
//   { 'name': 'Remdesivir' },
//   { 'name': 'Veklury 100mg' },
//   { 'name': 'Dilantin' },
//   { 'name': 'Epanutin' },
//   { 'name': 'Phenytoin' },
//   { 'name': 'Valparin' },
//   { 'name': 'Epival' },
//   { 'name': 'Valpro' },
//   { 'name': 'Depakote' },
//   { 'name': 'Keppra' },
//   { 'name': 'Levevit' },
//   { 'name': 'Epiep' },
//   { 'name': 'Eltroxin' },
//   { 'name': 'Thyronorm' },
//   { 'name': 'Euthyrox' },
//   { 'name': 'Thyroidinum' },
//   { 'name': 'Cytomel' },
//   { 'name': 'Liothyronine Sodium' },
//   { 'name': 'Eltroxin T3' },
//   { 'name': 'Ventolin' },
//   { 'name': 'Asthalin' },
//   { 'name': 'Salbair' },
//   { 'name': 'Salamol' },
//   { 'name': 'S-Breathe' },
//   { 'name': 'Pulmicort' },
//   { 'name': 'Symbicort' },
//   { 'name': 'Budesonide Inhaler' },
//   { 'name': 'Pulmicort Flexhaler' },
//   { 'name': 'Foradil' },
//   { 'name': 'Oxis' },
//   { 'name': 'Aerocort' },
//   { 'name': 'Foracort' },
//   { 'name': 'Depo-Provera' },
//   { 'name': 'Provera' },
//   { 'name': 'Depo-Medroxy' },
//   { 'name': 'Cyclofem' },
//   { 'name': 'Methotrex' },
//   { 'name': 'Trexal' },
//   { 'name': 'Emthexate' },
//   { 'name': 'Rheumatrex' },
//   { 'name': 'Glivec' },
//   { 'name': 'Imatin' },
//   { 'name': 'Imat' },
//   { 'name': 'Gleevec' },
//   { 'name': 'Taxol' },
//   { 'name': 'Paclitax' },
//   { 'name': 'Oncovin' },
//   { 'name': 'Tobradex' },
//   { 'name': 'Tobrex' },
//   { 'name': 'Tobramycin Opthalmic' },
//   { 'name': 'Xalatan' },
//   { 'name': 'Xalacom' },
//   { 'name': 'Yalantan' },
//   { 'name': 'Lioresal' },
//   { 'name': 'Bacloflex' },
//   { 'name': 'Baclofen' },
//   { 'name': 'Muscoril' },
//   { 'name': 'Sirdalud' },
//   { 'name': 'Tizadex' },
//   { 'name': 'Tizanil' },
//   { 'name': 'Coumadin' },
//   { 'name': 'Marevan' },
//   { 'name': 'Warfilon' },
//   { 'name': 'Warfar' },
//   { 'name': 'Eliquis' },
//   { 'name': 'Apixaban 5' },
//   { 'name': 'Apixaban 2.5' },
//   { 'name': 'Xarelto' },
//   { 'name': 'Rivaroxaban 10' },
//   { 'name': 'Rivaroxaban 20' }
// ];

const recomendedResponse = [
  { name: 'Paracetamol' },
  { name: 'Amoxicillin' },
  { name: 'Diominic DCA' },
];

export const insertMedications = async (req, res) => {
  try {
    const formattedMedications = recomendedResponse.map((med) => ({
      medicineName: med.name,
    }));

    const result = await Medicine.insertMany(formattedMedications, {
      ordered: false,
    });

    logger.info(`Successfully inserted ${result.length} medications.`);
    return successResponse(
      res,
      { insertedCount: result.length },
      MedicationInsertSucessfully,
      statusCodes.SUCCESS,
    );
  } catch (error) {
    if (error.name === 'BulkWriteError') {
      logger.warn(MedicationAlreadyExistsInDatabse);
      return errorResponse(
        res,
        MedicationAlreadyExistsInDatabse,
        ServerErrorMessage,
        statusCodes.SUCCESS,
      );
    }
    logger.error(`Error inserting medications: ${error.message}`);
    return errorResponse(
      res,
      error.message,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};

export const recomendedMedicine = async (req, res) => {
  try {
    const medications = [
      { _id: '6798b8c6b0e4be10b4448bf7', medicineName: 'Paracetamol' },
      { _id: '6798b8c6b0e4be10b4448bf8', medicineName: 'Amoxicillin' },
      { _id: '6798b8c6b0e4be10b4448bf9', medicineName: 'Diominic DCA' },
      { _id: '673481a23966b21e92008d05', medicineName: 'Dolo 650' },
      { _id: '673481a23966b21e92008d10', medicineName: 'Combiflam' },
    ];

    const { name = '', id = '' } = req.query;

    let filteredMedications = medications;

    if (id) {
      filteredMedications = medications.filter(
        (treatment) => treatment._id === id,
      );
    } else if (name) {
      const lowerCaseName = name.toLowerCase();
      filteredMedications = medications.filter((treatment) =>
        treatment.medicineName.toLowerCase().includes(lowerCaseName),
      );

      filteredMedications.sort((a, b) => {
        const aName = a.medicineName.toLowerCase();
        const bName = b.medicineName.toLowerCase();
        if (
          aName.startsWith(lowerCaseName) &&
          !bName.startsWith(lowerCaseName)
        ) {
          return -1;
        }
        if (
          !aName.startsWith(lowerCaseName) &&
          bName.startsWith(lowerCaseName)
        ) {
          return 1;
        }
        return 0;
      });
    }

    return res.status(200).json({
      success: true,
      data: filteredMedications,
      message:
        filteredMedications.length > 0
          ? 'medication search successful'
          : 'No medications found',
    });
  } catch (error) {
    logger.error(`Error fetching treatments: ${error.message}`);
    return errorResponse(
      res,
      error.message,
      ServerErrorMessage,
      statusCodes.SERVER_ERROR,
    );
  }
};
