import express from 'express';
import { getMedicine, insertMedications, recomendedMedicine } from './medicine.controller.js';

const medicineRoute = express.Router();

medicineRoute.route('/search-medicines').get(getMedicine);
medicineRoute.route('/sync-medication').post(insertMedications)
medicineRoute.route('/recomended-medicine').get(recomendedMedicine)

export default medicineRoute;
