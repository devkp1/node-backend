import { MedicineModelSchema } from '#constants/modelNameConstants.js';
import mongoose from 'mongoose';

const medicineSchema = new mongoose.Schema({
  medicineName: {
    type: String,
    required: true,
    unique: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

const Medicine = mongoose.model(MedicineModelSchema, medicineSchema);

export default Medicine;
