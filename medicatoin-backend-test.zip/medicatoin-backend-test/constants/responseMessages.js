export const successMessage = 'SUCCESS';
export const errorMessage = 'An error occurred';
export const userRegisterMessage = 'Register successfully.';
export const userLoginMessage = 'User Logged in successfully.';
export const userDataAddedSuccessfully = 'User info added successfully';
export const CodeVerifiedSucessfully = 'Code verified successfully';
export const OtpSentMessage = 'Code sent to email.';
export const passwordResetSuccessMessage = 'Password reset successfully.';
export const CountryGetSuccessfully = 'Countries retrieved successfully.';
export const StateGetSuccessfully = 'States retrieved successfully.';
export const CityGetSuccessfully = 'Cities retrieved successfully.';
export const PostalCodeGetSuccessfully = 'Postal code retrieved successfully.';
export const logoutSuccessfully = 'Logged out successfully.';
export const UserDetailsGetSucessfully = 'User details retrieved successfully.';
export const UserDataUpdatedSuccessfully = 'User updated successfully.';
export const PasswordResetSucessMessage = 'Password Reset successfully.';
export const AccountDeleteSucessfully = 'Account Deleted sucessfully.';
export const MedicineAddSucessfully = 'Medication Added sucessfully.';
export const MedicineSearchSuccessMessage = 'Medicines found successfully.';
export const MedicineNotFound =
  'No medicines found matching the search criteria.';
export const TreatmentSearchSuccessMessage = 'Treatments found successfully.';
export const TreatmenteNotFound =
  'No treatments found matching the search criteria.';
export const TreatmentCreationSuccessMessage = 'Treatment Added successfully.';
export const TreatmentCreationErrorMessage = 'Failed to Add treatment.';
export const TreatmentNotFoundMessage = 'Treatment not found';
export const TreatmentUpdateSuccessMessage = 'Treatment Updated successfully.';
export const MedicationDetailGetSucessfully =
  'Medication list retrieved successfully.';
export const NoDataFoundForSpecifiedRemider =
  'No data found for the specified reminder type.';
export const MedicationUpdateSucessfully = 'Medication updated sucessfully.';
export const TreatmentDetailGetSucessfully =
  'Treatment list retrieved successfully.';
export const StatuspauseSucessfully = 'Status paused successfully.';
export const StatusResumedSuccessfully = 'Status resumed successfully.';
export const MedicationDeleteSucessfully = 'Medication Deleted successfully.';
export const TreatmentDeletedSuccessfully = 'Treatment Deleted successfully.';
export const MedicationTreatmentSuspendSucessfully =
  'Medications/Treatments suspended successfully.';
export const SuspendedRecordsresumedSucessfully =
  'Suspended records resumed successfully.';
export const MenstruationAddSucessfully = 'Menstruation cycle add successfully.';
export const cycleLengthValidation = 'Cycle length must be a number between 1 and 31.';
export const MenstruationLengthValidation = 'Menstruation length must be a days between 2 and 60.';
export const MenstruationStartDateValidation = ' "Menstruation start date must be a valid date in this format DD/MM/YYYY.';
export const MenstruationDeletedSuccessfully = 'Menstruation Deleted successfully.';
export const MenstruationCycleUpdateSucessfully = 'Menstruation cycle updated successfully.';
export const MenstruationCycleGetSucessfully = 'Menstruation cycle retrieved successfully.';
export const PauseIsAlreadyExists = 'A pause already exists for the specified date range.';
export const MenstruationCycleResumeSucessfully = 'Menstruation cycle resume successfully.';
export const CyclePauseSucessfully =  'Menstruation cycle paused successfully.';
export const FcmTokenSavedSucessfully = 'FCM token saved successfully.';
export const StatusUpdatedSucessfully = 'Status updated successfully.';
export const GuestUserLoggedInSuccessfully =   'Guest user logged in successfully.';
export const TreatmentInsertSucessfully = 'Treatment Insert successfully.';
