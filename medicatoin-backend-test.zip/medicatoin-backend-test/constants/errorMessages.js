export const fullNameRequiredMessage = 'Name is required.';
export const fullNameCanNotBeEmptyMessage = 'Fullname can not be empty.';
export const emailRequiredMessage = 'Email is required.';
export const passwordRequiredMessage = 'Password is required.';
export const emailUniqueMessage = 'Email already exists.';
export const emailValidationMessage = 'Please enter a valid email address.';
export const strongPasswordValidationMessage =
  'Password must be 8-20 characters long, include at least one uppercase letter, one lowercase letter, one digit, and one special character.';
export const joiValidationMessage = 'Wrong validation.';
export const ValidationErrorMessage = 'Validation Error.';
export const NotFoundErrorMessage = 'Not found.';
export const UnauthorizedErrorMessage = 'Unauthorized!';
export const ForbiddenErrorMessage = 'Forbidden!';
export const ServerErrorMessage = 'Internal Server Error!';
export const EmailPasswordMatchMessage =
  'Email or password does not match. Please try again.';
export const EmailAndPasswordRequiredMessage =
  'Email and password are required.';
export const UserNotFoundMessage = 'User not found.';
export const TokenErrorMessage = 'please login to access this resource.';
export const blacklistedTokenMessage = 'Authorization failed! Token expired';
export const InvalidTokenErrorMessage = 'Invalid token.';
export const AdditionalFeildsErrorMessage =
  'Additional fields are not allowed.';
export const DuplicateFieldsErrorMessage = 'This field is already exists.';
export const InvalidOrExpireOTP = 'Invalid or expired Code';
export const PostalCodeEmptyParameterMessage =
  'Please check city name and try again.';
export const CityEmptyParameterMessage =
  'Please Check state code, country code and try again.';
export const StateEmptyParameterMessage =
  'Please Check country code and try again.';
export const PostalCodeNotFoundMessage = 'Postal code not found.';
export const CitiesNotFoundMessage = 'Cities not found.';
export const StateNotFoundMessage = 'States not found. ';
export const CountriesNotFoundMessage =
  'Countries not found. Please try again later.';
export const PasswordNotMatch =
  'New password and confirm password do not match';
export const IncorrectCurrentPassword = 'Current password is incorrect';
export const PasswordShouldNotSame =
  'New password should not be same as Existing';
export const PasswordResetSuccessMessage = 'Password reset successfully';
export const UserInfoRequiredMessage =
  'Can not found Details, Please add user information.';
export const ImageUploadErrorMessage = 'Image can not find.';
export const CityIsNotValidAsPerStateAndCountryMessage =
  'The provided city does not belong to the provided state and country.';
export const CityStateCountryDoNotMatchMessage =
  'The provided city, state, and country do not match.';
export const InvalidCityIDMessage = 'Invalid city ID.';
export const InvalidCityMessage = 'Invalid city.';
export const InvalidCountryIDMessage = 'Invalid country ID.';
export const InvalidCountryMessage = 'Invalid country.';
export const InvalidStateIDMessage = 'Invalid state ID.';
export const InvalidStateMessage = 'Invalid state.';
export const UpdateStateAndCityMessage =
  'Please update both state and city when updating country.';
export const UpdateCountryAndCityMessage =
  'Please update both country and city when updating state.';
export const UpdateCountryAndStateMessage =
  'Please update both country and state when updating city.';
export const startDateAndEndDateValidation =
  'Start date must be before end date.';
export const customDaysRequired =
  'Custom days can not be empty,Please add a value.';
export const InvalidFrequencyOfTimeFrequency = 'Invalid time frequency type.';
export const InvalidTimeFormate = 'Invalid time format.';
export const InvalidMedicationType = 'Invalid Medication type.';
export const InvalidMedicationUnit = 'Invalid Medication Unit.';
export const InvalidMedicationFoodTime = 'Invalid Medication food-time .';
export const NumberOfMedicationGreaterThanZero =
  'Number of medication must be greater than 0.';
export const MedicationNameRequired = 'Medication name required.';
export const MedicationStrengthRequired = 'Medication strength required.';
export const InvalidTimeEntriesMessage =
  'Invalid number of time entries provided.';
export const sessionsValidationMessage =
  'Number of sessions must be greater than 0.';
export const InvalidFrequencyValue = 'Invalid frequency type.';
export const InvalidTimeFormat = 'Invalid time format';
export const InvalidReminderType =
  'Invalid reminderType. Allowed values are "medication", "treatment", or "all".';
export const InvalidDateFormat = 'Invalid Date format';
export const NoDataFoundForSpecifiedReminder =
  'No data found for specified reminder.';
export const MedicationStrengthMustBeGreaterThanZero =
  'Medication strength must be greater than zero.';
export const MedicationNameCannotBeEmpty = 'Medication name can not be empty.';
export const MedicationNotFound =
  'Medication not found, Please provide correct ID.';
export const StartDateEndDateRequireMessage =
  'Both start date and end date are required.';
export const InvalidStatusMessage = 'Invalid status provided.';
export const StatusUpdatedSucessfullMesssage = 'Status updated successfully.';
export const RecordNotFoundMessage = 'Record not found, Please verify ID';
export const InvalidTimeMessage = 'Invalid Time.';
export const DateOutOfRangeMessage = 'Date Out Of Range.';
export const StartDateGreterthenEndDateMessage =
  'Start date cannot be greater than end date.';
export const InvalidDaysFrequencyMessage = 'Invalid days in frequency array.';
export const InvalidFrequencyType = 'Invalid frequency type.';
export const MedicationAlreadyPausedMessage =
  'Medication is already paused within the given date range.';
export const MedicationCanNotPausedMessage =
  'Cannot pause an medication that is already paused during this period.';
export const CanNotUpdateStatusDuringPause =
  'Cannot update status during pause period.';
export const StatusIsPausedForThisDate = 'The status is paused for this date.';
export const PauseStartDateIsGreathenEndDate =
  'Pause start date must be grater than pause end date.';
export const InvalidDateRange = 'Invalid Date Range.';
export const PauseStartDateRequired = 'pauseStartDate must be Required.';
export const NoActivePauseForProvidedResumeDate =
  'No active pause found for the provided resume date.';
export const ResumeDateNotFound = 'Resume Date Not Found.';
export const InvalidRequest =
  'Invalid request. Either pauseStartDate or resumeDate must be provided.';
export const StartDateEndDateRequired = 'Startdate and Enddate Required.';
export const TreatmentNameRequired = 'Treatment Name required.';
export const InvalidDaysInFrequencyArray = 'Invalid days in frequency array.';
export const ValidDateFormat = 'Invalid date format. Please use DD/MM/YYYY.';
export const CanNotUpdateStatusDuringSuspend =
  'Can not update status during suspend period.';
export const StatusIsSuspendedForThisDate =
  'The status is suspended for this date.';
export const MedicationTreatmentAlredySuspend =
  'Medication/Treatment already suspended.';
export const InvalidSuspendDays = 'Invalid suspend days.';
export const SuspendDaysFieldrequired =
  'SuspendDays field is required and must be a valid number between 1 and 99.';
export const SuspendDaysEligibleLength =
  'SuspendDays must be between 1 and 99.';
export const StatusCannotBeUpdatedUntilResumed =
  'Status can not be Updated until resumed.';
export const NoActiveSuspendForResumeDate = 'No active suspend for Resume';
export const SuspendedDaysNotBeProvidedWhenResuming =
  'SuspendDays should not be provided when resuming.';
export const SuspendApplied = 'Suspension applied.';
export const AuthorizationFailed = 'Authorization failed! Token expired.';
export const PausePeriodDoesNotIntersectWithDateRange =
  'Pause/Suspend period does not intersect with date range.';
export const InvalidpauseStartOrEndDate = 'Invalid pause start or end date.';
export const InvalidStatus = 'Invalid status.';
export const InvalidFilterValue = 'Invalid filter value.';
export const InvalidSetScedule =
  'Invalid schedule. Must be a valid key 1 to 6 for setSchedule.';
export const ValidTimeFormatMessage =
  'Invalid time format. Time must be in HH:mm format.';
export const MenstruationCycleNotFound =
  'Menstruation cycle not found.';
export const cycleLengthCanNotBeEmpty =
  'Cycle length can not be empty.';
export const GenderValidation =
  'Only females are allowed to add a menstruation cycle.';
export const GenderNotFound =
  'Gender can not recognized, Please Add gender. ';
export const GenderDOBrequired =
'Gender and Date of Birth are required fields.';
export const InvalidGenderValue =
'Invalid gender value.';
export const NoActivePauseFound =
'No active pause found to resume.';
export const InvalidRequestPauseResume = 'Invalid request. No valid pause or resume action found.';
export const CycleNotFound = 'Cycle not found.';
export const CanNotUpdateStatus = 'Cannot update status while the cycle is paused.';
export const NoActiveFoundForCompleted =  'No active status found to mark this cycle as completed.';
export const CanNotAddAnotherCompletedWithoutActiveStatus =  'Cannot add another completed status without a preceding active status.';
export const CanNotAddAnotherActiveWithoutCompletedStatus =   'Cannot set status to "active" when the last status is already "active". Complete the previous cycle first.';
export const CanNotAddMultipleCompletedStatus =   'Cannot add multiple consecutive completed statuses.';
export const StatusCompletedDateGratherThanActiveStartDate =  'Status completed date Should graterthan active start date.';
export const InvalidActiveDateToMeasureCycle ='Can not able to measure your cycle, Please check activeDate.';
export const InavlidDaysInFrequencyArray = 'Invalid days in frequency array.';
export const provideTimesAndNumber = 'Please provide times & numberOfCapsule.';
export const CompletedDaysGratherThanActiveStartDate =  'Completed days Should in between  0 to 15.';
export const AutoCompletedMustBeBoolenValue =  'AutoCompleted must be a boolean value (true or false).' ;
export const NoStatusFound = 'No status found.' ;
export const DateRequired = 'date is required for update status.' ;
export const TimeRequired = 'time is required for update status.' ;
export const ProviderProviderIDEmailRequired= 'Provider, Provider ID, and email are required.';
export const ProviderDetailsDoNotMatch= 'Provider details do not match.';
export const FcmTokenDeviceTypeRequired =' fcmToken and deviceType are required.';
export const InvalidDeviceType ='Invalid device type.';
export const NotificationSendingFailed ='Notification sending failed.';
export const NoRecordsFoundForSuspend = 'No record found for suspend.';
export const CycleIsAlreadyExistMessage = 'User already has an existing cycle. Only one cycle is allowed.';
export const MedicationInsertSucessfully ='medication insert sucessfully.';
export const MedicationAlreadyExistsInDatabse =  'Some medications already exist in the database. Skipping duplicates.';
export const DeviceIDIsRequired =  'Device ID is required';
export const ProfileUpdateNotAlowedForGuestUsers=  'Profile update not allowed for guest users';
export const InvalidPhoneNumber =   'Invalid phone number.';
export const TreatmentAlreadyExistsInDatabse =  'Treatment Already Exists In Databse';