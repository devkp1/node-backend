export const MedicationAddedNotification = (medicationName, medicationId) => {
  return {
    title: 'Medication Added',
    body: `🎉💊 Hooray! You’ve just added ${medicationName} to your Medication. Check your list for details!`,
    data: { medicationId: medicationId.toString() },
  };
};

export const MedicationUpdatedNotification = (medicationName,medicationId) => {
  return {
    title: 'Medication Updated',
    body: `🔄⚠️ Update Alert! ${medicationName} has been refreshed. Take a look at the latest details!`,
    data: { medicationId: medicationId.toString() },
  };
};

export const TreatmentAddedNotification = (treatmentName, treatmentId) => {
  return {
    title: 'Treatment Added',
    body: `🎉💊 Hooray! You’ve just added ${treatmentName} to your Treatment. Check your list for details!`,
    data: { treatmentId: treatmentId.toString() },
  };
};

export const TreatmentUpdatedNotification = (treatmentName,treatmentId) => {
  return {
    title: 'Treatment Updated',
    body: `🔄⚠️ Update Alert! ${treatmentName} has been refreshed. Take a look at the latest details!`,
    data: { treatmentId: treatmentId.toString() },
  };
};

export const MedicationEndReminderNotification = (notificationMessage, remainingDoses) => {
  return {
    title: 'Expiration Alert',
    body: notificationMessage,
    data: { remainingDoses: remainingDoses.toString() },
  };
};

export const TreatmentEndReminderNotification = (notificationMessage, remainingSessions) => {
  return {
    title: 'Expiration Alert',
    body: notificationMessage,
    data: { remainingSessions: remainingSessions.toString() },
  };
};

export const MorningMedicationTreatmenttReminderNotification = (notificationMessage, remainingSessions) => {
  return {
    title: 'Morning Medication Reminder',
    body: notificationMessage,
    data: { remainingSessions: remainingSessions.toString() },
  };
};

export const NoMorningMedicationTreatmenttReminderNotification = ( user_id) => {
  return {
    title: 'Morning Medication Reminder',
    body: 'Good morning! ☀️ Remember, today is a fresh start filled with opportunities. Take a moment to set your intentions and tackle your meds with positivity. You\'ve got this! 🌟',
    data: { user_id: user_id.toString() },
  };
};

export const UpcomingCycleReminder = (cycleId) => {
  return {
    title: 'Upcoming Cycle Reminder',
    body: '🔜🩸 Your next period is just around the corner! Prepare yourself.',
    data: { cycleId: cycleId.toString() },
  };
};


export const BeforePeriodStartReminder = (cycleId) => {
  return {
    title: 'Before Period Start Reminder',
    body: 'Hey! Just a friendly reminder that your menstrual cycle is starting today. Make sure to take care of yourself! 💕',
    data: { cycleId: cycleId.toString() },
  };
};

export const PeriodStartReminder = (cycleId) => {
  return {
    title: 'Period Start Reminder',
    body: '🩸📅 Hey there! Your period starts today. Time to grab your essentials!',
    data: { cycleId: cycleId.toString() },
  };
};

export const MorningCycleReminder = (cycleId) => {
  return {
    title: 'Good Morning!',
    body: '🌼☕ Good morning! Remember to take it easy today. Treat yourself to something comforting and stay cozy! ',
    data: { cycleId: cycleId.toString() },
  };
};

export const SleepCycleReminder = (cycleId) => {
  return {
    title: 'Sleep Reminder!',
    body: '😴🌙 Getting enough rest is important! Aim for a cozy night’s sleep.',
    data: { cycleId: cycleId.toString() },
  };
};

export const firstCycleReminder = (cycleId) => {
  return {
    title: 'Health Tip of the Day',
    body: '💧💖 Tip for today: Staying hydrated can help ease cramps. Drink up!',
    data: { cycleId: cycleId.toString() },
  };
};

export const secondCycleReminder = (cycleId) => {
  return {
    title: 'Comfort Tip',
    body: '🛁❤️ Need some comfort? A warm bath or heating pad can do wonders!',
    data: { cycleId: cycleId.toString() },
  };
};

export const thirdCycleReminder = (cycleId) => {
  return {
    title: 'Dietary Tips',
    body: '🥦🍫 Craving something? Foods rich in magnesium can ease menstrual discomfort!',
    data: { cycleId: cycleId.toString() },
  };
};

export const fourthCycleReminder = (cycleId) => {
  return {
    title: 'Exercise Suggestion',
    body: '🏋️‍♀️✨ Feeling up for a workout? Light exercise can help with cramps!',
    data: { cycleId: cycleId.toString() },
  };
};


export const fifthCycleReminder = (cycleId) => {
  return {
    title: 'Self-Care Reminder',
    body: '🌸🛀 Don’t forget to take some time for yourself today. You deserve it!',
    data: { cycleId: cycleId.toString() },
  };
};

export const MenstruationCycleAddedNotification = ( cycleId) => {
  return {
    title: 'Menstruation cycle Added',
    body: '💕 Hey there! You’ve just added Menstruation cycle. Check your list for details!',
    data: { cycleId: cycleId.toString() },
  };
};

export const MenstruationCycleUpdatedNotification = (cycleId) => {
  return {
    title: 'Menstruation cycle Updated',
    body: '🔄⚠️ Update Alert! your Menstruation cycle has been refreshed. Take a look at the latest details!',
    data: { cycleId: cycleId.toString() },
  };
};
