import Joi from 'joi';
import {
  emailRequiredMessage,
  emailValidationMessage,
  fullNameCanNotBeEmptyMessage,
  fullNameRequiredMessage,
  passwordRequiredMessage,
  strongPasswordValidationMessage,
} from '../constants/errorMessages.js';
import { emailRegex, passwordRegex } from '../constants/regexConstants.js';

export const userValidations = Joi.object({
  fullName: Joi.string().min(3).max(40).required(fullNameRequiredMessage),
  email: Joi.string()
    .email()
    .pattern(new RegExp(emailRegex))
    .required()
    .messages({
      'string.pattern.base': emailValidationMessage,
      'any.required': emailRequiredMessage,
    }),
  password: Joi.string()
    .pattern(new RegExp(passwordRegex))
    .required()
    .messages({
      'string.pattern.base': strongPasswordValidationMessage,
      'any.required': passwordRequiredMessage,
    }),
});

export const loginValidations = Joi.object({
  email: Joi.string().pattern(new RegExp(emailRegex)).required().messages({
    'string.pattern.base': emailValidationMessage,
    'any.required': emailRequiredMessage,
  }),
  password: Joi.string().required().messages({
    'any.required': passwordRequiredMessage,
  }),
});

export const resetPasswordValidations = Joi.object({
  newPassword: Joi.string().pattern(passwordRegex).required().messages({
    'string.pattern.base': strongPasswordValidationMessage,
    'any.required': passwordRequiredMessage,
  }),
  confirmNewPassword: Joi.string().pattern(passwordRegex).required().messages({
    'string.pattern.base': strongPasswordValidationMessage,
    'any.required': passwordRequiredMessage,
  }),
});

export const userUpdateValidations = Joi.object({
  fullName: Joi.string().min(3).max(40).optional().allow(null, '').messages({
    'string.min': 'Full name should have a minimum length of 3',
    'string.max': 'Full name should have a maximum length of 40',
    'string.empty': fullNameCanNotBeEmptyMessage,
  }),
  email: Joi.string().pattern(new RegExp(emailRegex)).required().messages({
    'string.pattern.base': emailValidationMessage,
    'any.required': emailRequiredMessage,
  }),
});

export const forgotPasswordValidations = Joi.object({
  newPassword: Joi.string().pattern(passwordRegex).required().messages({
    'string.pattern.base': strongPasswordValidationMessage,
    'any.required': passwordRequiredMessage,
  }),
});
