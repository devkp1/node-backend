import moment from 'moment';
import {
  InavlidDaysInFrequencyArray,
  InvalidFrequencyOfTimeFrequency,
  InvalidFrequencyValue,
  InvalidMedicationFoodTime,
  InvalidMedicationType,
  InvalidMedicationUnit,
  InvalidTimeFormate,
  MedicationNameCannotBeEmpty,
  MedicationNameRequired,
  MedicationStrengthMustBeGreaterThanZero,
  NumberOfMedicationGreaterThanZero,
  provideTimesAndNumber,
  startDateAndEndDateValidation,
} from '#constants/errorMessages.js';
import {
  medicationFoodTime,
  medicationFrequency,
  medicationTimeFrequency,
  medicationType,
  medicationUnit,
} from '#enums/medicationEnum.js';
import { validateTimeFormat } from '#constants/regexConstants.js';

export const validateMedicationData = (data) => {
  const {
    medicationName,
    startDate,
    endDate,
    type,
    strength = 0,
    unit = '',
    frequency = 'Everyday',
    foodTime = 'After meal',
    timeFrequency,
    times = [],
    numberOfCapsule = [],
  } = data;

  if (!medicationName || medicationName.trim() === '') {
    return { valid: false, error: MedicationNameRequired };
  }

  if (!Object.values(medicationType).includes(type)) {
    return { valid: false, error: InvalidMedicationType };
  }

  if (unit !== '' && !Object.values(medicationUnit).includes(unit)) {
    return { valid: false, error: InvalidMedicationUnit };
  }

  if (!Object.values(medicationFoodTime).includes(foodTime)) {
    return { valid: false, error: InvalidMedicationFoodTime };
  }

  if (strength !== 0 && (typeof strength !== 'number' || strength <= 0)) {
    return { valid: false, error: MedicationStrengthMustBeGreaterThanZero };
  }

  if (typeof frequency === 'string') {
    if (!Object.values(medicationFrequency).includes(frequency)) {
      return { valid: false, error: InvalidFrequencyValue };
    }
  } else if (Array.isArray(frequency)) {
    if (frequency.some((day) => !medicationFrequency.custom.includes(day))) {
      return { valid: false, error: InavlidDaysInFrequencyArray };
    }
  } else {
    return { valid: false, error: InvalidFrequencyValue };
  }

  if (
    timeFrequency &&
    (!times || times.length === 0) &&
    (!numberOfCapsule || numberOfCapsule.length === 0)
  ) {
    return { valid: false, error: provideTimesAndNumber };
  }

  const finalTimeFrequency = timeFrequency || 'Once a Day';
  const expectedCount = medicationTimeFrequency[finalTimeFrequency];

  if (!Object.keys(medicationTimeFrequency).includes(finalTimeFrequency)) {
    return { valid: false, error: InvalidFrequencyOfTimeFrequency };
  }

  if (times.length === 0) {
    data.times = Array(expectedCount).fill('12:00');
  } else if (times.length !== expectedCount) {
    return {
      valid: false,
      error: `The selected timeFrequency requires exactly ${expectedCount} time(s). You provided ${times.length}.`,
    };
  } else {
    try {
      const formattedTimes = times.map((time) => {
        if (!validateTimeFormat(time)) {
          throw new Error(`Invalid time format: ${time}`);
        }
        const [hours, minutes] = time.split(':');
        return `${hours.padStart(2, '0')}:${minutes.padStart(2, '0')}`;
      });
      data.times = formattedTimes;

      // eslint-disable-next-line
    } catch (error) {
      return { valid: false, error: InvalidTimeFormate };
    }
  }

  if (numberOfCapsule.length === 0) {
    data.numberOfCapsule = Array(expectedCount).fill(1);
  } else if (numberOfCapsule.length !== expectedCount) {
    return {
      valid: false,
      error: `The selected timeFrequency requires exactly ${expectedCount} capsules. You provided ${numberOfCapsule.length}.`,
    };
  } else if (numberOfCapsule.some((count) => count < 1)) {
    return { valid: false, error: NumberOfMedicationGreaterThanZero };
  }

  const formattedStartDate = moment
    .utc(startDate, 'DD/MM/YYYY')
    .startOf('day')
    .toDate();
  const formattedEndDate = moment
    .utc(endDate, 'DD/MM/YYYY')
    .endOf('day')
    .toDate();

  if (formattedStartDate >= formattedEndDate) {
    return { valid: false, error: startDateAndEndDateValidation };
  }

  data.startDate = formattedStartDate;
  data.endDate = formattedEndDate;
  data.frequency = frequency;
  data.foodTime = foodTime;
  data.timeFrequency = finalTimeFrequency;
  data.unit = unit;
  data.strength = strength;

  return { valid: true, data };
};

export const UpdatevalidateMedicationData = (data) => {
  const {
    medicationName,
    startDate,
    endDate,
    type,
    strength,
    unit,
    frequency,
    foodTime,
    timeFrequency,
    times,
    numberOfCapsule,
  } = data;

  if (medicationName && medicationName.trim() === '') {
    return { valid: false, error: MedicationNameCannotBeEmpty };
  }

  if (
    strength !== undefined &&
    (typeof strength !== 'number' || strength <= 0)
  ) {
    return { valid: false, error: MedicationStrengthMustBeGreaterThanZero };
  }

  if (type !== undefined && !Object.values(medicationType).includes(type)) {
    return { valid: false, error: InvalidMedicationType };
  }

  if (unit !== undefined && !Object.values(medicationUnit).includes(unit)) {
    return { valid: false, error: InvalidMedicationUnit };
  }

  if (
    foodTime !== undefined &&
    !Object.values(medicationFoodTime).includes(foodTime)
  ) {
    return { valid: false, error: InvalidMedicationFoodTime };
  }

  if (typeof frequency === 'string') {
    if (!Object.values(medicationFrequency).includes(frequency)) {
      return { valid: false, error: InvalidFrequencyValue };
    }
  } else if (Array.isArray(frequency)) {
    if (frequency.some((day) => !medicationFrequency.custom.includes(day))) {
      return { valid: false, error: 'Invalid days in frequency array' };
    }
  } else {
    return { valid: false, error: InvalidFrequencyValue };
  }

  if (
    timeFrequency !== undefined &&
    !Object.keys(medicationTimeFrequency).includes(timeFrequency)
  ) {
    return { valid: false, error: InvalidFrequencyOfTimeFrequency };
  }

  if (timeFrequency && times) {
    const expectedCount = medicationTimeFrequency[timeFrequency];
    if (expectedCount && times.length !== expectedCount) {
      return {
        valid: false,
        error: `The selected timeFrequency requires exactly ${expectedCount} time(s). You provided ${times.length}.`,
      };
    }
  }
  const expectedCount = medicationTimeFrequency[timeFrequency];
  if (expectedCount && numberOfCapsule.length !== expectedCount) {
    return {
      valid: false,
      error: `The selected timeFrequency requires exactly ${expectedCount} times ${type}. You provided ${numberOfCapsule.length}.`,
    };
  }
  if (
    numberOfCapsule !== undefined &&
    numberOfCapsule.some((count) => count < 1)
  ) {
    return { valid: false, error: NumberOfMedicationGreaterThanZero };
  }

  if (times) {
    try {
      const formattedTimes = times.map((time) => {
        if (!validateTimeFormat(time)) {
          throw new Error(`Invalid time format: ${time}`);
        }
        const [hours, minutes] = time.split(':');
        return `${hours.padStart(2, '0')}:${minutes.padStart(2, '0')}`;
      });
      data.times = formattedTimes;
      // eslint-disable-next-line
    } catch (error) {
      return { valid: false, error: InvalidTimeFormate };
    }
  }

  let formattedStartDate = null;
  let formattedEndDate = null;

  if (startDate) {
    formattedStartDate = moment
      .utc(startDate, 'DD/MM/YYYY')
      .startOf('day')
      .toDate();
    data.startDate = formattedStartDate;
  }

  if (endDate) {
    formattedEndDate = moment.utc(endDate, 'DD/MM/YYYY').endOf('day').toDate();
    data.endDate = formattedEndDate;
  }

  if (
    formattedStartDate &&
    formattedEndDate &&
    formattedStartDate >= formattedEndDate
  ) {
    return { valid: false, error: startDateAndEndDateValidation };
  }

  return { valid: true, data };
};
