import {
  AutoCompletedMustBeBoolenValue,
  CompletedDaysGratherThanActiveStartDate,
  InvalidSetScedule,
  ValidTimeFormatMessage,
} from '#root/constants/errorMessages.js';
import { validateTimeFormat } from '#root/constants/regexConstants.js';
import {
  MenstruationLengthValidation,
  MenstruationStartDateValidation,
  cycleLengthValidation,
} from '#root/constants/responseMessages.js';
import { setSchedule } from '#root/enums/cycleEnum.js';
import moment from 'moment';


export const validateCycleInput = (cycleData) => {
  const {
    cycleLength,
    menstruationLength,
    menstruationStartDate,
    scheduleDayBefore,
    time,
    autoCompleted,
    completedDays
  } = cycleData;


  if (cycleLength !== undefined && ( typeof cycleLength !== 'number' || cycleLength < 1 || cycleLength > 31) )  {
    return { valid: false, error: cycleLengthValidation };
  }

  if (
    menstruationLength !== undefined &&  
  (typeof menstruationLength !== 'number' ||
    menstruationLength < 2 ||
    menstruationLength > 60
  )) {
    return { valid: false, error: MenstruationLengthValidation };
  }


  if (scheduleDayBefore !== undefined) {
    if (
      typeof scheduleDayBefore !== 'number' ||
      !(scheduleDayBefore in setSchedule)
    ) {
      return { valid: false, error: InvalidSetScedule };
    }
    cycleData.scheduleDayBefore = setSchedule[scheduleDayBefore];
  }

  if (completedDays !== undefined && (typeof completedDays !== 'number' || completedDays <= 0 || completedDays >=15)) {
    return { valid: false, error: CompletedDaysGratherThanActiveStartDate };
  }

  if (autoCompleted !== undefined && typeof autoCompleted !== 'boolean') {
    return { valid: false, error: AutoCompletedMustBeBoolenValue };
  }

  const parsedStartDate = moment.utc(menstruationStartDate, 'DD/MM/YYYY', true);
  if (!menstruationStartDate || !parsedStartDate.isValid()) {
    return { valid: false, error: MenstruationStartDateValidation };
  }

  const utcStartDate = parsedStartDate.utc().toDate();
  cycleData.menstruationStartDate = utcStartDate;


  if (time && !validateTimeFormat(time)) {
    return { valid: false, error: ValidTimeFormatMessage };
  }

  return { valid: true, data: cycleData };
};

export const UpdateValidateCycleInput = (cycleData) => {
  const {
    cycleLength,
    menstruationLength,
    menstruationStartDate,
    scheduleDayBefore,
    time,
    autoCompleted,
    completedDays
  } = cycleData;

  
  if (cycleLength !== undefined && (cycleLength === '' || typeof cycleLength !== 'number' || cycleLength < 1 || cycleLength > 31)) {
    return { valid: false, error: cycleLengthValidation };
  }

  if (menstruationLength !== undefined && (menstruationLength === '' || typeof menstruationLength !== 'number' || menstruationLength < 2 || menstruationLength > 60)) {
    return { valid: false, error: MenstruationLengthValidation };
  }

  if (completedDays !== undefined && (typeof completedDays !== 'number' || completedDays <= 0)) {
    return { valid: false, error: CompletedDaysGratherThanActiveStartDate };
  }

  if (autoCompleted !== undefined && typeof autoCompleted !== 'boolean') {
    return { valid: false, error: AutoCompletedMustBeBoolenValue };
  }

  if (menstruationStartDate !== undefined) {
    if (menstruationStartDate === '') {
      return { valid: false, error: MenstruationStartDateValidation };
    }

  
    const parsedStartDate = moment(menstruationStartDate, 'DD/MM/YYYY', true);
    if (!parsedStartDate.isValid()) {
      return { valid: false, error: MenstruationStartDateValidation };
    }

   
    const utcStartDate = parsedStartDate.utc().toDate();
    cycleData.menstruationStartDate = utcStartDate;
  }


  if (scheduleDayBefore !== undefined) {
    if (typeof scheduleDayBefore !== 'number' || !(scheduleDayBefore in setSchedule)) {
      return { valid: false, error: InvalidSetScedule };
    }
    
    cycleData.scheduleDayBefore = setSchedule[scheduleDayBefore];
  }


  if (time && !validateTimeFormat(time)) {
    return { valid: false, error: ValidTimeFormatMessage };
  }

  return { valid: true, data: cycleData };
};