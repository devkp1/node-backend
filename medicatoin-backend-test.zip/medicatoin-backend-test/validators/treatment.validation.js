import moment from 'moment';
import { validateTimeFormat } from '#constants/regexConstants.js';
import {
  InvalidDaysInFrequencyArray,
  InvalidFrequencyOfTimeFrequency,
  InvalidFrequencyValue,
  InvalidTimeFormate,
  TreatmentNameRequired,
  sessionsValidationMessage,
  startDateAndEndDateValidation,
} from '#constants/errorMessages.js';
import {
  treatmemtFrequency,
  treatmentFrequencyTime,
} from '#root/enums/treatmentEnum.js';

export const validateCommonData = (data) => {
  const {
    treatmentName,
    frequency,
    timeFrequency,
    times,
    startDate,
    endDate,
    numberOfSessions,
  } = data;

  if (!treatmentName || treatmentName.trim() === '') {
    return { valid: false, error: TreatmentNameRequired };
  }

  if (typeof frequency === 'string') {
    if (!Object.values(treatmemtFrequency).includes(frequency)) {
      return { valid: false, error: InvalidFrequencyValue };
    }
  } else if (Array.isArray(frequency)) {
    if (frequency.some((day) => !treatmemtFrequency.Custom.includes(day))) {
      return { valid: false, error: InvalidDaysInFrequencyArray };
    }
  } else {
    return { valid: false, error: InvalidFrequencyValue };
  }

  if (!Object.keys(treatmentFrequencyTime).includes(timeFrequency)) {
    return { valid: false, error: InvalidFrequencyOfTimeFrequency };
  }

  const expectedCount = treatmentFrequencyTime[timeFrequency];

  if (expectedCount && times.length !== expectedCount) {
    return {
      valid: false,
      error: `The selected timeFrequency requires exactly ${expectedCount} time(s). You provided ${times.length}.`,
    };
  }

  try {
    const formattedTimes = times.map((time) => {
      if (!validateTimeFormat(time)) {
        throw new Error(`Invalid time format: ${time}`);
      }
      const [hours, minutes] = time.split(':');
      return `${hours.padStart(2, '0')}:${minutes.padStart(2, '0')}`;
    });
    data.times = formattedTimes;
    // eslint-disable-next-line
  } catch (error) {
    return { valid: false, error: InvalidTimeFormate };
  }

  if (numberOfSessions < 1) {
    return { valid: false, error: sessionsValidationMessage };
  }

  const formattedStartDate = moment
    .utc(startDate, 'DD/MM/YYYY')
    .startOf('day')
    .toDate();
  const formattedEndDate = moment
    .utc(endDate, 'DD/MM/YYYY')
    .endOf('day')
    .toDate();

  if (formattedStartDate >= formattedEndDate) {
    return { valid: false, error: startDateAndEndDateValidation };
  }

  data.startDate = formattedStartDate;
  data.endDate = formattedEndDate;

  return { valid: true, data };
};
