# Medication Backend

## Version Information

This project requires specific versions of Node.js and npm to ensure compatibility and proper functioning.

- **Node.js Version**: `18.20.4`
- **npm Version**: `10.7.0`

To install the correct versions, you may use tools like [nvm](https://github.com/nvm-sh/nvm) for managing Node.js versions:

```bash
nvm install 18.20.4
nvm use 18.20.4
