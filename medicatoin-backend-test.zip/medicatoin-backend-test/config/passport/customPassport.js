import passport from 'passport';
import { Strategy as GoogleStrategy } from 'passport-google-oauth20';
import { Strategy as FacebookStrategy } from 'passport-facebook';
//import AppleStrategy from 'passport-apple';
import User from '#root/modules/User/user.model.js';

export function initializePassport() {
  passport.serializeUser((user, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id, done) => {
    try {
      const user = await User.findById(id);
      done(null, user);
    } catch (err) {
      done(err, false);
    }
  });

  passport.use(
    new GoogleStrategy(
      {
        clientID: process.env.GOOGLE_CLIENT_ID,
        clientSecret: process.env.GOOGLE_CLIENT_SECRET,
        callbackURL: '/api/v1/auth/google/callback',
      },
       
      async (accessToken, refreshToken, profile, done) => {
        try {
          let user = await User.findOne({
            providerId: profile.id,
            provider: 'google',
          });
          if (!user) {
            user = await User.create({
              fullName: profile.displayName,
              email: profile.emails[0].value,
              provider: 'google',
              providerId: profile.id,
              profilePicture: profile.photos[0].value,
            });
          }
          done(null, user);
        } catch (err) {
       
          done(err, false);
        }
      },
    ),
  );

  
  passport.use(
    new FacebookStrategy(
      {
        clientID: process.env.FACEBOOK_APP_ID,
        clientSecret: process.env.FACEBOOK_APP_SECRET,
        callbackURL: 'http://localhost:5000/api/v1/auth/facebook/callback', 
        profileFields: ['id', 'emails', 'name', 'photos'],
      },
       
      async (accessToken, refreshToken, profile, done) => {
        try {
          let user = await User.findOne({ providerId: profile.id, provider: 'facebook' });
          if (!user) {
            user = await User.create({
              fullName: `${profile.name.givenName} ${profile.name.familyName}`,
              email: profile.emails && profile.emails.length > 0 ? profile.emails[0].value : null,
              provider: 'facebook',
              providerId: profile.id,
              profilePicture: profile.photos && profile.photos.length > 0 ? profile.photos[0].value : null,
            });
          }
          return done(null, user);
        } catch (err) {
          return done(err, false);
        }
      }
    )
  );
  

  // Apple Strategy
  // passport.use(
  //   new AppleStrategy(
  //     {
  //       clientID: process.env.APPLE_CLIENT_ID,
  //       teamID: process.env.APPLE_TEAM_ID,
  //       keyID: process.env.APPLE_KEY_ID,
  //       privateKeyLocation: process.env.APPLE_PRIVATE_KEY_PATH,
  //       callbackURL: '/api/v1/auth/apple/callback',
  //     },
  //     async (accessToken, refreshToken, profile, done) => {
  //       try {
  //         let user = await User.findOne({ providerId: profile.id, provider: 'apple' });
  //         if (!user) {
  //           user = await User.create({
  //             fullName: profile.name || '',
  //             email: profile.email || '',
  //             provider: 'apple',
  //             providerId: profile.id,
  //           });
  //         }
  //         done(null, user);
  //       } catch (err) {
  //         console.error('Apple strategy error', err);
  //         done(err, false);
  //       }
  //     },
  //   ),
  // );
}
