import cron from 'node-cron';
import logger from '#root/logger.js';
import CycleStatusModel from '#root/modules/Cycle/cycle.status.model.js';
import { SleepCycleReminder } from '#root/constants/notificationMessages.js';
import { sendMedicationNotification } from '#root/utils/sendMedicationNotification.js';
import moment from 'moment';

const isSuspended = (itemStatus) => {
  const today = moment.utc();
  return itemStatus?.statuses.some((statusEntry) => {
    return statusEntry.times.some((timeEntry) => {
      const suspendStart = moment.utc(
        timeEntry.pauseStartDate,
        'YYYY-MM-DD HH:mm',
      );
      const suspendEnd = moment.utc(timeEntry.pauseEndDate, 'YYYY-MM-DD HH:mm');
      if (
        timeEntry.status === 'suspend' &&
        today.isBetween(suspendStart, suspendEnd, 'day', '[]')
      ) {
        const isResumed = itemStatus.statuses.some((resumeEntry) => {
          return resumeEntry.times.some((resumeTime) => {
            return (
              resumeTime.status === 'resumed' &&
              moment
                .utc(resumeTime.time, 'YYYY-MM-DD HH:mm')
                .isAfter(suspendEnd)
            );
          });
        });
        return !isResumed;
      }
      return false;
    });
  });
};

const isPaused = (itemStatus) => {
  const today = moment.utc();
  return itemStatus?.statuses.some((statusEntry) => {
    const pauseTimes = statusEntry.times.find((t) => t.status === 'paused');
    if (pauseTimes) {
      const pauseStart = moment.utc(
        pauseTimes.pauseStartDate,
        'YYYY-MM-DD HH:mm',
      );
      const pauseEnd = moment.utc(pauseTimes.pauseEndDate, 'YYYY-MM-DD HH:mm');
      return today.isBetween(pauseStart, pauseEnd, 'day', '[]');
    }
    return false;
  });
};

export const sleepCycleReminderCronJob = () => {
  cron.schedule('0 22 * * *', async () => {
    try {
      const cycles = await CycleStatusModel.find({
        'statuses.times.status': 'active',
      });

      for (const cycle of cycles) {
        const sortedStatuses = cycle.statuses.slice().reverse();
        const lastActiveStatus = sortedStatuses.find(
          (s) => s.times[0].status === 'active',
        );
        const lastCompletedStatus = sortedStatuses.find(
          (s) => s.times[0].status === 'completed',
        );
        const lastPendingStatus = sortedStatuses.find(
          (s) => s.times[0].status === 'pending',
        );

        if (isSuspended(cycle) || isPaused(cycle)) {
          continue;
        }

        const isActiveAndIncomplete =
          lastActiveStatus &&
          (!lastCompletedStatus ||
            lastActiveStatus.date > lastCompletedStatus.date) &&
          (!lastPendingStatus ||
            lastActiveStatus.date > lastPendingStatus.date);

        if (isActiveAndIncomplete) {
          const userId = cycle.userId;
          const message = SleepCycleReminder(cycle.cycleId);

          await sendMedicationNotification(userId, message);
        }
      }
    } catch (error) {
      logger.error(`Cycle reminder cron job error: ${error.message}`);
    }
  });
};
