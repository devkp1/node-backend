import moment from 'moment';
import MedicationModel from '#root/modules/Medication/Medicine/medication.model.js';
import TreatmentModel from '#root/modules/Treatment/treatment.model.js';
import cron from 'node-cron';
import { sendMedicationNotification } from '../utils/sendMedicationNotification.js';
import { MorningMedicationTreatmenttReminderNotification, NoMorningMedicationTreatmenttReminderNotification } from '#root/constants/notificationMessages.js';
import TreatmentStatusModel from '#root/modules/Treatment/treatment.status.model.js';
import MedicationStatusModel from '#root/modules/Medication/Medicine/medication.status.model.js';
import User from '#root/modules/User/user.model.js';



export const setupMorningMedicationReminderCron = () => {
  cron.schedule('0 8 * * *', async () => {
    /* eslint-disable no-useless-catch */
    try {
      const today = moment.utc();
      // eslint-disable-next-line
      const todayDate = today.format('YYYY-MM-DD');

      const medicationsStartingToday = await MedicationModel.find({
        startDate: { $lte: today.toDate() },
        endDate: { $gte: today.toDate() },
      }).populate('userId');

      const treatmentsStartingToday = await TreatmentModel.find({
        startDate: { $lte: today.toDate() },
        endDate: { $gte: today.toDate() },
      }).populate('userId');

      const notificationsToSend = new Map();
      const usersWithNotifications = new Set();

      const isSuspended = (itemStatus) => {
        return itemStatus?.statuses.some((statusEntry) => {
          return statusEntry.times.some((timeEntry) => {
            const suspendStart = moment.utc(timeEntry.pauseStartDate, 'YYYY-MM-DD HH:mm');
            const suspendEnd = moment.utc(timeEntry.pauseEndDate, 'YYYY-MM-DD HH:mm');
            if (timeEntry.status === 'suspend' && today.isBetween(suspendStart, suspendEnd, 'day', '[]')) {
              const isResumed = itemStatus.statuses.some((resumeEntry) => {
                return resumeEntry.times.some((resumeTime) => {
                  return (
                    resumeTime.status === 'resumed' &&
                    moment.utc(resumeTime.time, 'YYYY-MM-DD HH:mm').isAfter(suspendEnd)
                  );
                });
              });
              return !isResumed;
            }
            return false;
          });
        });
      };

      const isPaused = (itemStatus) => {
        return itemStatus?.statuses.some((statusEntry) => {
          const pauseTimes = statusEntry.times.find((t) => t.status === 'paused');
          if (pauseTimes) {
            const pauseStart = moment.utc(pauseTimes.pauseStartDate, 'YYYY-MM-DD HH:mm');
            const pauseEnd = moment.utc(pauseTimes.pauseEndDate, 'YYYY-MM-DD HH:mm');
            return today.isBetween(pauseStart, pauseEnd, 'day', '[]');
          }
          return false;
        });
      };

      for (const medication of medicationsStartingToday) {
        const { times, medicationName, userId, numberOfCapsule, type, _id: medicationId } = medication;

        const medicationStatus = await MedicationStatusModel.findOne({
          userId: userId._id,
          medicationId,
        });

        if (isSuspended(medicationStatus) || isPaused(medicationStatus)) continue;

        const firstTime = times[0];
        const [hour] = firstTime.split(':').map(Number);
        if (hour >= 4 && hour < 12) {
          const capsuleCount = numberOfCapsule.length > 0 ? numberOfCapsule[0] : 0;

          if (!notificationsToSend.has(userId._id.toString())) {
            notificationsToSend.set(userId._id.toString(), { userId, medications: [], treatments: [] });
          }

          notificationsToSend.get(userId._id.toString()).medications.push({
            time: firstTime,
            name: medicationName,
            numberOfCapsule: capsuleCount,
            type,
          });
        }
      }

      for (const treatment of treatmentsStartingToday) {
        const { times, numberOfSessions, treatmentName, userId, _id: treatmentId } = treatment;

        const treatmentStatus = await TreatmentStatusModel.findOne({
          userId: userId._id,
          treatmentId,
        });

        if (isSuspended(treatmentStatus) || isPaused(treatmentStatus)) continue;

        const firstTime = times[0];
        const [hour] = firstTime.split(':').map(Number);
        if (hour >= 4 && hour < 12) {
          if (!notificationsToSend.has(userId._id.toString())) {
            notificationsToSend.set(userId._id.toString(), { userId, medications: [], treatments: [] });
          }

          notificationsToSend.get(userId._id.toString()).treatments.push({
            time: firstTime,
            name: treatmentName,
            sessions: numberOfSessions,
          });
        }
      }

      for (const [userId, { medications, treatments }] of notificationsToSend) {
        const medicationMessages = medications.map(
          ({ time, name, numberOfCapsule, type }) => `🕗 ${time} - ${name} - ${numberOfCapsule} ${type}`
        );

        const treatmentMessages = treatments.length > 0
          ? 'Treatments:\n' +
            treatments
              .map(({ time, name, sessions }) => `🕗 ${time} - ${name} - ${sessions} session.`)
              .join('\n')
          : '';

        const notificationMessage =
          '☀️💊 Rise and shine! Don’t forget to take your morning meds:' +
          (medications.length > 0 ? `\n${medicationMessages.join('\n')}` : '') +
          (treatmentMessages.length > 0 ? `\n${treatmentMessages}` : '') +
          '\nYou’ve got this!';

        const remainingSessions = treatments.reduce((total, treatment) => total + treatment.sessions, 0);
        const notificationObject = MorningMedicationTreatmenttReminderNotification(notificationMessage, remainingSessions);

        await sendMedicationNotification(userId, notificationObject);
        usersWithNotifications.add(userId);
      }

     
      const allUsers = await User.find({});
      for (const user of allUsers) {
        if (!usersWithNotifications.has(user._id.toString())) {
          // eslint-disable-next-line
          const remainingSessions = 0;
          const noSpecificNotification = NoMorningMedicationTreatmenttReminderNotification(user._id);

          await sendMedicationNotification(user._id, noSpecificNotification);
        }
      }

    } catch (error) {
      throw error;
    }
  });
};


