import cron from 'node-cron';
import moment from 'moment';
import { sendMedicationNotification } from '../utils/sendMedicationNotification.js';
import MedicationModel from '#root/modules/Medication/Medicine/medication.model.js';
import { MedicationEndReminderNotification } from '#root/constants/notificationMessages.js';
import TreatmentModel from '#root/modules/Treatment/treatment.model.js';
import MedicationStatusModel from '#root/modules/Medication/Medicine/medication.status.model.js';
import TreatmentStatusModel from '#root/modules/Treatment/treatment.status.model.js';

export const setupMedicationAndTreatmentEndReminderCron = () => {
  cron.schedule('0 9 * * *', async () => {
    /* eslint-disable no-useless-catch */
    try {
      const today = moment.utc();
      const currentDateString = today.format('YYYY-MM-DD');

      const medicationsEndingToday = await MedicationModel.find({}).populate(
        'userId',
      );
      const treatmentsEndingToday = await TreatmentModel.find({}).populate(
        'userId',
      );

      const notificationsToSend = new Map();

      const isSuspended = (itemStatus) => {
        return itemStatus?.statuses.some((statusEntry) => {
          return statusEntry.times.some((timeEntry) => {
            const suspendStart = moment.utc(
              timeEntry.pauseStartDate,
              'YYYY-MM-DD HH:mm',
            );
            const suspendEnd = moment.utc(
              timeEntry.pauseEndDate,
              'YYYY-MM-DD HH:mm',
            );
            return (
              timeEntry.status === 'suspend' &&
              today.isBetween(suspendStart, suspendEnd, 'day', '[]')
            );
          });
        });
      };

      const isPaused = (itemStatus) => {
        return itemStatus?.statuses.some((statusEntry) => {
          const pauseTimes = statusEntry.times.find(
            (t) => t.status === 'paused',
          );
          if (pauseTimes) {
            const pauseStart = moment.utc(
              pauseTimes.pauseStartDate,
              'YYYY-MM-DD HH:mm',
            );
            const pauseEnd = moment.utc(
              pauseTimes.pauseEndDate,
              'YYYY-MM-DD HH:mm',
            );
            return today.isBetween(pauseStart, pauseEnd, 'day', '[]');
          }
          return false;
        });
      };

      for (const medication of medicationsEndingToday) {
        const { times, medicationName, userId, endDate } = medication;
        const medicationEndDateString = endDate.toISOString().split('T')[0];

        if (medicationEndDateString === currentDateString) {
          const medicationStatus = await MedicationStatusModel.findOne({
            userId: userId._id,
            medicationId: medication._id,
          });

          if (isSuspended(medicationStatus) || isPaused(medicationStatus))
            continue;

          if (!notificationsToSend.has(userId._id.toString())) {
            notificationsToSend.set(userId._id.toString(), {
              userId,
              medications: [],
              treatments: [],
            });
          }
          notificationsToSend.get(userId._id.toString()).medications.push({
            name: medicationName,
            remainingDoses: times.length,
          });
        }
      }

      for (const treatment of treatmentsEndingToday) {
        const { numberOfSessions, treatmentName, userId, endDate } = treatment;
        const treatmentEndDateString = endDate.toISOString().split('T')[0];

        if (treatmentEndDateString === currentDateString) {
          const treatmentStatus = await TreatmentStatusModel.findOne({
            userId: userId._id,
            treatmentId: treatment._id,
          });

          if (isSuspended(treatmentStatus) || isPaused(treatmentStatus))
            continue;

          if (!notificationsToSend.has(userId._id.toString())) {
            notificationsToSend.set(userId._id.toString(), {
              userId,
              medications: [],
              treatments: [],
            });
          }
          notificationsToSend
            .get(userId._id.toString())
            .treatments.push({ name: treatmentName, numberOfSessions });
        }
      }

      for (const [userId, { medications, treatments }] of notificationsToSend) {
        const medicationMessages = medications.map(
          ({ name, remainingDoses }) =>
            `You’ve only got ${remainingDoses} doses left of ${name}.`,
        );
        const treatmentMessages = treatments.map(
          ({ name, numberOfSessions }) =>
            `You’ve only got ${numberOfSessions} sessions left of ${name}.`,
        );

        const allMessages = [...medicationMessages, ...treatmentMessages];
        const notificationMessage = `⏳⚠️ Heads up!\n${allMessages.join('\n')}\nTime to relax!`;

        const totalRemaining = medications.length + treatments.length;
        const notification =
          totalRemaining > 0
            ? MedicationEndReminderNotification(
              notificationMessage,
              totalRemaining,
            )
            : null;

        if (notification) {
          await sendMedicationNotification(userId, notification);
        }
      }
    } catch (error) {
      throw error;
    }
  });
};
