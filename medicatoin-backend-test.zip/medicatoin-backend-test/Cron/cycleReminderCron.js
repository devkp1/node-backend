import cron from 'node-cron';
import moment from 'moment';
import {
  BeforePeriodStartReminder,
  UpcomingCycleReminder,
} from '#root/constants/notificationMessages.js';
import { sendMedicationNotification } from '#root/utils/sendMedicationNotification.js';
import CycleModel from '#root/modules/Cycle/cycle.model.js';
import CycleStatusModel from '#root/modules/Cycle/cycle.status.model.js';
import logger from '#root/logger.js';


export const setupCycleReminderCron = () => {
  cron.schedule('45 8 * * *', async () => {
    try {
      const today = moment.utc();

      const cycles = await CycleModel.find().populate('userId');

      for (const cycle of cycles) {
        const {
          menstruationStartDate,
          scheduleDayBefore,
          userId,
          cycleLength = 30,
          _id: cycleId,
        } = cycle;
        const daysBefore = parseInt(scheduleDayBefore) || 1;
        const effectiveCycleLength = cycleLength || 30;

        const cycleStatusRecord = await CycleStatusModel.findOne({
          userId: userId._id,
          cycleId,
        });
        const lastActiveStatus = cycleStatusRecord?.statuses
          .slice(-1)
          .find((status) => status.times[0].status === 'active');

        let reminderDate;
        let periodStartDate;

        if (lastActiveStatus) {
          const lastActiveDate = moment(lastActiveStatus.date);
          const nextCycleStartDate = lastActiveDate
            .clone()
            .add(effectiveCycleLength, 'days');
          reminderDate = nextCycleStartDate
            .clone()
            .subtract(daysBefore, 'days');
          periodStartDate = nextCycleStartDate;
        } else {
          reminderDate = moment(menstruationStartDate)
            .add(effectiveCycleLength, 'days')
            .subtract(daysBefore, 'days');
          periodStartDate = moment(menstruationStartDate).add(
            effectiveCycleLength,
            'days',
          );
        }

        if (today.isSame(reminderDate, 'day')) {
          const notificationMessage = UpcomingCycleReminder(cycleId);

          await sendMedicationNotification(userId, notificationMessage);
        }

        if (today.isSame(periodStartDate, 'day')) {
          const periodStartMessage = BeforePeriodStartReminder(cycleId);

          await sendMedicationNotification(userId, periodStartMessage);
        }
      }
    } catch (error) {
      logger.error(`setup cycle reminder cron error: ${error.message}`);
    }
  });
};
