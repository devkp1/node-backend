import cron from 'node-cron';
import logger from '#root/logger.js';
import moment from 'moment';
import CycleStatusModel from '#root/modules/Cycle/cycle.status.model.js';
import {
  fifthCycleReminder,
  firstCycleReminder,
  fourthCycleReminder,
  secondCycleReminder,
  thirdCycleReminder,
} from '#root/constants/notificationMessages.js';
import { sendMedicationNotification } from '#root/utils/sendMedicationNotification.js';

const isSuspended = (itemStatus) => {
  const today = moment.utc();
  return itemStatus?.statuses?.some((statusEntry) => {
    return statusEntry.times?.some((timeEntry) => {
      const suspendStart = moment.utc(
        timeEntry.pauseStartDate,
        'YYYY-MM-DD HH:mm',
      );
      const suspendEnd = moment.utc(timeEntry.pauseEndDate, 'YYYY-MM-DD HH:mm');
      if (
        timeEntry.status === 'suspend' &&
        today.isBetween(suspendStart, suspendEnd, 'day', '[]')
      ) {
        const isResumed = itemStatus.statuses?.some((resumeEntry) => {
          return resumeEntry.times?.some((resumeTime) => {
            return (
              resumeTime.status === 'resumed' &&
              moment
                .utc(resumeTime.time, 'YYYY-MM-DD HH:mm')
                .isAfter(suspendEnd)
            );
          });
        });
        return !isResumed;
      }
      return false;
    });
  });
};


const isPaused = (itemStatus) => {
  const today = moment.utc();
  return itemStatus?.statuses?.some((statusEntry) => {
    const pauseTimes = statusEntry.times?.find((t) => t.status === 'paused');
    if (pauseTimes) {
      const pauseStart = moment.utc(
        pauseTimes.pauseStartDate,
        'YYYY-MM-DD HH:mm',
      );
      const pauseEnd = moment.utc(pauseTimes.pauseEndDate, 'YYYY-MM-DD HH:mm');
      return today.isBetween(pauseStart, pauseEnd, 'day', '[]');
    }
    return false;
  });
};

export const MotivationalCycleReminderCronJob = () => {
  cron.schedule('0 10 * * *', async () => {
    try {
      const cycles = await CycleStatusModel.find({
        'statuses.times.status': 'active',
      });

      for (const cycle of cycles) {
        const sortedStatuses = cycle.statuses.slice().reverse();
        const lastActiveStatus = sortedStatuses.find(
          (s) => s.times?.[0]?.status === 'active',
        );

        if (!lastActiveStatus || isSuspended(cycle) || isPaused(cycle))
          continue;

        const activationDate = moment.utc(lastActiveStatus.date);
        const daysSinceActivation = moment.utc().diff(activationDate, 'days');

        let message;
        switch (daysSinceActivation % 5) {
        case 0:
          message = firstCycleReminder(cycle.cycleId);
          break;
        case 1:
          message = secondCycleReminder(cycle.cycleId);
          break;
        case 2:
          message = thirdCycleReminder(cycle.cycleId);
          break;
        case 3:
          message = fourthCycleReminder(cycle.cycleId);
          break;
        case 4:
          message = fifthCycleReminder(cycle.cycleId);
          break;
        default:
          continue;
        }

        const userId = cycle.userId;

        if (message) {
          await sendMedicationNotification(userId, message);

          cycle.lastReminderIndex = daysSinceActivation % 5;
          await cycle.save();
        }
      }
    } catch (error) {
      logger.error(`Cycle reminder cron job error: ${error}`);
    }
  });
};
