import cron from 'node-cron';
import moment from 'moment';
import CycleStatusModel from '#root/modules/Cycle/cycle.status.model.js';
import CycleModel from '#root/modules/Cycle/cycle.model.js';
import { statusCodes } from '#root/constants/statusCodeMessages.js';
import { errorResponse } from '../utils/responseHandler.js';
import logger from '#root/logger.js';
import { ServerErrorMessage } from '#root/constants/errorMessages.js';

export const createCron = () => {
  cron.schedule('0 0 * * *', async () => {
    try {
      const currentDate = moment();

      const cycles = await CycleModel.find({ autoCompleted: true });

      for (const cycle of cycles) {
        const userId = cycle.userId;
        const completedDays = cycle.completedDays || 7;

        const cycleStatusRecord = await CycleStatusModel.findOne({
          userId,
          cycleId: cycle._id,
        });

        if (
          !cycleStatusRecord ||
          !Array.isArray(cycleStatusRecord.statuses) ||
          cycleStatusRecord.statuses.length === 0
        ) {
          continue;
        }

        const completedDaysAgo = currentDate
          .clone()
          .subtract(completedDays, 'days');

        const activeStatuses = cycleStatusRecord.statuses.filter((status) => {
          const hasActiveEntries = status.times.some(
            (timeEntry) => timeEntry.status === 'active',
          );
          const isOlderThanCompletedDays = moment(status.date).isBefore(
            completedDaysAgo,
          );
          return hasActiveEntries && isOlderThanCompletedDays;
        });

        if (activeStatuses.length > 0) {
          const lastActiveStatus = activeStatuses[activeStatuses.length - 1];
          const statusDateTime = moment(lastActiveStatus.date);

          const existingCompletedEntry = cycleStatusRecord.statuses.some(
            (status) =>
              status.times.some(
                (timeEntry) => timeEntry.status === 'completed',
              ) && moment(status.date).isAfter(statusDateTime),
          );

          if (existingCompletedEntry) {
            continue;
          }

          const completedEntry = {
            date: currentDate.toDate(),
            times: [
              {
                time: currentDate.format('HH:mm'),
                status: 'completed',
                cycleDuration: currentDate.diff(statusDateTime, 'days'),
              },
            ],
          };

          lastActiveStatus.times[0].cycleDuration =
            completedEntry.times[0].cycleDuration;

          cycleStatusRecord.statuses.push(completedEntry);
          await cycleStatusRecord.save();
        } else {
          logger.log(
            `No active statuses older than one minute found for user ${userId}.`,
          );
        }
      }
    } catch (error) {
      // logger.error(`cron auto-completed error: ${error.message}`);
      return errorResponse(error, ServerErrorMessage, statusCodes.SERVER_ERROR);
    }
  });
};
