import axios from 'axios';
import https from 'https';
import logger from './logger';

const getPostalCode = async () => {
  try {
    const response = await axios.get(
      'https://api.zippopotam.us/in/gj/ahmedabad',
      {
        httpsAgent: new https.Agent({
          rejectUnauthorized: false,
          keepAlive: true,
          minVersion: 'TLSv1.2',
        }),
      },
    );

    const postalCodeDetails = response.data.places.map(
      (detail) => detail['post code'],
    );

    return postalCodeDetails;
  } catch (error) {
    logger.error(`Postal Code error: ${error.message}`);
    return null;
  }
};
getPostalCode();
