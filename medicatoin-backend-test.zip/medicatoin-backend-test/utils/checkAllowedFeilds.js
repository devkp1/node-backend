import { statusCodes } from '#constants/statusCodeMessages.js';
import { AdditionalFeildsErrorMessage } from '#constants/errorMessages.js';
import { errorResponse } from './responseHandler.js';
import {
  medicationFoodTime,
  medicationFrequency,
  medicationStatuses,
  medicationTimeFrequency,
  medicationType,
} from '#root/enums/medicationEnum.js';

const validateAllowedFields = (allowedFields, obj, res) => {
  const invalidFields = Object.keys(obj).filter(
    (key) => !allowedFields.includes(key),
  );
  if (invalidFields.length > 0) {
    errorResponse(
      res,
      new Error(AdditionalFeildsErrorMessage),
      `These fields are not allowed: ${invalidFields.join(', ')}`,
      statusCodes.VALIDATION_ERROR,
    );
    return false;
  }

  return true;
};

export const allowedTypes = Object.keys(medicationType);
export const allowedFrequencies = Object.keys(medicationFrequency);
export const allowedFoodTimes = Object.keys(medicationFoodTime);
export const allowedTimeFrequencies = Object.values(
  medicationTimeFrequency,
).map(String);
export const allowedStatuses = Object.keys(medicationStatuses).map(String);

export const validateFilter = (filter, allowedValues, filterName, res) => {
  if (!filter) return true;


  const lowerCaseAllowedValues = allowedValues
    .filter((val) => typeof val === 'string') 
    .map((val) => val.toLowerCase());

  const filterValues = Array.isArray(filter) ? filter : filter.split(',');

  for (const value of filterValues) {
    
    const lowerCaseValue = value.trim().toLowerCase();

    if (!lowerCaseAllowedValues.includes(lowerCaseValue)) {
      errorResponse(
        res,
        new Error(`${filterName} contains an invalid value: ${value}`),
        `Invalid${filterName}Value`,
        statusCodes.VALIDATION_ERROR,
      );
      return false;
    }
  }

  return true;
};

export default validateAllowedFields;
