import { UserNotFoundMessage } from '#constants/errorMessages.js';
import { statusCodes } from '#constants/statusCodeMessages.js';
import logger from '../logger.js';
import userModel from '../modules/User/user.model.js';
import { errorResponse } from './responseHandler.js';

export const checkUserExists = async (userId, res) => {
  try {
    const user = await userModel.findById(userId);
    if (!user) {
      errorResponse(
        res,
        new Error(UserNotFoundMessage),
        UserNotFoundMessage,
        statusCodes.NOT_FOUND,
      );
      return null;
    }
    return user;
  } catch (error) {
    logger.error(`User error: ${error.message}`);
    errorResponse(res, error, UserNotFoundMessage, statusCodes.SERVER_ERROR);
    return null;
  }
};
