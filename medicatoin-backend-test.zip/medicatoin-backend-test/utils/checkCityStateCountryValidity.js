import {
  CityIsNotValidAsPerStateAndCountryMessage,
  CityStateCountryDoNotMatchMessage,
  InvalidCityIDMessage,
  InvalidCityMessage,
  InvalidCountryIDMessage,
  InvalidCountryMessage,
  InvalidStateIDMessage,
  InvalidStateMessage,
  UpdateStateAndCityMessage,
  UpdateCountryAndCityMessage,
  UpdateCountryAndStateMessage,
} from '#constants/errorMessages.js';
import { statusCodes } from '#constants/statusCodeMessages.js';
import City from '#modules/Location/Models/cityModel.js';
import Country from '#modules/Location/Models/countryModel.js';
import State from '#modules/Location/Models/stateModel.js';
import { errorResponse } from './responseHandler.js';

export const checkCityStateCountryValidity = async (
  city,
  state,
  country,
  res,
) => {
  let cityDetails, stateDetails, countryDetails;

  if (country && !state && !city) {
    return errorResponse(
      res,
      new Error(UpdateStateAndCityMessage),
      UpdateStateAndCityMessage,
      statusCodes.VALIDATION_ERROR,
    );
  }

  if (state && !country && !city) {
    return errorResponse(
      res,
      new Error(UpdateCountryAndCityMessage),
      UpdateCountryAndCityMessage,
      statusCodes.VALIDATION_ERROR,
    );
  }

  if (city && !state && !country) {
    return errorResponse(
      res,
      new Error(UpdateCountryAndStateMessage),
      UpdateCountryAndStateMessage,
      statusCodes.VALIDATION_ERROR,
    );
  }

  if (country) {
    countryDetails = await Country.findById(country);
    if (!countryDetails) {
      return errorResponse(
        res,
        new Error(InvalidCountryMessage),
        InvalidCountryIDMessage,
        statusCodes.VALIDATION_ERROR,
      );
    }
  }

  if (state) {
    stateDetails = await State.findById(state);
    if (!stateDetails) {
      return errorResponse(
        res,
        new Error(InvalidStateMessage),
        InvalidStateIDMessage,
        statusCodes.VALIDATION_ERROR,
      );
    }

    if (country && stateDetails.countryCode !== countryDetails.isoCode) {
      return errorResponse(
        res,
        new Error(CityStateCountryDoNotMatchMessage),
        CityIsNotValidAsPerStateAndCountryMessage,
        statusCodes.VALIDATION_ERROR,
      );
    }
  }

  if (city) {
    cityDetails = await City.findById(city);
    if (!cityDetails) {
      return errorResponse(
        res,
        new Error(InvalidCityMessage),
        InvalidCityIDMessage,
        statusCodes.VALIDATION_ERROR,
      );
    }

    if (state && cityDetails.stateCode !== stateDetails.isoCode) {
      return errorResponse(
        res,
        new Error(CityStateCountryDoNotMatchMessage),
        CityIsNotValidAsPerStateAndCountryMessage,
        statusCodes.VALIDATION_ERROR,
      );
    }
    if (country && cityDetails.countryCode !== countryDetails.isoCode) {
      return errorResponse(
        res,
        new Error(CityStateCountryDoNotMatchMessage),
        CityIsNotValidAsPerStateAndCountryMessage,
        statusCodes.VALIDATION_ERROR,
      );
    }
  }

  return { cityDetails, stateDetails, countryDetails };
};
