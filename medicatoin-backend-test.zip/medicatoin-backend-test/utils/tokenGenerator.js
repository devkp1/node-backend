import jwt from 'jsonwebtoken';

export const generateAccessToken = (user) => {
  return jwt.sign(
    { userId: user?._id , email: user.email },
    process.env.SECRET_TOKEN,
    { expiresIn: '12h' },
  );
};

export const generateGuestAccessToken = (user) => {
  return jwt.sign(
    {
      userId: user?._id,
      email: user?.email,
      isGuestUser: true,
    },
    process.env.SECRET_TOKEN,
    { expiresIn: '12h' },
  );
};
