import moment from 'moment';
import MedicationStatusModel from '#root/modules/Medication/Medicine/medication.status.model.js';
import TreatmentStatusModel from '#root/modules/Treatment/treatment.status.model.js';
import { ValidDateFormat } from '#root/constants/errorMessages.js';
import logger from '#root/logger.js';
import CycleStatusModel from '#root/modules/Cycle/cycle.status.model.js';

export const calculateAdherenceForPauseSuspend = async (
  item,
  type,
  userId,
  startDate,
  endDate,
  statusOption = '6',
) => {
  try {
    if (!['medication', 'treatment', 'cycle'].includes(type)) {
      throw new Error(`Invalid type: ${type}`);
    }

    const specifiedStartDate = moment(startDate, 'DD/MM/YYYY', true);
    const specifiedEndDate = moment(endDate, 'DD/MM/YYYY', true);

    if (!specifiedStartDate.isValid() || !specifiedEndDate.isValid()) {
      throw new Error(ValidDateFormat);
    }

    const statusModel =
      type === 'medication'
        ? MedicationStatusModel
        : type === 'treatment'
          ? TreatmentStatusModel
          : CycleStatusModel;

    const statuses = await statusModel
      .find({
        [`${type}Id`]: item._id,
        userId: userId,
      })
      .exec();

    if (!statuses || statuses.length === 0) {
      return {
        adherencePercentage: '0.00',
        timeWiseStatuses: [],
      };
    }

    const timeWiseStatuses = [];

    const statusMapping = {
      1: 'paused',
      5: 'suspend',
      6: ['paused', 'suspend'],
    };

    statuses.forEach((status) => {
      status.statuses.forEach((dateStatus) => {
        dateStatus.times.forEach((record) => {
          const pauseStartDate = moment(record.pauseStartDate);
          const pauseEndDate = moment(record.pauseEndDate);

          if (pauseStartDate.isValid() && pauseEndDate.isValid()) {
            const itemStartDate = moment(item.startDate, 'YYYY-MM-DD');
            const itemEndDate = moment(item.endDate, 'YYYY-MM-DD');

            const isCycleType = type === 'cycle';
            const isValidPausePeriod = isCycleType
              ? pauseStartDate.isSameOrBefore(specifiedEndDate) &&
                pauseEndDate.isSameOrAfter(specifiedStartDate)
              : itemStartDate.isSameOrBefore(specifiedEndDate) &&
                itemEndDate.isSameOrAfter(specifiedStartDate);

            if (isValidPausePeriod) {
              dateStatus.times.forEach((timeStatus) => {
                if (
                  !['resumed', 'completed', 'taken', 'skipped'].includes(
                    timeStatus.status,
                  )
                ) {
                  const isMatchingStatusOption =
                    (statusOption === '6' &&
                      statusMapping[6].includes(timeStatus.status)) ||
                    timeStatus.status === statusMapping[statusOption];

                  if (isMatchingStatusOption) {
                    timeWiseStatuses.push({
                      pauseStartDate: pauseStartDate.format('DD/MM/YYYY'),
                      pauseEndDate: pauseEndDate.format('DD/MM/YYYY'),
                      pauseReason: record.pauseReason,
                      status: timeStatus.status,
                    });
                  }
                }
              });
            }
          }
        });
      });
    });

    return {
      timeWiseStatuses,
    };
  } catch (error) {
    logger.error('Error calculating adherence:', error.message);
    throw error; // Re-throwing to handle upstream
  }
};


const formatPausedEntries = (filteredStatuses) => {
 
  const pausedEntries = filteredStatuses.flatMap(entry => 
    entry.times
      .filter(timeEntry => timeEntry.status === 'paused')
      .map(timeEntry => ({
        time: timeEntry.time,
        status: timeEntry.status,
        pauseStartDate: timeEntry.pauseStartDate ? moment(timeEntry.pauseStartDate).format('DD/MM/YYYY') : null,
        pauseEndDate: timeEntry.pauseEndDate ? moment(timeEntry.pauseEndDate).format('DD/MM/YYYY') : null,
        pauseReason: timeEntry.pauseReason,
        id: timeEntry._id,
        date: moment(entry.date).format('DD/MM/YYYY')
      }))
  );

  return pausedEntries; 
};

export const calculateActiveStatus = async (item, type, userId, startDate, endDate) => {
  const now = moment();
  const start = moment(item.startDate, 'DD/MM/YYYY');
  const end = moment(item.endDate, 'DD/MM/YYYY');
  const userStart = moment(startDate, 'DD/MM/YYYY');
  const userEnd = moment(endDate, 'DD/MM/YYYY');

  const statusModel = type === 'medication' ? MedicationStatusModel : TreatmentStatusModel;

  try {
    const statusData = await statusModel.findOne({
      [`${type}Id`]: item._id,
      userId: userId,
      'statuses.date': {
        $gte: userStart.startOf('day').toDate(),
        $lte: userEnd.endOf('day').toDate(),
      },
    });

    if (!statusData) {
      return { status: now.isAfter(end) ? 'expired' : 'active', pauseEntries: [] };
    }

    const filteredStatuses = statusData.statuses.filter(status => 
      moment(status.date).isBetween(start, end, null, '[]')
    );

    if (filteredStatuses.length === 0) {
      return { status: now.isAfter(end) ? 'expired' : 'active', pauseEntries: [] };
    }

    const pausedEntries = formatPausedEntries(filteredStatuses); 

    const effectiveStart = moment.max(userStart, start);
    const effectiveEnd = moment.min(userEnd, end);
    const daysBetween = [];

    for (let m = effectiveStart.clone(); m.isSameOrBefore(effectiveEnd); m.add(1, 'days')) {
      daysBetween.push(m.format('DD/MM/YYYY'));
    }

    const hasSuspended = filteredStatuses.some(status => 
      status.times.some(timeEntry => timeEntry.status === 'suspend')
    );

    if (pausedEntries.length > 0) {
      return { status: 'paused', pauseEntries: pausedEntries }; 
    }

    if (hasSuspended) {
      return { status: 'suspended', pauseEntries: [] }; 
    }

    const allStatusesFilled = daysBetween.every(day => {
      const dayStatuses = filteredStatuses.filter(status => moment(status.date).format('DD/MM/YYYY') === day);
      
      if (dayStatuses.length === 0) {
        return false;
      }

      const statusesFilled = dayStatuses.every(statusEntry => 
        statusEntry.times.every(timeEntry => 
          ['completed', 'taken', 'skipped', 'resumed'].includes(timeEntry.status)
        )
      );

      return statusesFilled;
    });

    if (allStatusesFilled) {
      return { status: 'completed', pauseEntries: [] };
    }

    if (now.isAfter(end)) {
      return { status: 'expired', pauseEntries: [] };
    }

    return { status: 'active', pauseEntries: [] };

  } catch (error) {
    logger.error(`Error calculating active status for ${type}: ${error.message}`, {
      itemId: item._id,
      userId: userId,
    });
    return { status: 'active', pauseEntries: [] }; 
  }
};


export const calculateAdherenceMedication = async (
  medication,
  userId,
  startDate,
  endDate,
) => {
  const specifiedStartDate = moment.utc(startDate, 'DD/MM/YYYY', true);
  const specifiedEndDate = moment.utc(endDate, 'DD/MM/YYYY', true);

  if (!specifiedStartDate.isValid() || !specifiedEndDate.isValid()) {
    throw new Error(ValidDateFormat);
  }

  const startOfDay = specifiedStartDate.startOf('day');
  const endOfDay = specifiedEndDate.endOf('day');
  const totalDays = endOfDay.diff(startOfDay, 'days') + 1;

  const totalCountCapsule = medication.numberOfCapsule;
  const sumCapsulesPerDay = totalCountCapsule.reduce(
    (partialSum, a) => partialSum + a,
    0,
  );

  const statuses = await MedicationStatusModel.find({
    medicationId: medication._id,
    userId: userId,
    'statuses.date': { $gte: startOfDay.toDate(), $lte: endOfDay.toDate() },
  });

  const statusMap = new Map();
  let completedMedicationCount = 0;

  statuses.forEach((status) => {
    status.statuses.forEach((dateStatus) => {
      const statusDate = moment.utc(dateStatus.date).startOf('day');

      if (statusDate.isBetween(startOfDay, endOfDay, null, '[]')) {
        dateStatus.times.forEach((timeStatus, index) => {
          const key = `${statusDate.format('DD/MM/YYYY')}|${timeStatus.time}`;
          statusMap.set(key, timeStatus.status);

          if (
            timeStatus.status === 'taken' ||
            timeStatus.status === 'completed'
          ) {
            completedMedicationCount += medication.numberOfCapsule[index] || 0;
          }
        });
      }
    });
  });

  const timeWiseStatuses = [];
  let takenStatusCount = 0;
  let totalTimeSlots = 0;

  for (let day = 0; day < totalDays; day++) {
    const currentDate = startOfDay.clone().add(day, 'days');
    const formattedDate = currentDate.format('DD/MM/YYYY');

    (medication.times || []).forEach((time, index) => {
      const key = `${formattedDate}|${time}`;
      const status = statusMap.get(key) || '';
      if (status === 'taken' || status === 'completed') {
        takenStatusCount += medication.numberOfCapsule[index] || 0;
      }
      totalTimeSlots++;
      timeWiseStatuses.push({
        time,
        date: formattedDate,
        status,
        numberOfCapsule: medication.numberOfCapsule
          ? medication.numberOfCapsule[index]
          : undefined,
      });
    });
  }

  const adherencePercentage =
    totalTimeSlots > 0 ? (takenStatusCount / totalTimeSlots) * 100 : 0;

  return {
    adherencePercentage: adherencePercentage.toFixed(2),
    timeWiseStatuses,
    totalMedicationCount: sumCapsulesPerDay * totalDays,
    completedMedicationCount,
  };
};

export const calculateAdherenceTreatment = async (
  treatment,
  userId,
  startDate,
  endDate,
) => {
  const specifiedStartDate = moment.utc(startDate, 'DD/MM/YYYY', true);
  const specifiedEndDate = moment.utc(endDate, 'DD/MM/YYYY', true);

  if (!specifiedStartDate.isValid() || !specifiedEndDate.isValid()) {
    throw new Error(ValidDateFormat);
  }

  const startOfDay = specifiedStartDate.startOf('day');
  const endOfDay = specifiedEndDate.endOf('day');
  const totalDays = endOfDay.diff(startOfDay, 'days') + 1;

  const statuses = await TreatmentStatusModel.find({
    treatmentId: treatment._id,
    userId: userId,
    'statuses.date': { $gte: startOfDay.toDate(), $lte: endOfDay.toDate() },
  });

  const totalTimesPerDay = (treatment.times || []).length;
  const totalNumberOfSessions = treatment.numberOfSessions || 0;
  const totalTreatmentCount =
    totalTimesPerDay * totalDays * totalNumberOfSessions;

  if (!statuses || statuses.length === 0) {
    const timeWiseStatuses = [];
    for (let day = 0; day < totalDays; day++) {
      const currentDate = startOfDay.clone().add(day, 'days');
      const formattedDate = currentDate.format('DD/MM/YYYY');

      (treatment.times || []).forEach((time) => {
        timeWiseStatuses.push({
          time,
          date: formattedDate,
          status: '',
          session: treatment.numberOfSessions,
        });
      });
    }

    return {
      adherencePercentage: '0.00',
      timeWiseStatuses,
      totalTreatmentCount,
      completedTreatmentCount: 0,
    };
  }

  const statusMap = new Map();
  let completedTreatmentCount = 0;

  statuses.forEach((status) => {
    status.statuses.forEach((dateStatus) => {
      const statusDate = moment.utc(dateStatus.date).startOf('day');

      if (statusDate.isBetween(startOfDay, endOfDay, null, '[]')) {
        const isDayCompleted = dateStatus.times.some(
          (timeStatus) => timeStatus.status === 'completed',
        );

        dateStatus.times.forEach((timeStatus) => {
          const key = `${statusDate.format('DD/MM/YYYY')}|${timeStatus.time}`;
          const statusToSet = isDayCompleted ? 'completed' : timeStatus.status;
          statusMap.set(key, statusToSet);

          if (statusToSet === 'taken' || statusToSet === 'completed') {
            completedTreatmentCount += totalNumberOfSessions;
          }
        });
      }
    });
  });

  const timeWiseStatuses = [];
  let takenStatusCount = 0;
  let totalTimeSlots = 0;

  for (let day = 0; day < totalDays; day++) {
    const currentDate = startOfDay.clone().add(day, 'days');
    const formattedDate = currentDate.format('DD/MM/YYYY');

    (treatment.times || []).forEach((time) => {
      totalTimeSlots++;
      const key = `${formattedDate}|${time}`;
      const status = statusMap.get(key) || '';

      timeWiseStatuses.push({
        time,
        date: formattedDate,
        status,
      });

      if (status === 'taken' || status === 'completed') {
        takenStatusCount++;
      }
    });
  }

  const adherencePercentage =
    totalTimeSlots > 0 ? (takenStatusCount / totalTimeSlots) * 100 : 0;

  return {
    adherencePercentage: adherencePercentage.toFixed(2),
    timeWiseStatuses,
    totalTreatmentCount,
    completedTreatmentCount,
  };
};

export const calculateAdherenceCycle = async (cycleId, userId) => {
  const cycleStatusRecord = await CycleStatusModel.findOne({
    cycleId,
    userId,
  });

  const timeWiseStatuses = [];

  if (cycleStatusRecord?.statuses?.length) {
    cycleStatusRecord.statuses.forEach((statusEntry) => {
      if (statusEntry.times && statusEntry.times.length > 0) {
        statusEntry.times.forEach((timeEntry) => {
          if (timeEntry.status === 'active' && timeEntry.cycleDuration > 0) {
            const activeStatus = {
              activeStartDate: moment
                .utc(statusEntry.date)
                .format('DD/MM/YYYY'),
              activeTime: timeEntry.time,
              cycleDuration: timeEntry.cycleDuration,
              completedDate: null,
            };
            timeWiseStatuses.push(activeStatus);
          } else if (timeEntry.status === 'completed') {
            timeWiseStatuses.forEach((entry) => {
              if (!entry.completedDate) {
                entry.completedDate = moment
                  .utc(statusEntry.date)
                  .format('DD/MM/YYYY');
              }
            });
          }
        });
      }
    });
  } else {
    timeWiseStatuses.push({
      activeStartDate: null,
      activeTime: null,
      cycleDuration: null,
      completedDate: null,
    });
  }

  const filteredStatuses = timeWiseStatuses.filter(
    (status) => status.cycleDuration !== 0,
  );

  return {
    timeWiseStatuses: filteredStatuses,
  };
};

export const calculateAdherence = async (
  item,
  type,
  userId,
  startDate,
  endDate,
) => {
  if (!['medication', 'treatment', 'cycle'].includes(type)) {
    throw new Error(`Invalid type: ${type}`);
  }

  const userStartDate = startDate
    ? moment(startDate, 'DD/MM/YYYY', true)
    : moment().startOf('month');

  const userEndDate = endDate
    ? moment(endDate, 'DD/MM/YYYY', true)
    : moment().endOf('month');

  if (!userStartDate.isValid() || !userEndDate.isValid()) {
    throw new Error('Invalid date format.');
  }

  const startOfDay = userStartDate.startOf('day');
  const endOfDay = userEndDate.endOf('day');
  const totalDays = endOfDay.diff(startOfDay, 'days') + 1;

  const statusModel = {
    medication: MedicationStatusModel,
    treatment: TreatmentStatusModel,
    cycle: CycleStatusModel,
  }[type];

  const statuses = await statusModel
    .find({
      [`${type}Id`]: item.id,
      userId: userId,
    })
    .exec();

  const statusMap = new Map();
  statuses.forEach((status) => {
    status.statuses.forEach((dateStatus) => {
      const statusDate = moment(dateStatus.date, 'DD/MM/YYYY').startOf('day');
      if (statusDate.isBetween(startOfDay, endOfDay, null, '[]')) {
        dateStatus.times.forEach((timeStatus) => {
          if (!['paused', 'suspend'].includes(timeStatus.status)) {
            const key = `${statusDate.format('DD/MM/YYYY')}|${timeStatus.time}`;
            statusMap.set(key, timeStatus.status);
          }
        });
      }
    });
  });

  const timeWiseStatuses = [];
  let finishedRecord = [];
  const uniqueFinishedEntries = new Set();

  for (
    let day = moment(item.startDate, 'DD/MM/YYYY');
    day.isSameOrBefore(moment(item.endDate, 'DD/MM/YYYY'));
    day.add(1, 'days')
  ) {
    const currentDate = day.format('DD/MM/YYYY');

    if (type === 'treatment' || type === 'medication') {
      (item.times || []).forEach((time, index) => {
        const key = `${currentDate}|${time}`;
        const status = statusMap.get(key) || '';
        const additionalProps =
          type === 'medication'
            ? {
              numberOfCapsule: item.numberOfCapsule
                ? item.numberOfCapsule[index]
                : undefined,
            }
            : { session: item.numberOfSessions };

        if (day.isBetween(startOfDay, endOfDay, null, '[]')) {
          timeWiseStatuses.push({
            time,
            date: currentDate,
            status,
            ...additionalProps,
          });
        }
      });
    }

    statuses.forEach((status) => {
      const isRelevantStatus =
        (type === 'medication' &&
          status.medicationId?.toString() === item.id) ||
        (type === 'treatment' && status.treatmentId?.toString() === item.id) ||
        (type === 'cycle' && status.cycleId?.toString() === item.id);

      if (isRelevantStatus) {
        status.statuses.forEach((dateStatus) => {
          dateStatus.times.forEach((timeStatus) => {
            if (timeStatus.status === 'finished') {
              const finishedKey = `${timeStatus.time}|${moment(dateStatus.date).format('DD/MM/YYYY')}`;

              if (!uniqueFinishedEntries.has(finishedKey)) {
                if (day.isBetween(startOfDay, endOfDay, null, '[]')) {
                  finishedRecord.push({
                    time: timeStatus.time,
                    date: moment(dateStatus.date).format('DD/MM/YYYY'),
                    status: 'finished',
                  });
                  uniqueFinishedEntries.add(finishedKey);
                }
              }
            }
          });
        });
      }
    });
  }

  if (type === 'cycle') {
    const cycleStatusRecord = await CycleStatusModel.findOne({
      cycleId: item.id,
      userId: userId,
    });

    const cycleWiseStatuses = processCycleStatuses(
      cycleStatusRecord,
      startOfDay,
      endOfDay,
    );
    return {
      timeWiseStatuses: cycleWiseStatuses,
    };
  }

  if (finishedRecord.length === 0) {
    finishedRecord = '';
  }

  let adherencePercentage = 0;
  if (type === 'treatment') {
    const totalSessions = item.numberOfSessions * totalDays;
    const completedSessions = timeWiseStatuses.filter(
      (session) => session.status === 'completed' || session.status === 'taken',
    ).length;

    adherencePercentage =
      totalSessions > 0 ? (completedSessions / totalSessions) * 100 : 0;
  } else if (type === 'medication') {
    const takenStatusCount = [...statusMap.values()].filter(
      (status) => status === 'taken' || status === 'completed',
    ).length;

    const totalRecords = item.times.length * totalDays;
    adherencePercentage =
      totalRecords > 0 ? (takenStatusCount / totalRecords) * 100 : 0;
  } else if (type === 'cycle') {
    adherencePercentage = calculateAdherencePercentage(
      finishedRecord,
      totalDays,
    );
  }

  const filteredTimeWiseStatuses = timeWiseStatuses.filter((status) =>
    moment(status.date, 'DD/MM/YYYY').isBetween(
      startOfDay,
      endOfDay,
      null,
      '[]',
    ),
  );

  return {
    adherencePercentage: adherencePercentage.toFixed(2),
    timeWiseStatuses: filteredTimeWiseStatuses,
    finishedRecord,
  };
};

const processCycleStatuses = (cycleStatusRecord, startOfDay, endOfDay) => {
  const timeWiseStatuses = [];

  if (cycleStatusRecord?.statuses?.length) {
    cycleStatusRecord.statuses.forEach((statusEntry) => {
      if (statusEntry.times && statusEntry.times.length > 0) {
        statusEntry.times.forEach((timeEntry) => {
          const activeStartDate = moment.utc(statusEntry.date).startOf('day');
          const completedDate =
            timeEntry.status === 'completed' ? activeStartDate : null;

          if (
            activeStartDate.isBetween(startOfDay, endOfDay, null, '[]') ||
            completedDate 
            
          ) {
            if (timeEntry.status === 'active' && timeEntry.cycleDuration > 0) {
              const activeStatus = {
                activeStartDate: activeStartDate.format('DD/MM/YYYY'),
                activeTime: timeEntry.time,
                cycleDuration: timeEntry.cycleDuration,
                completedDate: null,
              };
              timeWiseStatuses.push(activeStatus);
            } else if (timeEntry.status === 'completed') {
              timeWiseStatuses.forEach((entry) => {
                if (!entry.completedDate) {
                  entry.completedDate = activeStartDate.format('DD/MM/YYYY');
                }
              });
            }
          }
        });
      }
    });
  }

  return timeWiseStatuses.filter(
    (status) =>
      status.activeStartDate ||
      status.activeTime ||
      status.cycleDuration ||
      status.completedDate,
  );
};

const calculateAdherencePercentage = (timeWiseStatuses, totalDays) => {
  const completedCount = timeWiseStatuses.filter(
    (status) => status.status === 'finished',
  ).length;

  if (totalDays === 0) {
    return 0;
  }

  return (completedCount / totalDays) * 100;
};
