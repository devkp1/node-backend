import moment from 'moment';

export const formatMedicationData = (
  medication,
  adherencePercentage,
  timeWiseStatuses,
  finishedRecord,
  activeStatus,
  pauseEntries,
  totalMedicationCount,
  completedMedicationCount
 
 
) => {
  return {
    reminderType: 'medication',
    id: medication._id,
    medicationName: medication.medicationName,
    startDate: moment.utc(medication.startDate).format('DD/MM/YYYY'),
    endDate: moment.utc(medication.endDate).format('DD/MM/YYYY'),
    MedicationType: medication.type,
    strength: medication.strength,
    unit: medication.unit,
    frequency: medication.frequency,
    foodTime: medication.foodTime,
    timeFrequency: medication.timeFrequency,
    times: medication.times,
    numberOfCapsule: medication.numberOfCapsule,
    notes: medication.notes,
    activeStatus: activeStatus? activeStatus: '',
    pauseEntries : pauseEntries? pauseEntries: '',
    adherencePercentage: adherencePercentage
      ? `${adherencePercentage}%`
      : undefined,
    finishedRecord : finishedRecord,
    timeWiseStatuses: timeWiseStatuses,
    totalMedicationCount: totalMedicationCount,
    completedMedicationCount: completedMedicationCount
      ? completedMedicationCount
      : undefined,
  
  };
};

export const formatTreatmentData = (
  treatment,
  adherencePercentage,
  timeWiseStatuses,
  finishedRecord,
  activeStatus,
  pauseEntries,
  totalTreatmentCount,
  completedTreatmentCount,
  
) => {
  return {
    reminderType: 'treatment',
    id: treatment._id,
    treatmentName: treatment.treatmentName,
    startDate: moment.utc(treatment.startDate).format('DD/MM/YYYY'),
    endDate: moment.utc(treatment.endDate).format('DD/MM/YYYY'),
    frequency: treatment.frequency,
    timeFrequency: treatment.timeFrequency,
    times: treatment.times,
    numberOfSessions: treatment.numberOfSessions,
    notes: treatment.notes,
    activeStatus: activeStatus ?activeStatus :'',
    pauseEntries: pauseEntries?pauseEntries:'',
    adherencePercentage: adherencePercentage
      ? `${adherencePercentage}%`
      : undefined,
    finishedRecord :finishedRecord,
    timeWiseStatuses: timeWiseStatuses,
    totalTreatmentCount: totalTreatmentCount,
    completedTreatmentCount: completedTreatmentCount
      ? completedTreatmentCount
      : undefined,
  };
};

export const addformatTreatmentData = (
  treatment,
  adherencePercentage,
  timeWiseStatuses,
  totalTreatmentCount,
  completedTreatmentCount,
) => {
  return {
    id: treatment._id,
    treatmentName: treatment.treatmentName,
    startDate: moment.utc(treatment.startDate).format('DD/MM/YYYY'),
    endDate: moment.utc(treatment.endDate).format('DD/MM/YYYY'),
    frequency: treatment.frequency,
    timeFrequency: treatment.timeFrequency,
    times: treatment.times,
    numberOfSessions: treatment.numberOfSessions,
    notes: treatment.notes,
    adherencePercentage: adherencePercentage
      ? `${adherencePercentage}%`
      : undefined,
    timeWiseStatuses: timeWiseStatuses,
    totalTreatmentCount: totalTreatmentCount,
    completedTreatmentCount: completedTreatmentCount
      ? completedTreatmentCount
      : undefined,
  };
};

export const formatCycleData= (cycle,timeWiseStatuses)=>{
  return{
    reminderType: 'cycle',
    id: cycle._id,
    cycleLength: cycle.cycleLength,
    menstruationLength: cycle.menstruationLength,
    menstruationStartDate: moment(cycle.menstruationStartDate).format(
      'DD/MM/YYYY',
    ),
    time: cycle.time,
    scheduleDayBefore: cycle.scheduleDayBefore,
    message: cycle.message,
    autoCompleted: cycle.autoCompleted,
    completedDays: cycle.completedDays,
    timeWiseStatuses :timeWiseStatuses
  }
}

export const addFormatMedicationData = (
  medication,
  adherencePercentage,
  timeWiseStatuses,
  totalMedicationCount,
  completedMedicationCount,
) => {
  return {
    id: medication._id,
    medicationName: medication.medicationName,
    startDate: moment.utc(medication.startDate).format('DD/MM/YYYY'),
    endDate: moment.utc(medication.endDate).format('DD/MM/YYYY'),
    type: medication.type,
    strength: medication.strength,
    unit: medication.unit,
    frequency: medication.frequency,
    foodTime: medication.foodTime,
    timeFrequency: medication.timeFrequency,
    times: medication.times,
    numberOfCapsule: medication.numberOfCapsule,
    notes: medication.notes,
    timeWiseStatuses: timeWiseStatuses,
    adherencePercentage: adherencePercentage
      ? `${adherencePercentage}%`
      : undefined,
    totalMedicationCount: totalMedicationCount,
    completedMedicationCount: completedMedicationCount
      ? completedMedicationCount
      : undefined,
  };
};

export const formatPauseSuspendMedicationData = (
  medication,
  timeWiseStatuses,
) => {
  return {
    reminderType: 'medication',
    id: medication._id,
    medicationName: medication.medicationName,
    startDate: moment.utc(medication.startDate).format('DD/MM/YYYY'),
    endDate: moment.utc(medication.endDate).format('DD/MM/YYYY'),
    type: medication.type,
    strength: medication.strength,
    unit: medication.unit,
    frequency: medication.frequency,
    foodTime: medication.foodTime,
    timeFrequency: medication.timeFrequency,
    times: medication.times,
    numberOfCapsule: medication.numberOfCapsule,
    notes: medication.notes,
    timeWiseStatuses: timeWiseStatuses,
  };
};

export const formatPauseSuspendTreatmentData = (
  treatment,
  timeWiseStatuses,
) => {
  return {
    reminderType: 'treatment',
    id: treatment._id,
    treatmentName: treatment.treatmentName,
    startDate: moment.utc(treatment.startDate).format('DD/MM/YYYY'),
    endDate: moment.utc(treatment.endDate).format('DD/MM/YYYY'),
    frequency: treatment.frequency,
    timeFrequency: treatment.timeFrequency,
    times: treatment.times,
    numberOfSessions: treatment.numberOfSessions,
    notes: treatment.notes,
    timeWiseStatuses: timeWiseStatuses,
  };
};

export const formatPauseSuspendCycleData = (
  cycle,
  timeWiseStatuses,
) => {
  return {
    reminderType: 'cycle',
    id: cycle._id,
    cycleLength: cycle.cycleLength,
    menstruationLength: cycle.menstruationLength,
    menstruationStartDate: moment(cycle.menstruationStartDate).format(
      'DD/MM/YYYY',
    ),
    time: cycle.time,
    scheduleDayBefore: cycle.scheduleDayBefore,
    message: cycle.message,
    autoCompleted: cycle.autoCompleted,
    completedDays: cycle.completedDays,
    timeWiseStatuses :timeWiseStatuses
  };
};
