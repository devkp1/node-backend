import axios from 'axios';
import https from 'https';

const getPostalCode = async (cityName, stateCode, countryCode) => {
  try {
    const response = await axios.get(
      `https://api.zippopotam.us/${countryCode}/${stateCode}/${cityName}`,
      {
        httpsAgent: new https.Agent({
          rejectUnauthorized: false,
          keepAlive: true,
          minVersion: 'TLSv1.2',
        }),
      },
    );

    const postalCodeDetails = response.data.places.map(
      (detail) => detail['post code'],
    );

    return postalCodeDetails;
  } catch (error) {
    if (error) {
      return [];
    }
  }
};

export default getPostalCode;
