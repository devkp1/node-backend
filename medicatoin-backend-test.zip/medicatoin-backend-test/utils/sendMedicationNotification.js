import { NotificationSendingFailed } from '#root/constants/errorMessages.js';
import { statusCodes } from '#root/constants/statusCodeMessages.js';
import logger from '#root/logger.js';
import notificationModel from '#root/modules/Notification/notification.model.js';
import User from '#root/modules/User/user.model.js';
import notificationService from '#root/services/notificationService.js';
import { errorResponse } from './responseHandler.js';


export const sendMedicationNotification = async (userId, message) => {
  try {
     
    const user = await User.findById(userId);
    
    if (!user) {
      return; 
    }

    if (!user.notifyMe) {
      return;
    }
  
    const notification = await notificationModel.findOne({ userId });

    if (notification) {
      const { androidFcmToken, iosFcmToken } = notification;

     
      const promises = [];
      if (androidFcmToken) {
        promises.push(notificationService.sendNotification(androidFcmToken, message));
      }
      if (iosFcmToken) {
        promises.push(notificationService.sendNotification(iosFcmToken, message));
      }

      await Promise.all(promises);
      
    }
  } catch (error) {
    logger.error(`Sending notification error: ${error.message}`);
    return errorResponse(
      undefined,
      new Error(NotificationSendingFailed),
      NotificationSendingFailed,
      statusCodes.VALIDATION_ERROR,
    );
  }
};
