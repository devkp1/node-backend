import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';

dotenv.config();

export const createJwtToken = (user) => {
  const payload = {
    id: user._id,
    email: user.email,
  };
    
  return jwt.sign(payload, process.env.SECRET_TOKEN, { expiresIn: '1h' });
};
