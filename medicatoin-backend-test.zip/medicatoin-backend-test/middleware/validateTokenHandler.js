import dotenv from 'dotenv';
import { errorResponse } from '#utils/responseHandler.js';
import { isTokenBlacklisted } from '#utils/tokenManager.js';
import { statusCodes } from '#constants/statusCodeMessages.js';
import {
  blacklistedTokenMessage,
  ForbiddenErrorMessage,
  TokenErrorMessage,
} from '#constants/errorMessages.js';

dotenv.config();

export const isAuthenticateUser = (req, res, next) => {
  const authHeader = req.headers.authorization;
  // eslint-disable-next-line
  console.log('req ----->', req.route.path);
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return errorResponse(
      res,
      new Error(ForbiddenErrorMessage),
      TokenErrorMessage,
      statusCodes.FORBIDDEN,
    );
  }

  const token = authHeader.split(' ')[1];

  if (isTokenBlacklisted(token)) {
    return errorResponse(
      res,
      new Error(blacklistedTokenMessage),
      blacklistedTokenMessage,
      statusCodes.UNAUTHORIZED,
    );
  }

  req.token = token;
  next();
};


