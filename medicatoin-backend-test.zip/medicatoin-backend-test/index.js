import fs from 'fs';
import https from 'https';
import { config as dotenvConfig } from 'dotenv';
import express from 'express';
import cors from 'cors';
import session from 'express-session';
import passport from 'passport';
import logger from './logger.js';
import locationRoute from '#modules/Location/location.route.js';
import { db } from '#config/database/databaseConnection.js';
import { populateDatabase } from '#utils/populateLocationDatabase.js';
import userRoute from '#modules/User/user.route.js';
import { setupSwagger } from '#config/initial/swagger.js';
import { setUpLogger } from '#config/initial/setupLogging.js';
import { setupGracefulShutdown } from '#config/initial/shutdown.js';
import { statusCodes } from '#constants/statusCodeMessages.js';
import { errorResponse } from '#utils/responseHandler.js';
import {
  NotFoundErrorMessage,
  ServerErrorMessage,
} from '#constants/errorMessages.js';
import medicineRoute from '#modules/Medicine/medicine.routes.js';
import treatmentRoute from './modules/Treatment/treatment.routes.js';
import medicationRoute from '#modules/Medication/Medicine/medication.route.js';
import cycleRoute from './modules/Cycle/cycle.route.js';
import { createCron } from './Cron/autoCompltedCron.js';
import authRoute from './modules/Auth/auth.route.js';
import { initializePassport } from './config/passport/customPassport.js';
import notificationRoute from './modules/Notification/notification.route.js';
import { setupMedicationAndTreatmentEndReminderCron } from './Cron/expirationMedicationTreatmentCron.js';
import { setupMorningMedicationReminderCron } from './Cron/morningMedicationTreatmentCron.js';
import { setupCycleReminderCron } from './Cron/cycleReminderCron.js';
import { startCycleReminderCronJob } from './Cron/morningCycleReminder.js';
import { sleepCycleReminderCronJob } from './Cron/SleepCycleReminder.js';
import { MotivationalCycleReminderCronJob } from './Cron/motivationalCycleReminder.js';
import treatmemtsRoute from './modules/Treatment/Treatments/treatments.route.js';

dotenvConfig();

const app = express();
const port = process.env.PORT || 5000;

// HTTPS server options
const sslOptions = {
  key: fs.readFileSync('/etc/letsencrypt/live/medication.shineinfosoft.in/privkey.pem'),
  cert: fs.readFileSync('/etc/letsencrypt/live/medication.shineinfosoft.in/cert.pem'),
  ca: fs.readFileSync('/etc/letsencrypt/live/medication.shineinfosoft.in/chain.pem'),
};

app.use(
  session({
    secret: process.env.SESSION_SECRET || 'defaultSecret',
    resave: false,
    saveUninitialized: true,
    cookie: {
      secure: process.env.NODE_ENV === 'production',  // Ensures cookies are sent over HTTPS
      httpOnly: true,
      maxAge: 3600000,
    },
  }),
);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors({ origin: '*' }));
setUpLogger(logger);
setupSwagger(app);
populateDatabase();

initializePassport();
app.use(passport.initialize());
app.use(passport.session());

app.get('/', (req, res) => {
  res.send('Hello World!');
});

app.use('/api/v1', userRoute);
app.use('/api/v1', locationRoute);
app.use('/api/v1', medicationRoute);
app.use('/api/v1', medicineRoute);
app.use('/api/v1', treatmentRoute);
app.use('/api/v1', treatmemtsRoute);
app.use('/api/v1', cycleRoute);
app.use('/api/v1/auth', authRoute);
app.use('/api/v1', notificationRoute);

app.use((req, res, next) => {
  const error = new Error(NotFoundErrorMessage);
  error.status = statusCodes.NOT_FOUND;
  next(error);
});

// eslint-disable-next-line
app.use((error, req, res, next) => {
  const statusCode = error.status || statusCodes.SERVER_ERROR;
  const message = error.message || ServerErrorMessage;
  return errorResponse(res, error, message, statusCode);
});

// Create HTTPS server
const server = https.createServer(sslOptions, app);

server.listen(port, () => {
  db();
  createCron();
  setupCycleReminderCron();
  setupMedicationAndTreatmentEndReminderCron();
  setupMorningMedicationReminderCron();
  startCycleReminderCronJob();
  sleepCycleReminderCronJob();
  MotivationalCycleReminderCronJob();
  //console.log(`Server is running on https://localhost:${port}`);
});

setupGracefulShutdown(server);
