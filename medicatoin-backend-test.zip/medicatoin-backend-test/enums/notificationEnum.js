export const deviceType = { 
  'A': 'android',
  'I': 'ios',
  'B': 'both'
};
  