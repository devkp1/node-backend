export const medicationType = {
  capsule: 'Capsule',
  tablet: 'Tablet',
  liquid: 'Liquid',
  lotion: 'Lotion gel foam cream',
  injection: 'Injection',
  spray: 'Spray',
  powder: 'Powder',
  drops: 'Drops',
  other: 'Other',
};

export const medicationUnit = {
  mg: 'mg',
  mcg: 'mcg',
  g: 'g',
  ml: 'ml',
  percentage: '%',
  cfu: 'CFU',
  iu: 'IU',
  mgcml: 'mcg/ml',
  mEq: 'mEq',
  mgml: 'mg/ml',
  lmin: 'l/min'
};

export const medicationFrequency = {
  everyday: 'Everyday',
  dayAfterDay: 'Day After Day',
  custom: [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday',
  ],
};

export const medicationFoodTime = {
  before: 'Before meal',
  anyTime: 'Any time',
  after: 'After meal',
};

export const medicationTimeFrequency = {
  'Once a Day': 1,
  'Twice a Day': 2,
  'Thrice a Day': 3,
  'Four Times a Day': 4,
  'Five Times a Day': 5,
  'Six Times a Day': 6,
  'Seven Times a Day': 7,
  'Eight Times a Day': 8,
  'Nine Times a Day': 9,
  'Ten Times a Day': 10,
  'Eleven Times a Day': 11,
  'Twelve Times a Day': 12,
  'Every hour': 24,
  'Every two hours': 12,
  'Every three hours': 8,
  'Every four hours': 6,
  'Every five hours': 5,
  'Every six hours': 4,
  'Every twelve hours': 2,
};

export const medicationStatuses = {
  0: 'taken',
  1: 'paused',
  2: 'resumed',
  3: 'skipped',
  4: 'completed',
  5: 'suspend',
  6: 'finished'
};
