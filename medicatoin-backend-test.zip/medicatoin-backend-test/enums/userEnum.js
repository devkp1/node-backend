export const Gender = { 
  'M': 'Male',
  'F': 'Female',
  'O': 'Other' 
};
