
export const setSchedule = {
  1: '1 day before',
  2: '2 day before',
  3: '3 day before',
  4: '4 day before',
  5: '5 day before',
  6: '6 day before',
};

export const cycleStatus = {
  1 : 'active',
  2 : 'completed',
  3 : 'pending',
  4 : 'resumed',
  5 : 'paused',
  6 : 'suspend',
  7 : 'auto complete',
}
