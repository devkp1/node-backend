import globals from 'globals';
import pluginJs from '@eslint/js';

export default [
  {
    // Language options
    languageOptions: {
      globals: {
        ...globals.browser,
        ...globals.node, // Add Node.js globals
      },
    },
    // Additional rules or options specific to your project
    rules: {
      'no-console': 'error',
      'no-unused-vars': 'error', // Warn on unused variables
      'no-undef': 'error', // Disallow undeclared variables
      'prefer-const': 'warn', // Prefer const over let when variable is not reassigned
      'no-var': 'error', // Disallow usage of var
      quotes: ['error', 'single'], // Enforce single quotes
      indent: ['error', 2], // Enforce 2 spaces indentation
      // Add more rules as needed
    },
  },
  pluginJs.configs.recommended, // Include recommended JavaScript rules from @eslint/eslint-plugin
];
